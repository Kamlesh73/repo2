import java.util.Scanner;
public class EvenArray{
	public static void main(String[] args){
			final int SIZE=10;
			//int i;
	
			//int [] my Arr={10,20,30,40,50};
			
			Scanner sc=new Scanner(System.in);
			int myArr[]=new int[SIZE];		
					
			//store the elements in the array
			System.out.println("eNTER 10 Numbers:");		
			for(int i=0;i<SIZE;i++)
			myArr[i]=sc.nextInt();
					
			//Retrive the element f4rom the array
			for(int i=0;i<myArr.length;i++){
				if(i%2!=0)
				System.out.println(myArr[i]);
				}
			}
}			