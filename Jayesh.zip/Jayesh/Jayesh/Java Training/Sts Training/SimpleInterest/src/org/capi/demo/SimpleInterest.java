package org.capi.demo;

import java.util.Scanner;

public class SimpleInterest {

	double principle;
	float noy;
	float roi;
	
	public void getIntput(){        // scan number
		Scanner sc=new Scanner(System.in);  // declare scanner
		
		 System.out.println("Enter the principle amount:");
		 principle=sc.nextDouble();	
		 System.out.println("Enter the number of years:");
		 noy=sc.nextFloat();	
		 System.out.println("Enter the rate of interest:");
		 roi=sc.nextFloat();			
}

	public double simpleInterest(){
		return principle*noy*roi;
	}
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		SimpleInterest si=new SimpleInterest();
				si.getIntput();
				si.simpleInterest();
				System.out.println("Interest="+ si.simpleInterest());
	}
}
	