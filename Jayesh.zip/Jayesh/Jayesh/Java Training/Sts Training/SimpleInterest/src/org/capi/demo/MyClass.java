package org.capi.demo;

public class MyClass {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		SimpleInterest si=new SimpleInterest();
				si.getIntput();
				si.simpleInterest();
				System.out.println("Interest="+ si.simpleInterest());
	}

}
