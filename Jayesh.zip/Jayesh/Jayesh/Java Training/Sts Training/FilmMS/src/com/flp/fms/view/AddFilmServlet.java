package com.flp.fms.view;

import java.io.IOException;

import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.flp.fms.domain.Actor;
import com.flp.fms.domain.Category;
import com.flp.fms.domain.Film;
import com.flp.fms.domain.Language;
import com.flp.fms.service.FilmServiceImpl;

/**
 * Servlet implementation class AddFilmServlet
 */
public class AddFilmServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {


		PrintWriter out=response.getWriter();
		
		
		FilmServiceImpl filmService=new FilmServiceImpl();
		Film film=new Film();
		
		
		/*	Setting All The Parameter of form to the film object */
		
		film.setTitle(request.getParameter("filmtitle"));
		film.setDescription(request.getParameter("filmdescription"));
		film.setReleaseYear(new Date(request.getParameter("releasedate")));
		film.setLength(Integer.parseInt(request.getParameter("filmlength")));
		film.setRatings(Integer.parseInt(request.getParameter("rating")));
		film.setReplacement(Double.parseDouble(request.getParameter("replacementcost")));
		
		//For Original langugage:
		Language lang=new Language();
		lang.setLanguage_Id(Integer.parseInt(request.getParameter("orgLang")));
		film.setOriginalLanguage(lang);
		
		//For Category:
		Category category=new Category();
		category.setCategory_Id(Integer.parseInt(request.getParameter("category")));
		film.setCategory(category);
		
		
		film.setRentalDuration(new Date(request.getParameter("rentalduration")));
		film.setSpecialFeatures(request.getParameter("specialfeature"));
		
		//For Other language:
		   String [] lang1=request.getParameterValues("otherlanguage");
		   List<Language> langs=new ArrayList<>();
		   for(String lang2:lang1)
		   {
			   Language lang3=new Language();
			   lang3.setLanguage_Id(Integer.parseInt(lang2));
			   langs.add(lang3);
		   }
		   film.setLanguages(langs);
		   
		   
		   
		   
		   
		//For Actor:
		 String [] actor=request.getParameterValues("actor");
		 List<Actor> actors=new ArrayList<>();
		 
		 for(String act:actor){
			 Actor act1=new Actor();
			 act1.setActor_Id(Integer.parseInt(act));
			 actors.add(act1);
		 }
		film.setActors(actors);
		 
		 int count=filmService.addFilm(film);
			if(count==1)
			/*	alert(" Film Successfully added");*/
				/*out.println("\033 Film Successfully added");*/
			
			//out.print("Hello");
				out.println("<html>");
			out.println("<body>");
		
			out.println( "<center><h3 style='color:white'>Film Successfully added</h3></center>");
			out.println("</body>");
			out.println("</html>");
	}

}
