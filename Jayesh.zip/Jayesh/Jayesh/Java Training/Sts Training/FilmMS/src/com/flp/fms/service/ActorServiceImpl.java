package com.flp.fms.service;

import java.util.List;
import java.util.Set;

import com.flp.fms.doa.ActorDaoImplForList;
import com.flp.fms.doa.IActorDao;
import com.flp.fms.domain.Actor;

public class ActorServiceImpl implements IActorService{

	ActorDaoImplForList actorDao=new ActorDaoImplForList();
	@Override
	public List<Actor> getActorList() {
		
		return actorDao.getActorList();
	}
	
	@Override
	public int addActor(Actor actor) {
		return actorDao.addActor(actor);
	}

	public int removeActor(int id) {
		// TODO Auto-generated method stub
		return actorDao.removeActor(id);
	}

	public Actor getActorByID(int id) {
		// TODO Auto-generated method stub
		return actorDao.getActorByID(id);
	}

	public int updateFilm(Actor actor, int actorId) {
		// TODO Auto-generated method stub
		return actorDao.updateFilm(actor, actorId);
	}


	
}
