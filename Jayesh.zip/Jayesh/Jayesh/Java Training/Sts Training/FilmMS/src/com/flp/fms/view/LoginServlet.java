package com.flp.fms.view;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.flp.fms.domain.LoginUser;
import com.flp.fms.service.FilmServiceImpl;
import com.flp.fms.service.IFilmService;



/**
 * Servlet implementation class LoginServlet
 */
public class LoginServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		PrintWriter out=response.getWriter();
		
		String userName=request.getParameter("uname");
		String userPwd=request.getParameter("upwd");
		
		
		
		
		LoginUser loginUser=new LoginUser();
		loginUser.setUserName(userName);
		loginUser.setUserPwd(userPwd);
		
		
		
		
		IFilmService filmService =new FilmServiceImpl();
		
		if(filmService.isValidLogin(loginUser))
		{//response.sendRedirect("pages/success.html");
			out.print("<html>"
					+"<head>"
					+ "</head>"
					+"</html>");
		
			request.getRequestDispatcher("pages/success.html").forward(request, response);
			/*HttpSession session=request.getSession(false);  
	        if(session!=null){  
	        String name=(String)session.getAttribute("userName");  
	          
	       System.out.println("Hello, "+userName+" Welcome to Profile");  
	        }  */
   
		} 
	        else{  
	        	// System.out.println("Please login first");  
	         //   out.print("Please login first");  
	            request.getRequestDispatcher("pages/loginform1.html").include(request, response); 
	        }  
	     /*out.close();  */	
	}

}
