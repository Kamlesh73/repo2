package com.flp.fms.view;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.flp.fms.domain.Actor;
import com.flp.fms.domain.Film;
import com.flp.fms.domain.Language;
import com.flp.fms.service.FilmServiceImpl;

/**
 * Servlet implementation class UpDateServlet
 */
public class UpDateServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		

		FilmServiceImpl filmservice=new FilmServiceImpl();
		List<Film> film=filmservice.getAllFilms();
		PrintWriter out=response.getWriter();
		
		/*	 HTML page for Update Operation   */

		out.println("<head>");
		out.print("<link rel='stylesheet' type='text/css' href='css/mystyles.css'>");
		
		out.println("</head>");
		
		/*   Parameters of the Film Object:  */
		out.println("<body>"
			/*	+ "<form action='DeleteServlet1' method='post'>"*/
				+ "<center><font size='5' color='white'> List Of Films to be UpDated</font></center>"
				+ "<table border=2px style='color:white'>"
			
				+ "<tr>"
				+ "<th>Film Id</th>"
				+ "<th>Title</th>"
				+ "<th>Description</th>"
				+ "<th>Release Year</th>"
				+ "<th>Original Language</th>"
				+ "<th>Languages</th>"
				+ "<th>Rental Duration</th>"
				+ "<th>Length</th>"
				+ "<th>Replacement Cost</th>"
				+ "<th>Ratings</th>"
				+ "<th>Special Features</th>"
				+ "<th>Actors</th>"
				+ "<th>Category</th>"
				+ "<th>Update</th>"
				+ "</tr>");
		
		/*		Iteration to retrive the Film Object parameters:	*/
		for(Film film1:film){
			List<Language> languages=film1.getLanguages();
			
			/*For Language:*/
			String langs="";
			for(Language lang:languages)
			{
				langs=langs+lang.getLanguageName()+",";
			}
			
			/*For Actor:*/
			List<Actor> actors=film1.getActors();
			String actors1="";
			for(Actor actor:actors)
			{
				actors1=actors1+actor.getFirstName()+" "+actor.getLastName()+",";
			}
			out.println("<tr>");
			out.println("<td>"+film1.getFilm_id()+"</td>");
			out.println("<td>"+film1.getTitle()+"</td>");
			out.println("<td>"+film1.getDescription()+"</td>");
			out.println("<td>"+film1.getReleaseYear()+"</td>");
			out.println("<td>"+film1.getOriginalLanguage().getLanguageName()+"</td>");
			out.println("<td>"+langs.substring(0, (langs.length()-1))+"</td>");
			out.println("<td>"+film1.getRentalDuration()+"</td>");
			out.println("<td>"+film1.getLength()+"</td>");
			out.println("<td>"+film1.getReplacement()+"</td>");
			out.println("<td>"+film1.getRatings()+"</td>");
			out.println("<td>"+film1.getSpecialFeatures()+"</td>");
			out.println("<td>"+actors1.substring(0, (actors1.length()-1))+"</td>");
			out.println("<td>"+film1.getCategory().getcategory_name()+"</td>");
			out.print("<td><a href='UpDateServlet1?id="+film1.getFilm_id()+"'><h5 style='color:##728FCE ;'>Edit</h5></a></td>");
			out.println("</tr>");
		}
			out.println("</table></body>");
	}

		
		
		
		
	}

