package com.flp.fms.doa;

import java.util.List;
import java.util.Set;

import com.flp.fms.domain.Actor;

public interface IActorDao {

	
	public int addActor(Actor actor);
/*	public List<Actor>addActor();*/
	public int removeActor(int id);
	List<Actor> getActorList();
	public Actor getActorByID(int id);
	public int updateFilm(Actor actor, int actorId);
}
