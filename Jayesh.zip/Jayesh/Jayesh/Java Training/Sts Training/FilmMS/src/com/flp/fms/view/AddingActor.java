package com.flp.fms.view;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.flp.fms.domain.Actor;
import com.flp.fms.service.ActorServiceImpl;

/**
 * Servlet implementation class AddingActor
 */
public class AddingActor extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		

		PrintWriter out=response.getWriter();
		ActorServiceImpl actorService=new ActorServiceImpl();
		Actor actor=new Actor();
		
		
		String fname=request.getParameter("FName");
		actor.setFirstName(fname);
		
		String lname=request.getParameter("LName");
		actor.setLastName(lname);
		
		
		int count=actorService.addActor(actor);
		if(count==1){
			out.println("<head>");
			out.print("<link rel='stylesheet' type='text/css' href='css/myStyle.css'>");
			out.println("</head>");
			//out.println("<body><br/><br/><br/><h2><center>Actor added successfully!!!!!</center></h2></body>");
			out.println( "<center><h3 style='color:white'>Actor added successfully!</h3></center>");
		}
		
		
	}

}
