package com.flp.fms.doa;

import java.sql.Connection;

import java.sql.Date;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.flp.fms.domain.Actor;
import com.flp.fms.domain.Category;
import com.flp.fms.domain.Film;
import com.flp.fms.domain.Language;
import com.flp.fms.domain.LoginUser;

public class FilmDaoImplForList implements IFilmDao {

	private Map<Integer, Film> film_Repository=new HashMap<>();

	
/*	Connection Generation:*/
public Connection getConnection(){
		
		Connection connection=null;
		
		try {
			Class.forName("com.mysql.jdbc.Driver");
			connection=DriverManager.getConnection("jdbc:mysql://localhost:3306/FMSDatabase", "root", "Pass1234");
			
			
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
		
		return connection;
	} 
	
	
	
	
	
	/*Get List Of Languages*/
	@Override
	public List<Language> getLanguages() {
		List<Language> languages=new ArrayList<>();
		
		
		/*languages.add(new Language(1, "English"));
		languages.add(new Language(2, "Marathi"));
		languages.add(new Language(3, "Hindi"));
		languages.add(new Language(4, "Telgu"));
		languages.add(new Language(5, "Malyalam"));
		languages.add(new Language(6, "Bengali"));
		languages.add(new Language(7, "Kannad"));*/
		
		Connection con=getConnection();
		String sql="select*from LANGUAGE";
		try {
			PreparedStatement pst=con.prepareStatement(sql);
	
			
			ResultSet rs=pst.executeQuery();
			
		
		
			while(rs.next())
			{
		
			Language lang=new Language();
			lang.setLanguage_Id(rs.getInt(1));
			lang.setLanguageName(rs.getString(2));
			
			
			languages.add(lang);
			}
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
		}
		
		try {
			con.close();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return languages;
	
	}

	/*Get List Of Category*/
	@Override
	public List<Category> getCategory() {
		List<Category> categorys=new ArrayList<>();
		
		/*categorys.add(new Category(1, "Horror"));
		categorys.add(new Category(2, "Comedy"));
		categorys.add(new Category(3, "Action"));
		categorys.add(new Category(4, "Filmy"));
		categorys.add(new Category(5, "Romantic"));*/
		

		Connection con=getConnection();
		String sql="select * from CATEGORY";
		/*category.add(new Category(1, "Comic"));
		category.add(new Category(2, "Horrer"));
		category.add(new Category(3, "Action"));*/
		
		try {
			PreparedStatement pst=con.prepareStatement(sql);
			ResultSet rs=pst.executeQuery();
			
			while(rs.next())
			{
				Category category1=new Category();
				category1.setCategory_Id(rs.getInt(1));
				category1.setCategory_name(rs.getString(2));
				
				
				categorys.add(category1);
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		try {
			con.close();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return categorys;
		
	
	}
	
	//CURD Operation
	
	//ADDITION Logic of Film to Database
		@Override
		public int addFilm(Film film) {
			Connection con=getConnection();
			String sql="insert into film(title,description,releaseYear,originalLanguage,rentalDuration,length,replacementCost,ratings,specialFeatures,category)"
					+ "values(?,?,?,?,?,?,?,?,?,?)";
			

			
			int count=0;
			
			try {
				PreparedStatement pst=con.prepareStatement(sql);
				
				pst.setString(1, film.getTitle());
				pst.setString(2, film.getDescription());
				pst.setDate(3, new Date(film.getReleaseYear().getTime()));
				int language =film.getOriginalLanguage().getLanguage_Id();
				pst.setInt(4, language);
				pst.setDate(5, new Date(film.getRentalDuration().getTime()));
				pst.setInt(6, film.getLength());
				pst.setDouble(7, film.getReplacement());
				pst.setInt(8, film.getRatings());
				pst.setString(9, film.getSpecialFeatures());
				int category=film.getCategory().getCategory_Id();
				pst.setInt(10, category);
				count=pst.executeUpdate();
				
				//getting the last entered record in film table
				String sql1="select filmid from FILM order by filmid desc limit 1 ";
				PreparedStatement pst1=con.prepareStatement(sql1);
				ResultSet rs=pst1.executeQuery();
				int film_id=0;
				while(rs.next())
				{
					film_id=rs.getInt(1);
					
				}
				
				
				//entering data in film_language table
				String sql2="insert into film_language values(?,?)";
				PreparedStatement pst2=con.prepareStatement(sql2);
			     List<Language> lang=film.getLanguages();
			    // System.out.println(lang);
				for(Language lang1:lang){
				pst2.setInt(1, film_id);
				pst2.setInt(2,lang1.getLanguage_Id());
			    count=pst2.executeUpdate();
				}

				//entering data in film_actors table
				String sql3="insert into film_actors values(?,?)";
				PreparedStatement pst3=con.prepareStatement(sql3);
			    List<Actor> actor=film.getActors();
				for(Actor act1:actor){
				pst3.setInt(1, film_id);
				pst3.setInt(2,act1.getActor_Id());
				 count=pst3.executeUpdate();
				}
				
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
			
			System.out.println(film);
			try {
				con.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			return 1;
		}




		@Override
		public Map<Integer, Film> searchFilms() {
			
			return film_Repository;
		}

	
		//Get List Of Films:
		@Override
		public List<Film> getAllFilms() {
			Connection con=getConnection();
			List<Film> films=new ArrayList<>();
			String sql="select * from FILM";
			
			try {
				PreparedStatement pst=con.prepareStatement(sql);
				ResultSet rs=pst.executeQuery();
				while(rs.next()){
					Film film=new Film();
					film.setFilm_id(rs.getInt(1));
					film.setTitle(rs.getString(2));
					film.setDescription(rs.getString(3));
					film.setReleaseYear(rs.getDate(4).valueOf(rs.getDate(4).toString()));
					//Original Language
					int lang_id=rs.getInt(5);
					Language orgLang=getOrgLang(lang_id);
					film.setOriginalLanguage(orgLang);
					
					//Rental Duration
					film.setRentalDuration(rs.getDate(6).valueOf(rs.getDate(6).toString()));
					
					//length
					film.setLength(rs.getInt(7));
					
					//replacementCost
					film.setReplacement(rs.getDouble(8));
					
					//rating
					film.setRatings(rs.getInt(9));
					
					//Special Features
					film.setSpecialFeatures(rs.getString(10));
					
					int category_id=rs.getInt(11);
					Category category=getCategoryforListing(category_id);
					film.setCategory(category);
					
					//other Lang
					List<Integer> lang_ids=getLanguagesIDs(film.getFilm_id());
					List<Language> lang_name=new ArrayList<>();
					for(Integer langid:lang_ids){
						lang_name.add(getOrgLang(langid));
					}
					film.setLanguages(lang_name);
					
					//Actors
					
					
					List<Actor> act=new ArrayList<>();
					List<Integer> actor_id=getActorIDS(film.getFilm_id());
					for(Integer actor:actor_id){
						act.add(getActors(actor));
					}
					film.setActors(act);
					films.add(film);
					
					
				}
				
				
				
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			try {
				con.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			return films;
			
		}

		//Get Actors:
		public Actor getActors(int actor) {
			Actor actor1=new Actor();
			Connection con=getConnection();
			String str="select * from actortable where ActorId=?";
			try {
				PreparedStatement pst=con.prepareStatement(str);
				pst.setInt(1, actor);
				ResultSet rs=pst.executeQuery();
				while(rs.next()){
					actor1.setFirstName(rs.getString(2));
					actor1.setLastName(rs.getString(3));
				}
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
			try {
				con.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			return actor1;
		}

		//Get List Of Actor By Ids
		public List<Integer> getActorIDS(int film_Id) {


			Connection con=getConnection();
			List<Integer> actorids=new ArrayList<>();
			String str="select * from film_actors where film_id=?";
			try {
				PreparedStatement pst=con.prepareStatement(str);
				pst.setInt(1, film_Id);
				ResultSet rs=pst.executeQuery();
				
				
				while(rs.next()){
					actorids.add(rs.getInt(2));
				}
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			try {
				con.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			return actorids;
		}


		//Get List Of Language By Ids
		public List<Integer> getLanguagesIDs(int film_Id) {
			
			Connection con=getConnection();
			String str="select * from film_language where film_id=?";
			List<Integer> id=new ArrayList<>();
			try {
				PreparedStatement pst=con.prepareStatement(str);
				pst.setInt(1, film_Id);
				ResultSet rs=pst.executeQuery();
				
				
				while(rs.next()){
					id.add(rs.getInt(2));
				}
				
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			try {
				con.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			return id;
		}

		//Get Category for List 
		public Category getCategoryforListing(int category_id) {
			Connection con=getConnection();
			Category category=new Category();
			String str="select * from category where CategoryId=?";
			try {
				PreparedStatement pst=con.prepareStatement(str);
				pst.setInt(1, category_id);
				ResultSet rs=pst.executeQuery();
				
				while(rs.next()){
					category.setCategory_name(rs.getString(2));
				}
				
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			try {
				con.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			return category;
		}



		//Get Original Language

public Language getOrgLang(int langid){
		
			
			Language lang=new Language();
			Connection con=getConnection();
			String str="select * from language where LanguageId=?";
			try {
				PreparedStatement pst=con.prepareStatement(str);
				pst.setInt(1, langid);
				ResultSet rs=pst.executeQuery();
				
				while(rs.next()){
					lang.setLanguageName(rs.getString(2));
				}
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			try {
				con.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			return lang;
			
		}


	//REMOVE logic of film
	@Override
	public int removeFilm(int id) {
	
		Connection con=getConnection();
		int count=0;
		
		String str="delete from film where filmid=?";
		String str1="delete from film_language where filmid=?";
		String str2="delete from film_actors where filmid=?";
		try {
			PreparedStatement pst=con.prepareStatement(str);
			pst.setInt(1, id);
		    count=pst.executeUpdate();
		    
		    
		    
		    PreparedStatement pst1=con.prepareStatement(str1);
		    pst1.setInt(1, id);
		    count=pst1.executeUpdate();
		    
		    
		    PreparedStatement pst2=con.prepareStatement(str2);
		    pst2.setInt(1, id);
		    count=pst2.executeUpdate();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
	}
		try {
			con.close();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	return count;
	
	
}





	//SEARCH Film Logic
	@Override
	public List<Film> searchFilm(Film film) {
		{
			Connection con=getConnection();
			int count=0;
			String sql="select * from film where";
			ArrayList<Film> films=new ArrayList<Film>();
			System.out.println(film);
			if(film!=null)
			{
				if(film.getFilm_id()>0)
				{
					
					sql+=" filmid="+film.getFilm_id();
					
					count=1;
				}
				
				if(film.getTitle()!=null)
				{
					if(count==1)
					{
						sql+=" and title='"+film.getTitle()+"'";
					}
					else
					{
						sql+=" title='"+film.getTitle()+"'";
					}
					count=2;
				}
			

				if(film.getRatings()>0)
				{
					if(count==1||count==2)
					{
						sql+=" and ratings="+film.getRatings();
					}
					else
					{
						sql+=" ratings="+film.getRatings();
					}
					count=3;
				}
				if(film.getActors()!=null)
				{
					Actor actor=new Actor();
					List<Actor> act=film.getActors();
					for(Actor a:act)
						actor=a;
					if(count==1||count==2||count==3)
					{
						sql+=" and filmid In(Select film_id from film_actors where actor_id="+actor.getActor_Id()+")";
						
					}else
					{
					sql+=" filmid In(Select film_id from film_actors where actor_id="+actor.getActor_Id()+")";
					}
					count=4;
				}
				if(film.getLanguages()!=null)
				{
					Language lang=new Language();
					List<Language> langs=film.getLanguages();
				
					for(Language l:langs)
						lang=l;
					if(count==1||count==2||count==3||count==4)
					{
						sql+=" and( filmid In(Select film_id from film_language where language_id="+lang.getLanguage_Id()+") or filmid In( Select filmid from film where originalLanguage="+lang.getLanguage_Id()+"))";
						
					}else
					{
					sql+=" ( filmid In(Select film_id from film_language where language_id="+lang.getLanguage_Id()+") or filmid In(Select filmid from film where originalLanguage="+lang.getLanguage_Id()+"))";
					
					}
					count=5;
				}
			
				 
				if(film.getReleaseYear()!=null)
				{
					if(count==1||count==2||count==3||count==4||count==5)
					{
						sql+=" and releaseYear='"+new java.sql.Date(film.getReleaseYear().getTime())+"'";
					}
					else
					{
						sql+=" releaseYear='"+new java.sql.Date(film.getReleaseYear().getTime())+"'";
					}
					count=6;
				}
				System.out.println(sql);
				try {
					PreparedStatement pst=con.prepareStatement(sql);
					ResultSet rs=pst.executeQuery();
				
					while(rs.next())
					{
						Film film1=new Film();
						film1.setFilm_id(rs.getInt(1));
						film1.setDescription(rs.getString(2));
						film1.setTitle(rs.getString(3));
						film1.setReleaseYear(rs.getDate(4));
						
						String subsql;
						subsql="select LanguageName from LANGUAGE where LanguageId="+rs.getInt(5);
						PreparedStatement pst1=con.prepareStatement(subsql);
						ResultSet rs3=pst1.executeQuery();
						Language lang=new Language();
						if(rs3.next())
						{
							lang.setLanguage_Id(rs.getInt(5));
							lang.setLanguageName(rs3.getString(1));
						}
						film1.setOriginalLanguage(lang);
						film1.setRentalDuration(rs.getDate(6));
						film1.setLength(rs.getInt(7));
						film1.setReplacement(rs.getInt(8));
						film1.setRatings(rs.getInt(9));
						film1.setSpecialFeatures(rs.getString(10));
						
						subsql="select CategoryName from Category where CategoryId="+rs.getInt(11);
						PreparedStatement pst3=con.prepareStatement(subsql);
					    rs3=pst3.executeQuery();
						if(rs3.next())
						{
							Category cat=new Category();
							cat.setCategory_Id(rs.getInt(11));
							cat.setCategory_name(rs3.getString(1));
							film1.setCategory(cat);
						}
						
						subsql="select language_id from film_language where film_id="+rs.getInt(1);
						System.out.println(rs.getInt(1));
						pst3=con.prepareStatement(subsql);
					    rs3=pst3.executeQuery();
					    List<Language> languages=new ArrayList<>();
						while(rs3.next())
						{
													
							String subsql1="select LanguageName from LANGUAGE where LanguageId="+rs3.getInt(1);
							PreparedStatement pst2=con.prepareStatement(subsql1);
							ResultSet rs1=pst2.executeQuery();
							while(rs1.next()){
								Language langs=new Language();
								langs.setLanguage_Id(rs3.getInt(1));
								langs.setLanguageName(rs1.getString(1));
								languages.add(langs);
								
							}
						}
						film1.setLanguages(languages);
						subsql="select actor_id from film_actors where film_id="+rs.getInt(1);
					
						pst3=con.prepareStatement(subsql);
					    rs3=pst3.executeQuery();
					   
					    
						List<Actor>actors=new ArrayList<Actor>();
						while(rs3.next())
						{
							String subsql1="select CustFN,CustLN from ActorTable where ActorId="+rs3.getInt(1);
							PreparedStatement pst2=con.prepareStatement(subsql1);
							ResultSet rs1=pst2.executeQuery();
							while(rs1.next()){
								Actor actr=new Actor();
								actr.setFirstName(rs1.getString(1));
								actr.setLastName(rs1.getString(2));
								actr.setActor_Id(rs3.getInt(1));
								actors.add(actr);
								
							}
						}
						film1.setActors(actors);
						film1.setLanguages(languages);
						System.out.println(film1);
						films.add(film1);
				} }catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			
				
			}
			try {
				con.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			return films;
		}

	}





	//UPDATE logic for film 
	@Override
	public int updateFilm(int id, Film film) {
		int  count=0;
		Connection con=getConnection();
		String sql="update FILM set title=?,description=?,releaseYear=?,originalLanguage=?,rentalDuration=?,LENGTH=?,replacementCost=?,ratings=?,specialFeatures=?,category=? where filmid=?";
		String sql1="delete from film_language where film_id=?";
		String sql4="delete from film_actors where film_id=?";
		
		try {
			PreparedStatement pst=con.prepareStatement(sql);
			//pst.setString(1, film.getTitle());
			pst.setString(1, film.getTitle());
			pst.setString(2, film.getDescription());
			pst.setDate(3, new Date(film.getReleaseYear().getTime()));
			int language=film.getOriginalLanguage().getLanguage_Id();
			pst.setInt(4, language);
			pst.setDate(5, new Date(film.getRentalDuration().getTime()));
			pst.setInt(6, film.getLength());
			pst.setDouble(7,film.getReplacement());
			
			pst.setInt(8,film.getRatings());
			pst.setString(9,film.getSpecialFeatures());
			int category=film.getCategory().getCategory_Id();
			pst.setInt(10,category);
			pst.setInt(11, id);
			
			count=pst.executeUpdate();
			
			
			//delete from film_language
			PreparedStatement pst1=con.prepareStatement(sql1);
			pst1.setInt(1, id);
		    count=pst1.executeUpdate();
		    
		  //delete from film_actors
			PreparedStatement pst4=con.prepareStatement(sql4);
			pst4.setInt(1, id);
		    count=pst4.executeUpdate();
		    
		    //insert into film_language
		  //insert into film_languages
			String sql2="insert into film_language values(?,?)";
			PreparedStatement pst2=con.prepareStatement(sql2);
		     List<Language> lang=film.getLanguages();
		     System.out.println(lang);
			for(Language lang1:lang){
			pst2.setInt(1, id);
			pst2.setInt(2,lang1.getLanguage_Id());
		    count=pst2.executeUpdate();
			}
		    
			String sql3="insert into film_actors values(?,?)";
			PreparedStatement pst3=con.prepareStatement(sql3);
		    List<Actor> actor=film.getActors();
			for(Actor act1:actor){
			pst3.setInt(1, id);
			pst3.setInt(2,act1.getActor_Id());
			 count=pst3.executeUpdate();
			}
			
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}


		try {
			con.close();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		return count;
	}





	// GET Search Film By Ids
	@Override
	public Film getSearchFilmByID(int id) {
		Connection con=getConnection();
		Film film=new Film();
		String sql="select * from FILM where filmid=?";
		
		try {
			PreparedStatement pst=con.prepareStatement(sql);
			pst.setInt(1, id);
			ResultSet rs=pst.executeQuery();
			while(rs.next()){
			/*	Film film=new Film();*/
				film.setFilm_id(rs.getInt(1));
				film.setTitle(rs.getString(2));
				film.setDescription(rs.getString(3));
				film.setReleaseYear(rs.getDate(4).valueOf(rs.getDate(4).toString()));
				//Original Language
				int lang_id=rs.getInt(5);
				Language orgLang=getOrgLang(lang_id);
				film.setOriginalLanguage(orgLang);
				
				//Rental Duration
				film.setRentalDuration(rs.getDate(6).valueOf(rs.getDate(6).toString()));
				
				//length
				film.setLength(rs.getInt(7));
				
				//replacementCost
				film.setReplacement(rs.getDouble(8));
				
				//rating
				film.setRatings(rs.getInt(9));
				
				//Special Features
				film.setSpecialFeatures(rs.getString(10));
				
				int category_id=rs.getInt(11);
				Category category=getCategoryforListing(category_id);
				film.setCategory(category);
				
				//other Lang
				List<Integer> lang_ids=getLanguagesIDs(film.getFilm_id());
				List<Language> lang_name=new ArrayList<>();
				for(Integer langid:lang_ids){
					lang_name.add(getOrgLang(langid));
				}
				film.setLanguages(lang_name);
				
				//Actors
				
				
				List<Actor> act=new ArrayList<>();
				List<Integer> actor_id=getActorIDS(film.getFilm_id());
				for(Integer actor:actor_id){
					act.add(getActors(actor));
				}
				film.setActors(act);
				/*films.add(film);*/
				
				
			}
			
			
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		try {
			con.close();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return film;
	}





	//User Login Validation
	@Override
	public boolean isValidLogin(LoginUser loginUser) {
		boolean flag=false;
		Connection con=getConnection();
		String sql="select * from logindata where username=? and pass=?";
		try {
			PreparedStatement pst=con.prepareStatement(sql);
			pst.setString(1, loginUser.getUserName());
			pst.setString(2, loginUser.getUserPwd());
			
			ResultSet rs=pst.executeQuery();
			
			if(rs.next())
				flag=true;
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		try {
			con.close();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return flag;
	}

}
