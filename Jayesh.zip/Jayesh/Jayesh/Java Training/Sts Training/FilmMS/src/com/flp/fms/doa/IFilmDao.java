package com.flp.fms.doa;

import java.util.List;
import java.util.Map;

import com.flp.fms.domain.Category;
import com.flp.fms.domain.Film;
import com.flp.fms.domain.Language;
import com.flp.fms.domain.LoginUser;

public interface IFilmDao {

	public List<Language> getLanguages();
	public List<Category> getCategory();
	public int addFilm(Film film);
	public Map<Integer, Film> searchFilms();
	public List<Film> getAllFilms();
	public int removeFilm(int id);
	public List<Film> searchFilm(Film film);
	public int updateFilm(int id,Film film);
	public Film getSearchFilmByID(int id);
	public boolean isValidLogin(LoginUser loginUser);
}
