package com.flp.fms.service;

import java.util.List;
import java.util.Map;

import com.flp.fms.doa.FilmDaoImplForList;
import com.flp.fms.doa.IFilmDao;
import com.flp.fms.domain.Category;
import com.flp.fms.domain.Film;
import com.flp.fms.domain.Language;
import com.flp.fms.domain.LoginUser;

public class FilmServiceImpl implements IFilmService{

	
	private IFilmDao filmDoa=new FilmDaoImplForList();

	public List<Language> getLanguages() {
		
		System.out.println(filmDoa.getLanguages());

		return filmDoa.getLanguages();
		
	}
	public List<Category> getCategory() {
		
		System.out.println(filmDoa.getCategory());

		return filmDoa.getCategory();
		
	}
	@Override
	public int addFilm(Film film) {
		
		//film.setFilm_id(generate_Film_Id());
		// filmDoa.addFilm(film);

		return filmDoa.addFilm(film);
	}
	
	/*
	public int generate_Film_Id(){
		
		int filmId=0;
		
		//Verify filmId has been Duplicated or not
		do{
			double fid=Math.random()*1000;
			filmId=(int)fid;
		}while(checkDuplicateFilmId(filmId));
		
		
		return filmId;
	}*/
		

	@Override
	public List<Film> getAllFilms() {
		// TODO Auto-generated method stub
		return filmDoa.getAllFilms();
	}
/*
public boolean checkDuplicateFilmId(int filmId){
		
		Set<Integer> keys= getAllFilms().keySet();
		boolean flag=false;
		if(keys.isEmpty() || keys==null){
			flag= false;
		}else{
			for(Integer key:keys){
				if(key==filmId){
					flag=true;
					break;
				}
			}
		}
		
		return flag;
		
	}*/
@Override
public Map<Integer, Film> searchFilms() {
	// TODO Auto-generated method stub
	return filmDoa.searchFilms();
}
@Override
public int removeFilm(int id) {
	// TODO Auto-generated method stub
	return filmDoa.removeFilm(id);
}
@Override
public List<Film> searchFilm(Film film) {
	// TODO Auto-generated method stub
	return filmDoa.searchFilm(film);
}
public Film getSearchFilmById(int id) {
	// TODO Auto-generated method stub
	return filmDoa.getSearchFilmByID(id);
}
public int updateFilm(int id, Film film) {
	// TODO Auto-generated method stub
	return filmDoa.updateFilm(id,film);
}
@Override
public boolean isValidLogin(LoginUser loginUser) {
	
	return filmDoa.isValidLogin(loginUser);
}


}
	

