package com.flp.fms.doa;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import com.flp.fms.domain.Actor;


public class ActorDaoImplForList implements IActorDao {


	
	/*Connection Generation*/
public Connection getConnection(){
		
		Connection connection=null;
		
		try {
			Class.forName("com.mysql.jdbc.Driver");
			connection=DriverManager.getConnection("jdbc:mysql://localhost:3306/FMSDatabase", "root", "Pass1234");
			
			
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
		
		return connection;
	} 
	
	
	
	
	//Get Actor List
	@Override
	public List<Actor> getActorList() {
		List<Actor> actor=new ArrayList<>();
		/*actors.add(new Actor(101,"Tom","Jerry"));
		actors.add(new Actor(102,"Sharuk","Khan"));
		actors.add(new Actor(103,"Kamal","Hasan"));
		actors.add(new Actor(104,"Salman","Khan"));
		actors.add(new Actor(105,"Rajni","Kant"));
		actors.add(new Actor(106,"Hrithik","Roshan"));*/
	
		
		
		
		FilmDaoImplForList filmDao=new FilmDaoImplForList();
		Connection con= filmDao.getConnection();
		
		String sql="select * from actortable";
		try {
			PreparedStatement pst=con.prepareStatement(sql);
			ResultSet rs=pst.executeQuery();
			
			while(rs.next())
			{
				Actor actor1=new Actor();
				actor1.setActor_Id(rs.getInt(1));
				actor1.setFirstName(rs.getString(2));
				actor1.setLastName(rs.getString(3));
				actor.add(actor1);
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		try {
			con.close();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return actor;
	}




	//Add Actor To the DataBase
	@Override
	public int addActor(Actor actor) {
		FilmDaoImplForList filmDao=new FilmDaoImplForList();
		Connection con=filmDao.getConnection();
		String sql="insert into actortable(CustFN,CustLN)"
				+ "	 values(?,?)";
		
		int count=0;
		try {
			PreparedStatement pst=con.prepareStatement(sql);
			pst.setString(1, actor.getFirstName());
			pst.setString(2, actor.getLastName());
			
			count=pst.executeUpdate();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		try {
			con.close();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		try {
			con.close();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return count;
	}




	//REMOVE Actor from the DataBase
	public int removeActor(int id) {
		int count=0;
		FilmDaoImplForList filmDao=new FilmDaoImplForList();
		Connection con=filmDao.getConnection();
		
		String  sql="delete from actortable where ActorId=?";
		
		try {
			PreparedStatement pst=con.prepareStatement(sql);
			pst.setInt(1, id);
			count=pst.executeUpdate();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		try {
			con.close();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return count;
	}




	//Get Actor By Ids
	public Actor getActorByID(int id) {
		
        Actor actor=new Actor();
    	FilmDaoImplForList filmDao=new FilmDaoImplForList();
		Connection con=filmDao.getConnection();
		String sql="select * from actortable where ActorId=?";
		
		try {
			PreparedStatement pst=con.prepareStatement(sql);
			pst.setInt(1, id);
			ResultSet rs=pst.executeQuery();
			
			
			while(rs.next())
			{
				actor.setFirstName(rs.getString(2));
				actor.setLastName(rs.getString(3));
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		try {
			con.close();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return actor;
	}




	//UPDATE film Logic
	public int updateFilm(Actor actor, int actorId) {
		int count=0;
		FilmDaoImplForList filmDao=new FilmDaoImplForList();
	    Connection con=filmDao.getConnection();
	    String sql="update actortable set CustFN=?,CustLN=? where ActorId=?";
	    
	    
	    try {
			PreparedStatement pst=con.prepareStatement(sql);
			pst.setString(1, actor.getFirstName());
			pst.setString(2, actor.getLastName());
			pst.setInt(3, actorId);
			
			
			count=pst.executeUpdate();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	    try {
			con.close();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	        return count;
	}




	
}

	

		
	