package com.flp.fms.util;

import static org.junit.Assert.*;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.junit.Test;

import com.flp.fms.doa.ActorDaoImplForList;
import com.flp.fms.doa.FilmDaoImplForList;
import com.flp.fms.domain.Actor;
import com.flp.fms.domain.Category;
import com.flp.fms.domain.Film;
import com.flp.fms.domain.Language;
import com.flp.fms.service.FilmServiceImpl;

public class TestCases {



	FilmDaoImplForList filmDao=new FilmDaoImplForList();
	ActorDaoImplForList actorDao=new ActorDaoImplForList();

	FilmServiceImpl filmService=new FilmServiceImpl();


	//TEST CASE FOR LIST OF LANGUAGES
	@Test
	public void testGetLanguages(){


		List<Language>languages=new ArrayList<>();

		languages.add(new Language(1, "Hindi"));
		languages.add(new Language(2, "English"));
		languages.add(new Language(3, "Telgu"));
		languages.add(new Language(4, "Marathi"));
		languages.add(new Language(5, "Malyallam"));
		
		assertEquals(languages, filmDao.getLanguages());

	}


	//GET LANGUAGE FROM ID
	@Test
	public void testGetOrgLang(){
		Language lang=new Language(0,"Hindi");
		assertEquals(lang, filmDao.getOrgLang(1));
	}
	
	
	

	//TEST CASE FOR LIST FOR CATEGORY
	@Test
	public void testGetCategory(){

		List<Category> category=new ArrayList<>();

		category.add(new Category(1, "Romantic"));
		category.add(new Category(2, "Action"));
		category.add(new Category(3, "Horror"));
		category.add(new Category(4, "Comedy"));
		category.add(new Category(5, "Adventures"));
	
		assertEquals(category, filmDao.getCategory());

	}
	

	//TEST CASE FOR CATEGORY to check null	
@Test
public void isCategoryObjectIsNull() {
	
	Category category=null;
	assertNotEquals(category, filmService.getCategory());
	
} 


//TEST CASE FOR CATEGORY valid or not	
@Test
public void isNotValidCategory() {
	
	Category category=new Category(20,"ABC");
	assertNotEquals(category,filmService.getCategory());
	
}
	
	
	
	

	//TEST CASE FOR ACTOR LIST
	@Test
	public void testGetActor(){
		List<Actor> actor=new ArrayList<>();

		actor.add(new Actor(1, "Shahid", "Kapoor"));
		actor.add(new Actor(3, "Ranbir", "Kapoor"));
		actor.add(new Actor(4, "Amitabh", "Bacchan"));
		actor.add(new Actor(5, "Rajesh", "Khanna"));
		actor.add(new Actor(6, "Rajikanth", "Gaikwad"));
	
		assertEquals(actor, actorDao.getActorList());

	}


	//TEST CASE FOR ADD FILM
	@Test
	public void testAddFilm(){

		Film film=new Film();
		film.setTitle("The notebook");
		film.setDescription("abcd");
		Date d=new Date("12-apr-2016");
		film.setReleaseYear(d);
		Language lang=new Language();
		lang.setLanguage_Id(1);
		film.setOriginalLanguage(lang);
		Date d1=new Date("13-apr-2017");
		film.setRentalDuration(d1);
		film.setLength(11);
		film.setReplacement(1111);
		film.setRatings(2);
		film.setSpecialFeatures("asdfg");
		Category category=new Category();
		category.setCategory_Id(1);
		film.setCategory(category);

		List<Language> langs=new ArrayList<>();
		Language lang1=new Language();
		lang1.setLanguage_Id(2);
		langs.add(lang);
		langs.add(lang1);
		film.setLanguages(langs);

		List<Actor> actors=new ArrayList<>();
		Actor actor1=new Actor();
		actor1.setActor_Id(1);
		Actor actor2=new Actor();
		actor2.setActor_Id(2);
		actors.add(actor1);
		actors.add(actor2);
		film.setActors(actors);
		assertEquals(1,filmDao.addFilm(film));
	}

/*
	//TEST CASE FOR DELETE FILM
	@Test
	public void testFilmDeleted(){

    	assertEquals(2,filmDao.removeFilm(5));
	}
	 

*/


	//UPDATE FILM
	@Test
	public void testUpdateFilm(){

		Film film=new Film();
		film.setFilm_id(5);
		film.setTitle("The notebook");
		film.setDescription("aaaa");
		Date d=new Date("15-apr-2016");
		film.setReleaseYear(d);

		Language lang=new Language();
		lang.setLanguage_Id(1);
		film.setOriginalLanguage(lang);
		Date d1=new Date("13-may-2016");
		film.setRentalDuration(d1);
		film.setLength(11);
		film.setReplacement(1111);
		film.setRatings(2);
		film.setSpecialFeatures("asdfg");
		Category category=new Category();
		category.setCategory_Id(1);
		film.setCategory(category);

		List<Language> langs=new ArrayList<>();
		Language lang1=new Language();
		lang1.setLanguage_Id(2);
		langs.add(lang);
		langs.add(lang1);
		film.setLanguages(langs);

		List<Actor> actors=new ArrayList<>();
		Actor actor1=new Actor();
		actor1.setActor_Id(1);
		Actor actor2=new Actor();
		actor2.setActor_Id(2);
		actors.add(actor1);
		actors.add(actor2);
		film.setActors(actors);

		assertEquals(1, filmDao.updateFilm(15, film));


	}
	

//Test Case for film Present or not	
	@Test
	public void isFilmNotPresent()
	{
		 List<Film> films=filmService.getAllFilms();
		 Film film1=new Film();
		 for(Film film:films)
			 film1=film;
        assertNotEquals(film1, filmService.searchFilm(film1));
	}
	

	
	//Test Case for film Object is null or not
	@Test
	public void filmObjectIsNullWhenSearchById()
	{
		 Film film=null;
        assertNotEquals(film, filmService.getSearchFilmById(1));
	}
	

	
	
	

	//GET ACTOR NAME THROUGH ACTORID
	@Test
	public void testGetActors(){
		Actor actor=new Actor(0,"Shahid","Kapoor");
		
		assertEquals(actor, filmDao.getActors(1));
	}

	


	//Actor Test For Null
	@Test
	public void isActorObjectIsNull() {
		
		Actor actor=null;
		assertNotEquals(actor, actorDao.getActorByID(50));
		
	} 
	
	//Actor TEst For No Duplicate value
	@Test
	public void noDuplicateActorEntry() {
	
		Actor actor=new Actor(1,"Shahid","Kapoor");
		assertNotEquals(actor, actorDao.getActorByID(2));
		
	}
	
	//ACtor test For valid
	@Test
	public void isNotValidActor() {
		
		Actor actor=new Actor(15,"ABC","XYZ");
		assertNotEquals(actor, actorDao.getActorByID(15));
		}
}
