package com.flp.fms.domain;

public class Category {

	  //Private Fields
	private int category_Id;
	private String category_name;

//No Argument Constructor	
public Category(){}

//Argument Constructor	
public Category(int category_Id,String category_name){
	super();
		this.category_Id=category_Id;
		this.category_name=category_name;
}

//Getters and Setters
public int getCategory_Id() {
	return category_Id;
}

public void setCategory_Id(int category_Id) {
	this.category_Id = category_Id;
}

public String getcategory_name() {
	return category_name;
}

public void setCategory_name(String category_name) {
	this.category_name = category_name;
}




@Override
public int hashCode() {
	final int prime = 31;
	int result = 1;
	result = prime * result + category_Id;
	result = prime * result + ((category_name == null) ? 0 : category_name.hashCode());
	return result;
}

@Override
public boolean equals(Object obj) {
	if (this == obj)
		return true;
	if (obj == null)
		return false;
	if (getClass() != obj.getClass())
		return false;
	Category other = (Category) obj;
	if (category_Id != other.category_Id)
		return false;
	if (category_name == null) {
		if (other.category_name != null)
			return false;
	} else if (!category_name.equals(other.category_name))
		return false;
	return true;
}

@Override
public String toString() {
	return "Category [category_Id=" + category_Id + ", categoryName=" + category_name + "]";
}





}