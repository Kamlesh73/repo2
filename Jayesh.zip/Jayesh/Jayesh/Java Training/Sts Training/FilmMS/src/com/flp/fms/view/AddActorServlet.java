package com.flp.fms.view;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class AddActorServlet
 */
public class AddActorServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

		
		PrintWriter out=response.getWriter();
		
		/*HTML Page For ADDITIOn of Actor:*/
		
		out.print("<html>");
		out.print("<head>");
		out.print("<script type='text/javascript' src='scripts/validate.js'></script>"
				+ " <link rel='stylesheet' type='text/css' href='../css/myStyle.css'>");
		out.print("</head>");
		
		out.print("<body>");
		out.print("<form name='actor' method='post' action='AddingActor'>");
		out.print("<center><font size='5' color='white'>Add Actor</font></center>"
				+ "<br>");
		
		out.println("<center> "
				+ "<table border=2px style='color:white'>"
				+ "<tr>"
				+ "<td><label>First Name</label></td>"
				+ "<td>:</td>"
				+ "<td><input type='text' name='FName' >"
				+ "<div id='fNameErr'></div>"
				+ "</td>"
				+ "</tr>");
		out.println("<tr>"
				+ "<td><label>Last Name</label></td>"
				+ "<td>:</td>"
				+ "<td><input type='text' name='LName'>"
				+ "<div id='lNameErr'></div>"
				+ "</td>"
				+ "</tr>");
		
		out.print("<tr><td></td>"
				+ "<td><input type='submit' value='Submit'</td>"
				+ "</tr>");
				
		out.print("</table>"
				+ "</center>"
				+ "</body>"
				+ "</html");
	}

}


