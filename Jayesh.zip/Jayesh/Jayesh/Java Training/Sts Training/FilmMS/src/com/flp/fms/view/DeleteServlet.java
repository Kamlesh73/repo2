package com.flp.fms.view;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.flp.fms.domain.Actor;
import com.flp.fms.domain.Film;
import com.flp.fms.domain.Language;
import com.flp.fms.service.FilmServiceImpl;

/**
 * Servlet implementation class DeleteServlet
 */
public class DeleteServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public DeleteServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		PrintWriter out=response.getWriter();
		
		/*out.println("<head>");
		out.print("<link rel='stylesheet' type='text/css' href='css/mystyles.css'>");
		out.println("</head>");
		out.print("<body>");
		out.print("Add");
		out.print("</body>");*/
		
		FilmServiceImpl filmservice=new FilmServiceImpl();
		List<Film> film=filmservice.getAllFilms();
		
		
/*	HTML Page for Delete film from list of films:*/

		out.println("<head>");
		out.println("<link rel='stylesheet' type='text/css' href='../css/myStyle.css'>");
		out.println("</head>");
		
		
		out.println("<body>"
			/*	+ "<form action='DeleteServlet1' method='post'>"*/
				+ "<center><font size='5' color='white'> List Of Films To Be Deleted</font></center>"
				+ "<table border=2px style='color:white'>"
				+ "<tr>"
				+ "<th>Film Id</th>"
				+ "<th>Title</th>"
				+ "<th>Description</th>"
				+ "<th>Release Year</th>"
				+ "<th>Original Language</th>"
				+ "<th>Languages</th>"
				+ "<th>Rental Duration</th>"
				+ "<th>Length</th>"
				+ "<th>Replacement Cost</th>"
				+ "<th>Ratings</th>"
				+ "<th>Special Features</th>"
				+ "<th>Actors</th>"
				+ "<th>Category</th>"
				+ "<th>Delete</th>"
				+ "</tr>");
		for(Film film1:film){
			List<Language> languages=film1.getLanguages();
			
			String langs="";
			for(Language lang:languages)
			{
				langs=langs+lang.getLanguageName()+",";
			}
			
			List<Actor> actors=film1.getActors();
			String actors1="";
			for(Actor actor:actors)
			{
				actors1=actors1+actor.getFirstName()+" "+actor.getLastName()+",";
			}
			out.println("<tr>");
			out.println("<td>"+film1.getFilm_id()+"</td>");
			out.println("<td>"+film1.getTitle()+"</td>");
			out.println("<td>"+film1.getDescription()+"</td>");
			out.println("<td>"+film1.getReleaseYear()+"</td>");
			out.println("<td>"+film1.getOriginalLanguage().getLanguageName()+"</td>");
			out.println("<td>"+langs+"</td>");
			out.println("<td>"+film1.getRentalDuration()+"</td>");
			out.println("<td>"+film1.getLength()+"</td>");
			out.println("<td>"+film1.getReplacement()+"</td>");
			out.println("<td>"+film1.getRatings()+"</td>");
			out.println("<td>"+film1.getSpecialFeatures()+"</td>");
			out.println("<td>"+actors1+"</td>");
			out.println("<td>"+film1.getCategory().getcategory_name()+"</td>");
			out.print("<td><a href='DeleteServletRef?id="+film1.getFilm_id()+"'><h5 style='color:#E45E9D;''>Delete</h5></a></td>");
			out.println("</tr>");
		}
			out.println("</table></body>");
	}


	}



