package com.flp.fms.view;

import java.io.IOException;

import java.io.PrintWriter;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.flp.fms.domain.Actor;
import com.flp.fms.domain.Category;
import com.flp.fms.domain.Language;
import com.flp.fms.service.ActorServiceImpl;
import com.flp.fms.service.FilmServiceImpl;

/**
 * Servlet implementation class UserInteractionServlet
 */
public class UserInteractionServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
	private Object languages;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public UserInteractionServlet() {
        super();
        // TODO Auto-generated constructor stub
    }



	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		PrintWriter out=response.getWriter();
		
		
		FilmServiceImpl filmService=new FilmServiceImpl();
		ActorServiceImpl actorService=new ActorServiceImpl();
		
		List<Actor> actor=actorService.getActorList();
		List<Language> languages=filmService.getLanguages();
		List<Category> category=filmService.getCategory();
	
		
		//	HTML Page for ADDITION of Film	//
		
		
		out.println("<html align='center'>");
		out.println("<head>");
	/*	out.println("<link rel='stylesheet' href='//code.jquery.com/ui/1.11.4/themes/smoothness/jquery-ui.css'>");
		out.println("<script src='//code.jquery.com/jquery-1.10.2.js'></script>");
		out.println("<script src='//code.jquery.com/ui/1.11.4/jquery-ui.js'></script>");
		out.println("<script>");
			out.println("$(function() {$( '#datepicker' ).datepicker({  maxDate: '0'});});");
		out.println("</script>");
		out.println(" <script>");
			out.println(" $(function() { $( '#datepicker1' ).datepicker();});");
		out.println("</script>");*/
		out.print("<link rel='stylesheet' href='//code.jquery.com/ui/1.11.4/themes/smoothness/jquery-ui.css'>"
				+ "<script src='//code.jquery.com/jquery-1.10.2.js'></script>"
				+"<script src='//code.jquery.com/ui/1.11.4/jquery-ui.js'></script>"
				+ "<link rel='stylesheet' type='text/css' href='css/myStyle.css'>"
			
				/*+ "<link rel='stylesheet' type='text/css' href='css/jquery-ui-1.9.2.custom.css'>"
				+ "<link rel='stylesheet' type='text/css' href='css/jquery-ui-1.9.2.custom.min.css'>"
				+ "<link rel='stylesheet' type='text/css' href='css/jquery-ui-1.9.2.custom.min.css'>"*/
				+ "<script type='text/javascript' src='scripts/jquery-1.8.3.js'></script>"
				+ "<script type='text/javascript' src='scripts/jquery-ui-1.9.2.custom.js'></script>"
				+ "<script type='text/javascript' src='scripts/jquery-ui-1.9.2.custom.min.js'></script>"
				+ "<script type='text/javascript' src='script/validate.js'></script>"
				+"<script type='text/javascript' src='script/datepicker.js'></script>"
				+"<script type='text/javascript' src='script/s.js'></script>");
		//out.println("<script type='text/javascript' src='script/validate.js'></script>");
		out.println("<title>Film Details</title>");
		out.println("</head>");

		out.println("<body bgcolor='#E6E6FA'>");

		
		// GO to AddFilm Servlet For Storing data//
		out.println("<form align='center' name='filmf' method='get' action='AddFilmServlet' onsubmit='return validateForm()'>");

		out.println("<font size='5' color='white'> Film Registration Form</font>");
		out.print("<center>"
				+ "<table style='color:#B6B6B4'>");


		out.println("<tr>"
			+"<td>FilmTitle:</td>"
			+"<td><input type='text' name='filmtitle' size='20'><div id='titleerr' class='errMsg'> </div></td>"
			+"</tr>"
			+"<tr>");
			
			
		out.println("<tr>"
			+"<td>Film Description:</td>"
			+"<td>"
			+"<textarea rows='4' name='filmdescription' cols='25'></textarea>"
			+"<div id='descerr' class='errMsg'> </div> "
			+"</td>"
			+"</tr>");
			
			
			
			out.println("<tr>"
			+"<td>Release Date:</td>"
			+"<td>"
			+"<input type='text' name='releasedate' size='20' id='dateSelection'>"
			+ "<div id='relasedatrr' class='errMsg'> </div>"
			+"</td>"
			+"</tr>");
			
			
			out.println("<tr>"
			+"<td>FilmLength:</td>"
			+"<td><input type='text' name='filmlength' size='20' >"
			+"<div id='lenghterr' class='errMsg'> </div>"
			+"</td>"
			+"</tr>");
			
			
			
			out.println("<tr>"
			+"<td>Rental Duration:</td>"
			+"<td>"
			+ "<input type='text' name='rentalduration' size='20' id='dateSelection1'>"
			+"<div id='rentaldurationerr' class='errMsg'> </div>"
			+ "</td>"
			+"</tr>");
			
			out.println("<tr>"
			+"<td>Replacement Cost:</td>"
			+"<td><input type='text' name='replacementcost' size='20'><div id='replacementcosterr' class='errMsg'> </div>"
			+"</tr>");
			
			
			out.println("<tr>"
				+"<td>Film Rating:</td>"
				+"<td>"
				+"<select name='rating'>"
					+"<option value='1'>1</option>"
					+"<option value='2'>2</option>"
					+"<option value='3'>3</option>"
					+"<option value='4'>4</option>"
					+"<option value='5'>5</option>"
				+"</select>"
				+"<div id='rating' class='errMsg'> </div>"
				
				+"</td>"
			+"</tr>");
			
			
			
			out.println("<tr>"
			+"<td>Special Features:</td>"
			+"<td>"
				+"<textarea rows='4' name='specialfeature' cols='25'></textarea>"
			+"</td>"
			+"</tr>"
			+"<br>");
			
			/*
			out.println("<tr>"
				+"<td>Actor:</td>"
				+"<td>"
				+"<select name='actor'>"
					+"<option value='Vidyut'>Vidyut</option>"
					+"<option value='Salman'>Salman</option>"
					+"<option value='Sharukh'>Sharukh</option>"
					+"<option value='Ajay'>Ajay</option>"
					+"<option value='Amir'>Amir</option>"
				+"</select>"
				
				+"</td>"
			+"</tr>");*/
			
			out.print("<tr><td>Actor:</td>"
					+ "<td><select name='actor' multiple=''>"
					+ "<option value''>Select actors</option>");
			for(Actor actor1:actor){
				out.print("<option value='"+actor1.getActor_Id()+"'>"+actor1.getActor_Id()+" "+actor1.getFirstName()+" "+actor1.getLastName()+"</option>");
			}
			out.print("</select></td></tr>");
					
			out.print("<tr><td>Original Language:</td>"
					+ "<td><select name='orgLang'>");
			for(Language lang:languages){
					out.print("<option value='"+lang.getLanguage_Id()+"'>"+lang.getLanguage_Id()+" "+lang.getLanguageName()+"</option>");
				}
		out.print("</select></td></tr>");
		out.println("<br>");
			
	/*		out.println("<tr>"
				+"<td>Other Language:</td>"
				+"<td>"
				+"<select name='otherlanguage' multiple=''>"
					+"<option value='Marathi'>Marathi</option>"
					+"<option value='Hindi'>Hindi</option>"
					+"<option value='English'>English</option>"
					+"<option value='Gujrati'>Gujrati</option>"
					+"<option value='Malyalam'>Malyalam</option>"
				+"</select>"
				
				+"</td>"
			+"</tr>");*/
			
		out.print("<tr><td>Other Language:</td>"
				+ "<td><select name='otherlanguage' multiple=''>");
		for(Language lang:languages){
				out.print("<option value='"+lang.getLanguage_Id()+"'>"+lang.getLanguage_Id()+" "+lang.getLanguageName()+"</option>");
			}
	out.print("</select></td></tr>");
	out.println("<br>");
			
			/*out.println("<tr>"
				+"<td>Category:</td>"
				+"<td>"
				+"<select name='category'>"
					+"<option value='Action'>Action</option>"
					+"<option value='Drama'>Drama</option>"
					+"<option value='Comedy'>Comedy</option>"
					+"<option value='Horror'>Horror</option>"
					+"<option value='Animation'>Animation</option>"
				+"</select>"
				
				+"</td>"
			+"</tr>");*/
			
			
			out.print("<tr><td>Category:</td>"
					+ "<td><select name='category'>");
			for(Category category1:category){
				out.print("<option value='"+category1.getCategory_Id()+"'>"+category1.getCategory_Id()+" "+category1.getcategory_name()+"</option>");
			}
		out.print("</select></td></tr>");
				
			
			
			out.println("<tr>"
				+"<td></td>"
				+"<td><input type='submit' value='Save'>"
				+"<input type='reset' value='Clear'>"
				 +"</td>"
			+"</tr>");
			
	out.println("</table>"
			+ "</center>");


		out.println("</form>");


		out.println("</body>");
		out.println("</html>");

		
		
		
		
	}

}
