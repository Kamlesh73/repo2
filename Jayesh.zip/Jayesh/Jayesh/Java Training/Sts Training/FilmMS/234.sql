USE myServlet;


CREATE TABLE Address(addId INT(25), door_no VARCHAR(25), st_Name VARCHAR(25), city VARCHAR(25),state VARCHAR(25) );


INSERT INTO Address(addId, door_no,st_Name,city,state)VALUES(101,"21","Mahamarg","Pune","Maharashtra");
INSERT INTO Address(addId, door_no,st_Name,city,state)VALUES(102,"22","Rajmarg","Delhi","Delhi");
INSERT INTO Address(addId, door_no,st_Name,city,state)VALUES(103,"23","Swarajmarg","Lucknow","UP");
INSERT INTO Address(addId, door_no,st_Name,city,state)VALUES(104,"24","Maharajmarg","Chandigarh","Punjab");
INSERT INTO Address(addId, door_no,st_Name,city,state)VALUES(105,"25","Zansimarg","Hyderabad","AP");

SELECT*FROM Address;