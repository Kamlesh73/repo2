SELECT * FROM actortable;

SELECT * FROM category;
SELECT * FROM category;