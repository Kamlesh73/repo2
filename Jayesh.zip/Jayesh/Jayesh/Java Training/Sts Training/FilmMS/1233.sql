USE fmsdatabase;

CREATE TABLE logindata(username VARCHAR(25) PRIMARY KEY, pass VARCHAR(25));


INSERT INTO logindata ( username ,pass)VALUES	('Jayesh','12345');
INSERT INTO logindata ( username ,pass)VALUES	('Mayur','23456');
INSERT INTO logindata ( username ,pass)VALUES	('Akash','34567');
INSERT INTO logindata ( username ,pass)VALUES	('Kamlesh','45678');
INSERT INTO logindata ( username ,pass)VALUES	('Ashish','56789');


SELECT*FROM logindata;