package org.capgemini;

import java.util.Scanner;

public class TablePrint implements Runnable {
	
private int num;
	
	public TablePrint(int num){
		this.num=num;
	}
	Scanner sc=new Scanner (System.in);
	
public void printTable(){
		
		for(int i=1;i<=20;i++)
			System.out.println( Thread.currentThread().getName() +"-->"+ i+"*"+num+"="+(i*num));
	}

	
	public void run() {
		printTable();
		
	}

	


} 


