package org.capgemini;

public class ThreadString extends Thread{

	private String ThreadInputString;
	
	public ThreadString(String ThreadInputString){
		this.ThreadInputString=ThreadInputString;
	}
	
	
	@Override
	public void run(){
		for(int i=0;i<ThreadInputString.length();i++)
			System.out.println(ThreadInputString.substring(0, i));
		
	}
}
