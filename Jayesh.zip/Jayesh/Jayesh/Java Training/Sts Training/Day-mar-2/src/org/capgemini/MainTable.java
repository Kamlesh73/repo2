package org.capgemini;

public class MainTable {

	public static void main(String[] args) {
		
		TablePrint table1=new TablePrint(10);
		TablePrint table2=new TablePrint(13);
		TablePrint table3=new TablePrint(19);
		TablePrint table4=new TablePrint(12);

		
		Thread t1=new Thread(table1);
		Thread t2=new Thread(table2);
		Thread t3=new Thread(table3);
		Thread t4=new Thread(table4);
		
		
		t1.start();
		
		try {
			t1.join();
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		t2.start();
		try {
			t2.join();
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		t3.start();
		t4.start();
		
		
	}
	}


