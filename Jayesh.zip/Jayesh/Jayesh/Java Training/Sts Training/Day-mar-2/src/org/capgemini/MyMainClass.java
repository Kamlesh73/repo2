package org.capgemini;

public class MyMainClass {

	public static void main(String []args){
		
		ThreadString t1=new ThreadString("Capgemini");
		ThreadString t2=new ThreadString("Welcome");
		t1.start();
		t2.start();
	}
}
