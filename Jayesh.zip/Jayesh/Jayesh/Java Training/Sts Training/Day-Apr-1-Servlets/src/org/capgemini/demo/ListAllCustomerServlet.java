package org.capgemini.demo;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.capgemini.pojo.Customer;
import org.capgemini.service.LoginService;
import org.capgemini.service.LoginServiceImpl;


public class ListAllCustomerServlet extends HttpServlet {
	
	private static final long serialVersionUID = 1L;


	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
	
		LoginService loginService=new LoginServiceImpl();
		
		ArrayList<Customer> customers=loginService.getAllCustomers();
		
		PrintWriter out=response.getWriter();
		
		out.println("<html>");
		out.println("<head>List All Customer</head>"
				+ "<body>"
				+ "<table  border='2' cellPadding='10px'>"
				+ "<tr>"
				+ "<th>Customer Id</th>"
				+ "<th>FirstName</th>"
				+ "<th>LastName</th>"
				+ "<th>Address</th>"
				+ "<th>Registration Date</th>"
				+ "<th>Fees</th>"
				+ "<th>Customer Type</th>"
				+ "<th>Gendar</th>"
				+ "</tr>");
		
			for(Customer cust:customers){
				out.println("<tr>");
				out.println("<td>"+cust.getCustId()+"</td>");
				out.println("<td>"+cust.getCustFN()+"</td>");
				out.println("<td>"+cust.getCustLN()+"</td>");
				out.println("<td>"+cust.getAddress()+"</td>");
				out.println("<td>"+cust.getRegDate()+"</td>");
				out.println("<td>"+cust.getFees()+"</td>");
				out.println("<td>"+cust.getCustomerType()+"</td>");
				out.println("<td>"+cust.getGendar()+"</td>");
				out.println("</tr>");
			}
				out.println("</table></body>");
	
				out.println("</html>");
		
		
		
		
		
	}

}
