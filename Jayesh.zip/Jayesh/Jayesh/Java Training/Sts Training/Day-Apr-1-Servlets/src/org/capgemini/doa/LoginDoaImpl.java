package org.capgemini.doa;

import java.sql.Connection;
import java.sql.Date;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

import org.capgemini.pojo.Customer;
import org.capgemini.pojo.LoginUser;

public class LoginDoaImpl implements LoginDoa {

public Connection getConnection(){
		
		Connection connection=null;
		
		try {
			Class.forName("com.mysql.jdbc.Driver");
			connection=DriverManager.getConnection("jdbc:mysql://localhost:3306/myServlet", "root", "Pass1234");
			
			
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
		
		return connection;
	} 
	@Override
	public boolean isValidLogin(LoginUser loginUser) {
		boolean flag=false;
		Connection con=getConnection();
		String sql="select * from LoginData where username=? and pass=?";
		try {
			PreparedStatement pst=con.prepareStatement(sql);
			pst.setString(1, loginUser.getUserName());
			pst.setString(2, loginUser.getUserPwd());
			
			ResultSet rs=pst.executeQuery();
			
			if(rs.next())
				flag=true;
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
		
		return flag;
	
	}
	
	
	@Override
	public void saveCustomer(Customer customer) {
		
		Connection con=getConnection();
		
		String sql="insert into Customer(CustFN,CustLN,Address,RegistrationDate,Fees,CustomerType,Gendar)"
				+"values(?,?,?,?,?,?,?)";
		
		try {
			PreparedStatement pst=con.prepareStatement(sql);
		pst.setString(1, customer.getCustFN());
		pst.setString(2, customer.getCustLN());
		pst.setString(3, customer.getAddress());
		pst.setDate(4, new Date(customer.getRegDate().getTime()));
		pst.setDouble(5, customer.getFees());
		pst.setString(6, customer.getCustomerType());
		pst.setString(7, customer.getGendar());
		
			int count=pst.executeUpdate();
			
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
		
		
	}
	@Override
	public ArrayList<Customer> getAllCustomers() {
		
		ArrayList<Customer> customers=new ArrayList<>();
		
		String sql="Select * From customer";
		Connection con=getConnection();

			try {
				PreparedStatement pst=con.prepareStatement(sql);
				
				ResultSet rs=pst.executeQuery();
				
				while(rs.next()){
					
					Customer cust=new Customer();
					
					
					cust.setCustId(rs.getInt(1));
					cust.setCustFN(rs.getString(2));
					cust.setCustLN(rs.getString(3));
					cust.setAddress(rs.getString(4));
					cust.setRegDate(rs.getDate(5).valueOf(rs.getDate(5).toString()));
					cust.setFees(rs.getDouble(6));
					cust.setCustomerType(rs.getString(7));
					cust.setGendar(rs.getString(8));
					
					customers.add(cust);
					
				}
				
							
				
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		
		
		return customers;
	}
	@Override
	public boolean deleteCustomer(int CustId) {
		Connection con=getConnection();
		boolean flag=false;
		String sql="delete from employee where empid=?";
		
		try {
			PreparedStatement pst=con.prepareStatement(sql);
			pst.setInt(1, CustId);
	
			int count=pst.executeUpdate();
			
			if(count>0)
				flag=true;
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
		return false;
	}
	
	/*
	public ArrayList<Customer> search(int id)
	{
		ArrayList<Customer> customer=new ArrayList<>();
		
		String sql="select * from customer_details where cust_Id ="+"?";
		Connection con=getConnection();
		try {
			
			PreparedStatement pst=con.prepareStatement(sql);
			pst.setInt(1, id);
			
			ResultSet rs=pst.executeQuery();
			
			
				
				while(rs.next())
				{
				Customer cst=new Customer();
				cst.setCustId(rs.getInt(1));
						
				}
		}
		catch(Exception e){}
		return customer;
	}
		*/

	

		

	}


