package org.capgemini.demo;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.capgemini.pojo.Customer;
import org.capgemini.service.LoginService;
import org.capgemini.service.LoginServiceImpl;

/**
 * Servlet implementation class SearchCustomerServlet
 */
public class SearchCustomerServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public SearchCustomerServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

		
		
		LoginService loginService=new LoginServiceImpl();
		int custId=Integer.parseInt(request.getParameter("CustId"));
		ArrayList<Customer> customersList=loginService.getAllCustomers();
		//Customer customer=new Customer();
		PrintWriter pw=response.getWriter();
		
		pw.print("<table border='1'><tr><th>ID</th><th>FN</th><th>LN</th><th>ADD</th><th>DATE</th><th>FEES</th><th>TYPE</th><th>GENDER</th></tr>");
		
		for(int i=0;i<customersList.size();i++){
			Customer customer=customersList.get(i);	
			if(customer.getCustId()==custId){
				pw.print("<tr><td>"+customer.getCustId()+ "</td><td>"+ customer.getCustFN() + "</td><td>" +customer.getCustLN() + "</td><td>" +customer.getAddress() +
						"</td><td>"+customer.getRegDate()+ "</td><td>"+ customer.getFees()+"</td><td>"+customer.getCustomerType()+"</td><td>"+customer.getGendar()+"</td></tr>" );	
				
			}
			
			
			
		}
		
		pw.print("</table>");		
		
	}

	

}
