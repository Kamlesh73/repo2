package org.capgemini.doa;

import java.util.ArrayList;

import org.capgemini.pojo.Customer;
import org.capgemini.pojo.LoginUser;

public interface LoginDoa {

	public boolean isValidLogin(LoginUser loginUser);
	public void saveCustomer(Customer customer);
	public ArrayList<Customer> getAllCustomers();

/*	public ArrayList<Customer> search(int id);*/
	public boolean deleteCustomer(int CustId);
}
