package org.capgemini.service;

import java.util.ArrayList;


import org.capgemini.doa.LoginDoa;
import org.capgemini.doa.LoginDoaImpl;
import org.capgemini.pojo.Customer;
import org.capgemini.pojo.LoginUser;

public class LoginServiceImpl implements LoginService {

	
	LoginDoa loginDoa=new LoginDoaImpl();
	
	
	@Override
	public boolean isValidLogin(LoginUser loginUser) {
		
	//if(loginUser.getUserName().equals("jayesh")&&loginUser.getUserPwd().equals("jay123"))
		
		return loginDoa.isValidLogin(loginUser);
		
	}


	@Override
	public void saveCustomer(Customer customer) {
		  loginDoa.saveCustomer(customer);
		
	}
 

	@Override
	public ArrayList<Customer> getAllCustomers() {
		
		return loginDoa.getAllCustomers();
	}


	@Override
	public boolean deleteCustomer(int CustId) {
		// TODO Auto-generated method stub
		return loginDoa.deleteCustomer(CustId);
	}

/*
	public ArrayList<Customer> search(int id)
	{
		
		
		return loginDoa.search(id);
		
	}
*/


	
	
	
	
	

}
