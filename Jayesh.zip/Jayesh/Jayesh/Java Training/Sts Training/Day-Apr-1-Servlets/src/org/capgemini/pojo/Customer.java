package org.capgemini.pojo;

import java.util.Date;

public class Customer {

	private int custId;
	private String custFN;
	private String custLN;
	private String address;
	private Date regDate;
	private Double fees;
	private String CustomerType;
	private String gendar;
	
	public Customer(){}

	public Customer(int custId, String custFN, String custLN, String address, Date regDate, Double fees,
			String customerType, String gendar) {
		super();
		this.custId = custId;
		this.custFN = custFN;
		this.custLN = custLN;
		this.address = address;
		this.regDate = regDate;
		this.fees = fees;
		CustomerType = customerType;
		this.gendar = gendar;
	}

	public int getCustId() {
		return custId;
	}

	public void setCustId(int custId) {
		this.custId = custId;
	}

	public String getCustFN() {
		return custFN;
	}

	public void setCustFN(String custFN) {
		this.custFN = custFN;
	}

	public String getCustLN() {
		return custLN;
	}

	public void setCustLN(String custLN) {
		this.custLN = custLN;
	}

	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
	}

	public Date getRegDate() {
		return regDate;
	}

	public void setRegDate(Date regDate) {
		this.regDate = regDate;
	}

	public Double getFees() {
		return fees;
	}

	public void setFees(Double fees) {
		this.fees = fees;
	}

	public String getCustomerType() {
		return CustomerType;
	}

	public void setCustomerType(String customerType) {
		CustomerType = customerType;
	}

	public String getGendar() {
		return gendar;
	}

	public void setGendar(String gendar) {
		this.gendar = gendar;
	}

	@Override
	public String toString() {
		return "Customer [custId=" + custId + ", custFN=" + custFN + ", custLN=" + custLN + ", address=" + address
				+ ", regDate=" + regDate + ", fees=" + fees + ", CustomerType=" + CustomerType + ", gendar=" + gendar
				+ "]";
	}
	
	
	
	
	
	
	
	
	
	
}	
