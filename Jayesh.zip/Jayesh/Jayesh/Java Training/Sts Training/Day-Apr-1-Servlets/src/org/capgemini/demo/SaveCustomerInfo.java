package org.capgemini.demo;

import java.io.IOException;

import java.util.Date;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.capgemini.pojo.Customer;
import org.capgemini.service.LoginService;
import org.capgemini.service.LoginServiceImpl;

/**
 * Servlet implementation class SaveCustomerInfo
 */
public class SaveCustomerInfo extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public SaveCustomerInfo() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.getWriter().append("Served at: ").append(request.getContextPath());
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		LoginService loginService=new LoginServiceImpl();
		
		Customer customer=new Customer();
		
		

		customer.setCustFN(request.getParameter("fname"));
		customer.setCustLN(request.getParameter("lname"));
		customer.setAddress(request.getParameter("address"));
		
		String rdate=request.getParameter("regDate");
		Date registrationdate=new Date(rdate);
		customer.setRegDate(registrationdate);
		
		double fee=Double.parseDouble(request.getParameter("fees"));
		customer.setFees(fee);
		
		String custtype=request.getParameter("CustomerType");
		customer.setCustomerType(custtype);
		
		customer.setGendar(request.getParameter("gendar"));
		
		System.out.println(customer);
		
		
		//Persist employee Object into DataBase
				loginService.saveCustomer(customer);
				

				//response.sendRedirect("SaveEmployeeServlet");
				request.getRequestDispatcher("pages/customer.html").forward(request, response);	
				
		
	}

}
