package org.capgemini;

public class Mainclass {

	public static void main(String[] args) {
		String publisherName;
		String publishedDate;
		Publisher(publisherName="hahha",publishedDate="12-feb-2016");
		Book book=new Book(1001,"Java Complete", 1200);
	}

	

}
