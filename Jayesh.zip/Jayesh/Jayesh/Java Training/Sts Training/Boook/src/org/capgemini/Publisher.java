package org.capgemini;

import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.Target;

import javax.lang.model.element.Element;

@Target({ElementType.TYPE,ElementType.FIELD,ElementType.LOCAL_VARIABLE})
@Retention(RetentionPolicy.CLASS)
public @interface Publisher {
	
	String publisherName() default "Tata";
	String publishedDate();
	double price();

}
