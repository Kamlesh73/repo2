package org.capgemini;



public class Book {
	
		@Publisher(publisherName="Java",publishedDate="22-jan-2000", price = 12000)
		private int bookId; 
		private String bookName;
		private double price;
		
		public Book(){}
		
		
		public Book (int bookId,String bookName,double price){
			super();
			this.bookId=bookId;
			this.bookName=bookName;
			this.price=price;
		}


		public int getBookId() {
			return bookId;
		}


		public void setBookId(int bookId) {
			this.bookId = bookId;
		}


		public String getBookName() {
			return bookName;
		}

		@Publisher(publisherName="tom",publishedDate="22-feb-2016")
		public void setBookName(String bookName) {
			this.bookName = bookName;
		}


		public double getPrice() {
			return price;
		}

		@Publisher(publisherName="tom",publishedDate="22-feb-2016")
		public void setPrice(double price) {
			this.price = price;
		}

	

}
