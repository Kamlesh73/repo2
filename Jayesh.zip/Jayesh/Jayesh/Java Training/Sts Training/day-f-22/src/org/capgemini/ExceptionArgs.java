package org.capgemini;

public class ExceptionArgs {

	public static void main(String[] args) {
	
		try{
			// args is the string 
			//converted to integer by parseint
			if(args.length==2){
			int num1=Integer.parseInt(args[0]);
			int num2=Integer.parseInt(args[1]);
				
			int ans;
			
				ans=num1/num2;
			
				System.out.println("Answer:" + ans);
			}
			}catch(NumberFormatException|ArithmeticException|ArrayIndexOutOfBoundsException ex){
				System.out.println(ex.getMessage());// it give the message of the compile resulting output
				ex.printStackTrace();// gives the exact error and location 
			}catch (Exception e) {
				System.out.println(e.getMessage());
			}
			
			System.out.println("Program Completed");
		}

	}

