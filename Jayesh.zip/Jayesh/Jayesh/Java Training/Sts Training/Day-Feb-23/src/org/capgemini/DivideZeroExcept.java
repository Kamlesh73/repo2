package org.capgemini;

import java.util.Scanner;

public class DivideZeroExcept {


	public static void main(String[] args) {
		int number1,number2;
		float result=0;
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter 1st number");
		number1=sc.nextInt();
		System.out.println("Enter 2nd number");
		number2=sc.nextInt();
		try{
			if(number2==0)
				throw new DivideByZero("Divide by zero");
			else{
			result=(float)number1/number2;
			System.out.println("Result is "+result);
			}
		}
		catch(DivideByZero dbzo){
			System.out.println(dbzo.getMessage());
		}
	}
}
