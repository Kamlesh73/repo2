package org.capgemini;

public class InvalidExceptionClass extends Exception {

	public InvalidExceptionClass(String msg){
		super(msg);
	
}
