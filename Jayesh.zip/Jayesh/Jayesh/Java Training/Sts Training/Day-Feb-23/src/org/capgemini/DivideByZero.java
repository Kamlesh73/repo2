package org.capgemini;

public class DivideByZero extends Exception {
	
	public DivideByZero(String msg)
	{
		super(msg);
	}
	@Override
	public String getMessage(){
		return "Divisor should not be zero";
	}
}
