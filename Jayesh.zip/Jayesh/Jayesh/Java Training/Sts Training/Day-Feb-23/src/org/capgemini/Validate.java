package org.capgemini;

public class Validate {

	
	public static boolean isValidSalary(Double salary) throws InvalidExceptionClass
	{	
		if(2000<salary && salary<50000){
			System.out.println("Salaary Is Valid");
			return true;
		else
			System.out.println("Salaary Is Invalid");	
		
		}
	}

	
}
