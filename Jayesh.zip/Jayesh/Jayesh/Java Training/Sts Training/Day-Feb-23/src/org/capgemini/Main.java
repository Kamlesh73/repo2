package org.capgemini;

import java.util.Scanner;

public class Main {

	public static void main(String[] args) {
		
		Employee emp=new Employee();
		emp.getEmpId();
	
		 Scanner in = new Scanner(System.in);
		 do{
				System.out.println("EnterSalary:");
				salary=sc.nextDouble();
				flag=Validate.isValidAccId(salary);
					if(!flag)
						System.out.println("Please enter Valid AccountId!");
					
				}while(!flag);
				acc.setAccountId(salary);
		
	

	}

}
