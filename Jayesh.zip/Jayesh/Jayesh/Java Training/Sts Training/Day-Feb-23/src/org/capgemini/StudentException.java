package org.capgemini;

public class StudentException {
	public StudentException(String msg)
	{
		super(msg);
	}
	@Override
	public String getMessage(){
		return "Maximum of 10 students";
	}

}
