package org.capgemini;

import java.io.File;
import java.io.FileReader;

public class CopyFileInfo {

	public static void main(String[] args) {
		File file=new File("D:\\Jayesh\\FileIO\\reverse.txt");
		FileReader fileReader=null;
		
			fileReader=new FileReader(file);
			

	}

}
