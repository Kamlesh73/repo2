package org.capgemini;

import java.io.DataOutputStream;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.Scanner;



public class FormatOutputDemo {

	public static void main(String[] args) {
		
		int empId;
		String empName;
		double salary;
		boolean isPermanent;
		String gender;
		
	File file=new File("D:\\Jayesh\\FileIO\\emp.txt");
	Scanner sc=new Scanner(System.in);

		
	FileOutputStream fout=null;
	DataOutputStream dout=null;
	int j=0;
	
	try{
		fout=new FileOutputStream(file);
		dout=new DataOutputStream(fout);
	do{
		System.out.println("Enter the Employee Id:");
		empId=sc.nextInt();
		System.out.println("Enter the Employee Name:");
		empName=sc.next();

		System.out.println("Enter the Employee salary:");
		salary=sc.nextDouble();

		System.out.println("Is the Employee Permanent(True/False):");
		isPermanent=sc.nextBoolean();

		System.out.println("Enter the gender:");
		gender=sc.next();

			dout.write(empId);
			dout.writeUTF(gender);
			dout.writeDouble(salary);
			dout.writeBoolean(isPermanent);
			dout.writeChars(empName);
		}while(j<10);
	
	
	}catch(FileNotFoundException ex){
		ex.printStackTrace();
	}catch (IOException e) {
		e.printStackTrace();
	}finally{
		try{
		dout.close();
		fout.close();
		}catch(IOException ex){
			ex.printStackTrace();
		}
		
		}
	}
}



