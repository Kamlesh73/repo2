package org.capgemini.demo;

import java.util.ArrayList;
import java.util.Collection;
import java.util.List;

public class Test {

	public static void main(String[] args) {
		int size;
		//Collection lst=new ArrayList();
		//List lst=new ArrayList();
		//ArrayList<Integer> lst=new ArrayList<Integer>();
		ArrayList<Integer> lst=new ArrayList<>();//jdk 1.7
		lst.add(23);
		lst.add(100);
		lst.add(100);
		/*lst.add(1000042432432l);
		lst.add("Tom");
		lst.add('V');
		lst.add(34.56);
		lst.add("Tom");
		lst.add(3.5f);
		lst.add(null);*/
		//lst.add("Tom");
		lst.add(null);
		lst.add(null);
		lst.add(100);
		
	
		
		
		System.out.println(lst);
		//size
		size=lst.size();
		System.out.println(size);
		
		//get
		System.out.println(lst.get(5));
		
		//isEmpty
		if(lst.isEmpty())
			System.out.println("Array LIst is EMpty");
		else
			System.out.println("Array LIst is not Empty");
	
	
			System.out.println(lst.contains(23));
		
		lst.addAll(3,lst);
		lst.addAll(lst2);
		System.out.println(lst);
		
		
		
		
		
		
		
		
	}

}
