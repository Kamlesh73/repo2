package org.capgemini.demo;

import java.util.Scanner;

public class UserInteraction {
	
	public Employee getEmployeeDetails(){
		Employee employee=new Employee();
		
		Scanner sc=new Scanner(System.in);
		
		System.out.println("Enter Employee Id:");
		employee.setEmpId(sc.nextInt());
		

		System.out.println("Enter Employee FirstName:");
		employee.setFirstName(sc.next());
		
		
		System.out.println("Enter Employee LastName:");
		employee.setLastName(sc.next());
		
		System.out.println("Enter Employee Salary:");
		employee.setSalary(sc.nextDouble());
		
		
		
		return employee;
	}
	
	
	
	public void printEmployee(Employee emp){
		System.out.println(emp.getEmpId() + "\t" + emp.getFirstName() + "\t" + 
						emp.getLastName() + "\t" + emp.getSalary());
	}
}