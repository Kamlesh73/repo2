package org.capgemini.demo;

import java.util.Collection;
import java.util.LinkedList;
import java.util.List;

public class linkEdList {

	public static void main(String[] args) {
		
		LinkedList<Integer> lst=new LinkedList<>();
		//List<Integer> lst=new LinkedList<>();
		//Collection<Integer> lst=new LinkedList<>();
		
		
		lst.add(34);
		lst.add(56);
		lst.add(new Integer(-10));
		lst.add(34);
		lst.add(null);
		lst.add(1999);lst.add(34);
		lst.add(null);
		
		
		System.out.println(lst);

		lst.removeFirst();
		System.out.println(lst);
		lst.addFirst(new Integer(56));
		System.out.println(lst);
		lst.addLast(new Integer(99));
		System.out.println(lst);
		
		System.out.println(lst.getFirst());
		System.out.println(lst.getLast());
		
		System.out.println(lst.offer(5));
			System.out.println(lst);
		System.out.println(lst.offerFirst(3));
			System.out.println(lst);
		System.out.println(lst.offerLast(6));
			System.out.println(lst);
		
		System.out.println("Peek:"+lst.peek());
			System.out.println(lst);
		System.out.println(lst.peekFirst());
			System.out.println(lst);
		System.out.println(lst.peekLast());
			System.out.println(lst);
			
		System.out.println("PollFirst:"+ lst.pollFirst());	
			System.out.println(lst);
		System.out.println("PollLast:"+ lst.pollLast());	
			System.out.println(lst);
			
			
		System.out.println("RenameFirstOcc:"+ lst.removeFirstOccurrence(34));	
			System.out.println(lst);
		System.out.println("PollLast:"+ lst.pollLast());	
			System.out.println(lst);	
			
	}

}
