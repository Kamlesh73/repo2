package org.capgemini.demo;

import java.util.ArrayList;

public class Test1 {

	public static void main(String[] args) {
		
		ArrayList<Integer> num1=new ArrayList<>();//jdk 1.7
		num1.add(23);
		num1.add(100);
		num1.add(100);
		
		ArrayList<Integer> num2=new ArrayList<>();//jdk 1.7
		num2.add(45);
		num2.add(500);
		num2.add(800);
		
		
		
		 ArrayList<Integer> allNums = new ArrayList<Integer>();
		    num2.addAll(nums1);
		    
		    System.out.println(allNums);
		
	}

}
