package org.cap.demo;

import java.util.Scanner;

public class SumOfSeries {
	
	
	// intialization
	int num;
	double sum;
	
	public void getIntput(){        // scan number
	Scanner sc=new Scanner(System.in);  // declare scanner
	
	 System.out.println("Enter the number");
	 num=sc.nextInt();	
}
	
	public double sumOfSeries(){
		for(int i=1;i<=num;i++)
			sum=sum+((double)findPower(i,i)/findFactorial(i));
		
		return sum;
	}
	
	// finding the factorial of number
	public long findFactorial(int num){
		long fact=1;  //declaration of local variable
		for(int i=1;i<=num;i++)
			fact=fact*i;
		return fact;
	}
	
	//finding the power of the number
	public long findPower(int base,int power){
		long ans=1;
		for(int i=1;i<=power;i++)
			ans=ans+power;
		return ans;

}
}