package org.cap.demo;

public class MainClassSumOfSeries {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		SumOfSeries sos=new SumOfSeries();
		sos.getIntput();
		sos.sumOfSeries();
		//System.out.println(sos.findFactorial(num));
		System.out.println("sumOfSeries="+ sos.sumOfSeries());
	//	sos.findFactorial(int num);
	//	sos.findPower;
	}
}	
