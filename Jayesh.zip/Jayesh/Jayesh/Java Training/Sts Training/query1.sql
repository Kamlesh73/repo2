CREATE TABLE Visitor( visitorId INT PRIMARY KEY,
visitorName VARCHAR(25),
vAddressId INT REFERENCES address(addId)
)

SELECT * FROM address;

DELETE FROM address;

SELECT * FROM visitor;

DELETE FROM visitor;