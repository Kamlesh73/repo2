package org.capgemini;

import java.util.Date;
import java.util.Scanner;

public class UserInteraction {
		
	public Account getAccountDetails(){
			Account acc=new Account();
			
			Scanner sc=new Scanner(System.in);
			boolean flag=false;
			
			 String accountName;
			 String opendate;
			 double balance;
			 Address addr;
			
		long accid;
		do{
			System.out.println("Enter Account ID:");
			accid=sc.nextLong();
			Long acc1=accid;
			String s=acc1.toString();
			flag=ValidateAcc.isValidAccId(s);
				if(!flag)
					System.out.println("Please enter valid acc Id");
				
			}while(!flag);
			acc.setAccountId(accid);
			
			do{
				System.out.println("Enter Account Name:");
				accountName=sc.next();
				
				flag=ValidateAcc.isValidAccName(accountName);
				/*if(!flag)
					System.out.println("InValid KinId. Please try Again!");
				if(Validation.isValidKinid(kinId)){
					System.out.println("Valid Id");
				}else
					System.out.println("InValid Id");*/
			}while(!flag);
			acc.setAccountName(accountName);
			
			String accdate;
			do{
				System.out.println("Enter Employee Date of Birth[dd-MMM-yyyy]:");
				accdate=sc.next();
				flag=ValidateAcc.isValidOpenDate(accdate);
					if(!flag)
						System.out.println("Please enter Valid Date!");
					
			}while(!flag);
			Date empDob=new Date(accdate);
			acc.setOpendate(empDob);
			
			
			
		
			do{
				System.out.println("Enter balance of the account:");
				balance=sc.nextDouble();

				Double s=new Double(balance);
				String b=s.toString();
				flag=ValidateAcc.isValidBalance(balance);
				if(!flag)
					System.out.println("InValid Name. Please try Again!");
				/*if(Validation.isValidKinid(kinId)){
					System.out.println("Valid Id");
				}else
					System.out.println("InValid Id");*/
			}while(!flag);
			acc.setBalance(balance);

			Address addr1 = new Address();
		    //doorno
			System.out.println("Enter door no:");
			int doorno=sc.nextInt();
			addr1.setDoorNo(doorno);
			acc.setAddr(addr1);
			
			
			//StreetName
			System.out.println("Enter Name of street");
			String sname=sc.next();
			addr1.setStreetname(sname);
			acc.setAddr(addr1);
			
			
			//city
			
			String city;
			do
			{
				System.out.println("Enter city name");
				city=sc.next();
				flag=ValidateAcc.isValidCity(city);
				if(!flag)
					System.out.println("Balance should be greater than 500");
			}while(!flag);
			addr1.setCity(city);
			acc.setAddr(addr1);
			
			
			String state;
			do
			{
				System.out.println("Enter state name");
				state=sc.next();
				flag=ValidateAcc.isValidState(state);
				if(!flag)
					System.out.println("Balance should be greater than 500");
			}while(!flag);
			addr1.setState(state);
			acc.setAddr(addr1);
			
			
			long pincode;
			do{
				System.out.println("Enter Pincode:");
				pincode=sc.nextLong();
				Long pincode1=pincode;
				String s=pincode1.toString();
				
				flag=ValidateAcc.isValidPincode(s);
				if(!flag)
					System.out.println("invalid Pincode");
				
			}while(!flag);
			addr1.setPincode(pincode);
			acc.setAddr(addr1);
		return acc;

	}

}

	
