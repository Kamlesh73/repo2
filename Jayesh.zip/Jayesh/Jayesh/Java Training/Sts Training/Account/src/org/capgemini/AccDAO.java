package org.capgemini;

public interface AccDAO {

	public void saveAccount(Account account);
	public void listAllAccount();
	
	
}
