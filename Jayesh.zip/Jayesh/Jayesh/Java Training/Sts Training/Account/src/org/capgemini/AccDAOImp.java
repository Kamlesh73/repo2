package org.capgemini;

public class AccDAOImp {

	Account[] accounts;
	 int index=0;
	
	
	public AccDAOImp() {
	   accounts=new Account[50];
	}

	public void saveAccount(Account account) {
		accounts[index]=account;
		index++;
		
	}

	public void listAllAccount() {
		for(int i=0;i<index;i++)
			System.out.println(accounts[i]);;
		
	}
}
