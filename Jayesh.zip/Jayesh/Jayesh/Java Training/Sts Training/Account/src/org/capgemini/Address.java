package org.capgemini;

import java.util.Scanner;

public class Address {

	
	private int doorNo;
	private long pincode;
	private String streetname,city,state;
	public Address() {
		
		
	}
	
		public int getDoorNo() {
			return doorNo;
		}
		public void setDoorNo(int doorNo) {
			this.doorNo = doorNo;
		}
		public long getPincode() {
			return pincode;
		}
		public void setPincode(long pincode2) {
			this.pincode = pincode2;
		}
		public String getStreetname() {
			return streetname;
		}
		public void setStreetname(String streetname) {
			this.streetname = streetname;
		}
		public String getCity() {
			return city;
		}
		public void setCity(String city) {
			this.city = city;
		}
		public String getState() {
			return state;
		}
		public void setState(String state) {
			this.state = state;
		}
		
		/*public String printAddress()
		{
			return doorNo+"\t"+streetname+"\t"+city+"\t"+state+"\t"+pincode;
			}
	*/

		@Override
		public String toString() {
			return "Address [doorNo=" + doorNo + ", pincode=" + pincode + ", streetname=" + streetname + ", city=" + city
					+ ", state=" + state + "]";
		}
}
