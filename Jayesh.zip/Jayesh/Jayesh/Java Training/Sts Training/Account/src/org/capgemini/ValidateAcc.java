package org.capgemini;

public class ValidateAcc {

	public static boolean isValidAccId(String accountId){
		return accountId.matches("\\d{15}");
	}
	

	public static boolean isValidAccName(String accountName){
		return accountName.matches("[A-Z][a-z]+");
	}
	
	public static boolean isValidOpenDate(String openDate){
		return openDate.matches("[0|1|2|3|]\\d{1}-(jan|feb|mar|apr|jun|jul|aug|sep|oct|dec)-"
				+ "[12][890]\\d{2}");
	}
	
	public static boolean isValidBalance(Double balance){
		if(balance>=500)
			return true;
			else
				return false;
	}

	public static boolean isValidCity(String city) {
		
		return city.matches("[a-z]+");
	}

	public static boolean isValidState(String state) {
		
		return state.matches("[a-z]+");
	}

	public static boolean isValidPincode(String s) {
		
		return s.matches("\\d{6}");
	}

}
