package org.capgemini;

import java.util.Scanner;

public class AccMain {

	public static void main(String[] args) {
	//	Account account=null;
		AccDAOImp accDao=new AccDAOImp();
		Scanner sc=new Scanner(System.in);
		UserInteraction interaction=new UserInteraction();
		int option;
		String choice;
		do{
			
			System.out.println("1.Save Account");
			System.out.println("2.ListAll Accounts");
			
			System.out.println("Enter your Option:");
			option=sc.nextInt();
			
			if(option==1){
				Account account=new Account();
				account=interaction.getAccountDetails();
				accDao.saveAccount(account);
			}
			else if(option==2)
			{
				
				accDao.listAllAccount();
			}
			
			System.out.println("Wish to Continue?[y|n]");
			choice=sc.next();
		
		}while(choice.charAt(0)=='Y'|| choice.charAt(0) =='y');
		
	}

}
