package org.capgemini;

public class MainClass {

	public static void main(String[] args) {
		
		Customer cus=new Customer();
		
	
		cus.getCustomer();
		cus.printCustomer();

		
		
		
	}

}
