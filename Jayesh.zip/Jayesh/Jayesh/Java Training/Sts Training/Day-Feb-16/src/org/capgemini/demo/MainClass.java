package org.capgemini.demo;

public class MainClass {

	public static void main(String[] args) {
		
		Rectangle rect1=new Rectangle();
		Rectangle rect2=new Rectangle();
		
		rect1.setlength();
		rect1.setwidth();
	    rect1.setcolour();
	
		rect2.setlength();
		rect2.setwidth();
		rect2.setcolour();
		
		if(rect1.findArea()==rect2.findArea() && rect1.setcolour()==rect2.setcolour())
		{
			System.out.println("Matching Rectangles");
		}else
			System.out.println("Not-Matching Rectangles");
		
	}

}
