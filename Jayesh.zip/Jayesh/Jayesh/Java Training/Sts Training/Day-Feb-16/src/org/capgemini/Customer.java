package org.capgemini;

import java.util.Scanner;

public class Customer {

	private int custId;
	private String custName ;
	private Address addr;
	private double fees;
	
	//default Constractor:
	public Customer(){
		System.out.println("Default Constractor");
		this.custId=1001;
		this.custName="Jack";
		this.fees=4500;	   
	}
	
	//overloaded Constractor:
	/*public Customer(int custId,String custName,double fees, Address addr){
		System.out.println("Overloaded Constractor");
		this.custId=custId;
		this.custName=custName;
		this.fees=fees;
	 }
	*/
	public Customer(int custId, String custName, Address addr, double fees) {
		super();
		this.custId = custId;
		this.custName = custName;
		this.addr = addr;
		this.fees = fees;
	}

	public void getCustomer(){
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter Customer Id:");
		custId=sc.nextInt();
		System.out.println("Enter Customer name:");
		custName=sc.next();
		System.out.println("Enter reg Fees:");
		fees=sc.nextDouble();
		
		addr=new Address(); // store the instance variable from address
		addr.getCustomerAddr();
	}
	
	public void printCustomer(){
		System.out.println( custId + "\n" + custName + "\n" + fees);
		addr.printAddr();
		
	}
	
}
