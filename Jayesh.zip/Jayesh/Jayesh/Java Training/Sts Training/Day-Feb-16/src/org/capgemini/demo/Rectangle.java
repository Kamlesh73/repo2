package org.capgemini.demo;

import java.util.Scanner;
public class Rectangle {
        private double width, length, area;
		private String colour;
		
		Scanner sc=new Scanner(System.in);
		
		public void setlength(){
			System.out.println("Enter the Length");
			length=sc.nextDouble();
		}
		public void setwidth(){
			System.out.println("Enter the Width");
			width=sc.nextDouble();
		}
		public String setcolour(){
			System.out.println("Enter the Colour");
			colour=sc.next();
			return colour;
		}
		
		public double findArea(){
			
			return length*width;
		}
		
		
		
}

