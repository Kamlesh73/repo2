package org.capgemini;

import java.util.Scanner;

public class Address {
	private int doorNo, streetNo;
	private String city, state ;
	private String pinCode;
	
	public void getCustomerAddr(){
		Scanner sc=new Scanner(System.in);
		
		System.out.println("Enter Customer Address:");
		System.out.println(" Door no:");
		doorNo=sc.nextInt();
		System.out.println(" Street no:");
		streetNo=sc.nextInt();	
		System.out.println(" City:");
		city=sc.next();	
		System.out.println("State:");
		state=sc.next();	
		System.out.println("Pincode:");
		pinCode=sc.next();
	}
	
	public void printAddr(){
		System.out.println( doorNo + "," + streetNo + "\n" + city + "\n" + state + "-"+ pinCode);
	}
}
