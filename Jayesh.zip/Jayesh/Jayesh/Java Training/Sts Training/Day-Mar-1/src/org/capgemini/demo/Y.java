package org.capgemini.demo;

public class Y {

}
