package org.capgemini.demo.generics;

public class MainClass {

	public static void main(String[] args) {
		Employeeutil<CGEmpolyee> cg=new Employeeutil<CGEmpolyee>(new CGEmpolyee("Tom",2300));
		Employeeutil<CTSEmployee> cts=new Employeeutil<CTSEmployee>(new CTSEmployee("Jerry",2300));
		Employeeutil<CTSEmployee> cts1=new Employeeutil<CTSEmployee>(new CTSEmployee("Jerry",2300));
		
		Employeeutil<CGEmpolyee> cg1=new Employeeutil<CGEmpolyee>(new CGEmpolyee("Kamal",2400));
		
		cg.compareSalary(cg1);
		cts1.compareSalary(cts);
		
		cg.compareSalary(cts);

	}

}
