package org.capgemini.demo;

public class X {

}
