package org.capgemini.demo.generics;

public class Employeeutil<T extends Employee> {

private T empobj;
	
	public T getempObj(){
		return empobj;
	}
	
	public Employeeutil(T empobj){
		this.empobj=empobj;
	}
	
	public void printClass(){
		System.out.println(empobj.getClass().getName());
	}
	
	
	public void compareSalary(Employeeutil<?> emp){
		if(empobj.getSalary()==emp.getempObj().getSalary())
			System.out.println("Equal");
		else
			System.out.println("UnEqual");
	}
	
}
