package org.capgemini.demo;

public class Circle {

}
