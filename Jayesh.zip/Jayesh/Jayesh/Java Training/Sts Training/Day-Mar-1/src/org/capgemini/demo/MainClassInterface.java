package org.capgemini.demo;

public class MainClassInterface {

	public static void main(String[] args) {
		
		MyClass<InterA> objA=new MyClass<InterA>(new X());
		MyClass<InterA> objB=new MyClass<InterA>(new Y());

		objA.printClass();
		objB.printClass();
	}

}
