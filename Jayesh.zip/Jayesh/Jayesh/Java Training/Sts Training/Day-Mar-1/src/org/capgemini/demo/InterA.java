package org.capgemini.demo;

public class InterA {

}
