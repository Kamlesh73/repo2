package org.capgemini.demo.generics;

public class CGEmpolyee extends Employee {

	public CGEmpolyee(String ename, double salary){
		super(ename,salary);
	}
}
