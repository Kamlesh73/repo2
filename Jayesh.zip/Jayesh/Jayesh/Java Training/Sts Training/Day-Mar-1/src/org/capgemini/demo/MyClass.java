package org.capgemini.demo;

public class MyClass<T extends InterA> {

	private T obj;
	
	public MyClass(T obj){
		this.obj=obj;
	}
	


	public MyClass(X obj2) {
		
	}



	public void printClass(){
		System.out.println(obj.getClass().getName());
		obj.show();
	}
	
}
