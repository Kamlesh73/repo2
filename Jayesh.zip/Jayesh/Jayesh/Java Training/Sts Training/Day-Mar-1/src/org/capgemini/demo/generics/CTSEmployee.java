package org.capgemini.demo.generics;

public class CTSEmployee extends Employee {

	public CTSEmployee(String ename, double salary){
		super(ename,salary);
	}
}
