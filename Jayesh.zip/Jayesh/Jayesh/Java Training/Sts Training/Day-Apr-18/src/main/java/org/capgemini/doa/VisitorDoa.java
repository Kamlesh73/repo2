package org.capgemini.doa;

import javax.sql.DataSource;

import org.capgemini.demo.Visitor;

public interface VisitorDoa {
	
	
	public void setDataSource(DataSource dataSource);
	public void createVisitor(Visitor visitor);
	
	public void deleteVisitor(int visitId,int addId);
		


}
