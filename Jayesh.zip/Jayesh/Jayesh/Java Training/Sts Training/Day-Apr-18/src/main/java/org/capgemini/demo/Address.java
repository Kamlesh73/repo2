package org.capgemini.demo;

public class Address {

	private int addId;
	private String door_No;
	private String st_Name;
	private String city;
	private String state;
	
	
	
	
	public Address(){}
	
	public Address(int addId, String door_No, String st_Name, String city, String state) {
		super();
		this.addId = addId;
		this.door_No = door_No;
		this.st_Name = st_Name;
		this.city = city;
		this.state = state;
	}
	public int getAddId() {
		return addId;
	}
	public void setAddId(int addId) {
		this.addId = addId;
	}
	public String getDoor_No() {
		return door_No;
	}
	public void setDoor_No(String door_No) {
		this.door_No = door_No;
	}
	public String getSt_Name() {
		return st_Name;
	}
	public void setSt_Name(String st_Name) {
		this.st_Name = st_Name;
	}
	public String getCity() {
		return city;
	}
	public void setCity(String city) {
		this.city = city;
	}
	public String getState() {
		return state;
	}
	public void setState(String state) {
		this.state = state;
	}

	@Override
	public String toString() {
		return "Address [addId=" + addId + ", door_No=" + door_No + ", st_Name=" + st_Name + ", city=" + city
				+ ", state=" + state + "]";
	}
	
	
	
	
	
}
