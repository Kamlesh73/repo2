package org.capgemini.doa;

import javax.sql.DataSource;

import org.capgemini.demo.Visitor;
import org.springframework.jdbc.core.JdbcTemplate;

public class VisitorDoaImpl implements VisitorDoa{

	private JdbcTemplate jdbcTemplate;
	private DataSource dataSource;


	public void setDataSource(DataSource dataSource) {
		this.dataSource=dataSource;
		jdbcTemplate=new JdbcTemplate(dataSource);
			
	}

	public void createVisitor(Visitor visitor) {
		String sql="insert into Visitor values(?,?,?)";
		jdbcTemplate.update(sql, new Object[]{visitor.getVisitId(),visitor.getVisitName(),
				visitor.getAddress().getAddId()});
		
		
		String sql1="insert into address values(?,?,?,?,?)";
		jdbcTemplate.update(sql1, new Object[]{ visitor.getAddress().getAddId(),visitor.getAddress().getDoor_No(),visitor.getAddress().getSt_Name(),visitor.getAddress().getCity(),visitor.getAddress().getState()
				});
	}


	public void deleteVisitor(int visitId, int addId) {
		String sql2="delete from visitor where visitId";
		jdbcTemplate.update(sql2, visitId);
		System.out.println("Visitor Id Deleted");
		
		String sql3="delete from address where addId";
		jdbcTemplate.update(sql3, addId);
		System.out.println("Address Id Deleted");
		
	}

}
