package org.capgemini.demo;

import org.capgemini.doa.VisitorDoaImpl;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.AbstractApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class Maintest {

	public static void main(String[] args) {
		
	/*	
		//ApplicationContext context= new ClassPathXmlApplicationContext("Beans.xml");
				AbstractApplicationContext context= new ClassPathXmlApplicationContext("Beans.xml");
				Visitor visitor=(Visitor)context.getBean("visitor1");
				
				System.out.println(visitor);
			
				
				context.registerShutdownHook();*/
		

		ApplicationContext context=new ClassPathXmlApplicationContext("jdbc.xml");
		
		VisitorDoaImpl visitorDao=(VisitorDoaImpl) context.getBean("jdbcTemp");
		
		
		Address addr=new Address(101, "21", "Akurdi st", "Pune", "Maharashtra");
		Visitor vis=new Visitor(1001, "Jack",addr);

		
		Address addr1=new Address(102, "22", "Nigdi st", "Pune", "Maharashtra");
		Visitor vis1=new Visitor(1002, "Mack",addr1);
		
		Address addr2=new Address(103, "23", "pimpri st", "Pune", "Maharashtra");
		Visitor vis2=new Visitor(1003, "Pinku",addr2);
		
		visitorDao.createVisitor(vis);
		visitorDao.createVisitor(vis1);
		visitorDao.createVisitor(vis2);
		System.out.println(vis);
		
		
		visitorDao.deleteVisitor(vis.getVisitId(),addr.getAddId());
		
		//employeeDao.deleteEmployee(emp.getEmployeeId());
		
		
		/*Employee emp2=new Employee(2, "Sasi", 5500.0);
		employeeDao.updateEmployee(emp2);*/
		
		/*Employee emp=employeeDao.searchEmployee(452);
		
		System.out.println(emp);*/
		
		/*List<Employee> employees=employeeDao.getAllEmployees();
		
		for(Employee emp:employees)
			System.out.println(emp);*/
		
	}

		
		
		
		
		
			}

		


