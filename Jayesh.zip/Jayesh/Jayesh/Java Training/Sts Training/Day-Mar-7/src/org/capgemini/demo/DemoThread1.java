package org.capgemini.demo;

public class DemoThread1 extends Thread {
	  public static int number = 0;
		public static void main(String[] args) {
			

			   

			        Thread t1 = new DemoThread1();
			        Thread t2 = new DemoThread1();
			        Thread t3 = new DemoThread1();
			        Thread t4 = new DemoThread1();
			        Thread t5 = new DemoThread1();
			        Thread t6 = new DemoThread1();
			        Thread t7 = new DemoThread1();
			        Thread t8 = new DemoThread1();
			        Thread t9 = new DemoThread1();
			        Thread t10 = new DemoThread1();
			  		        
			       
			        t1.start();
			        t2.start();
			        t3.start();
			        t4.start();
			        t5.start();
			        t6.start();
			        t7.start();
			        t8.start();
			        t9.start();
			        t10.start();
			        
			       
			       /* for(int i=1;i<=5;i++)
			        {
			         */
			        try {
			            t1.join();
			            t2.join();
			            t3.join();
			            t4.join();
			            t5.join();
			            t6.join();
			            t7.join();
			            t8.join();
			            t9.join();
			            t10.join();
			            
			        } catch (InterruptedException e) {
			            e.printStackTrace();
			        }
			    }
			  
			    @Override
			    public synchronized void run() {
			      /*  for (int i = 0; i <=1; i++) {
			         // System.out.println(increment());  
			          System.out.println(this.getName() + "====>>" + number++);*/
			          try {
						Thread.sleep(1000);
						  System.out.println(this.getName() + "====>>" + number++);
					} catch (InterruptedException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
			        }
			    }



