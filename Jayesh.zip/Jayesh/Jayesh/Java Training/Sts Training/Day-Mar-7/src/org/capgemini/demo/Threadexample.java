package org.capgemini.demo;

public class Threadexample extends Thread{

	public static int number = 0;
	public static void main(String[] args) {
		

		   

		        Thread t1 = new Threadexample();
		        Thread t2 = new Threadexample();
		        Thread t3 = new Threadexample();
		        
		       
		        t1.start();
		        t2.start();
		        t3.start();
		       
		       /* for(int i=1;i<=5;i++)
		        {
		         */
		        try {
		            t1.join();
		            t2.join();
		            t3.join();
		            
		            
		        } catch (InterruptedException e) {
		            e.printStackTrace();
		        }
	}
	
		    @Override
		    public synchronized void run() {
		     for (int i = 0; i <=2; i++) {
		         // System.out.println(increment());  
		          System.out.println(this.getName() + "====>>" + number++);
		         /* try {
					Thread.sleep(1000);
					//  System.out.println(this.getName() + "====>>" + number++);
				} catch (InterruptedException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();*/
				}
		        }
	
		  }
//}


