package org.capgemini.demo;

public class MyThread extends Thread{

	static int i=0;
	public void run(){
		for(;i<10;i++){
			System.out.println("i="+ i);
		}
	}

		

}
