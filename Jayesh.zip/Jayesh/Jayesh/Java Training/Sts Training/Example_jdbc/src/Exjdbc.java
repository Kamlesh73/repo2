import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

import com.mysql.jdbc.ResultSet;
import com.mysql.jdbc.Statement;



public class Exjdbc {

	public static void main(String[] args) throws Exception{
		

			Class.forName("com.mysql.jdbc.Driver");
			System.out.println("class formed");
			Connection con= DriverManager.getConnection("jdbc:mysql://localhost:3306/assignment","root","Pass1234");
			System.out.println("Connection established");
		
			Statement stmt=(Statement) con.createStatement();
			System.out.println("Statement Created");
	
			ResultSet rs=(ResultSet) stmt.executeQuery("Select FN,LN from college1");
		
		while(rs.next()){
			System.out.println(rs.getString(1));
		}
		con.close();
	}

}
