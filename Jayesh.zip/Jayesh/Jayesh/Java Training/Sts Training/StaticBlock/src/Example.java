
public class Example {

	static int count;
	int num;
	static
	{
		System.out.println("static var:"+ count);
		System.out.println("Static Block");
	}
	{
		System.out.println("Normal Block");
	}

	public Example(){
		System.out.println("Constructor");
	}
	
	public static void main(String[] args) {
	}
	}