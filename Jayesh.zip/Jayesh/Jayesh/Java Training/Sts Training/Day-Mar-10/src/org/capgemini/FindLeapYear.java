package org.capgemini;

public class FindLeapYear {

	public boolean FindLeapYear(int year)
	{
		
		if(year<0){
			throw new RuntimeException();
		}
		else{
		if(year>0){
			
			if(year%4==0)
				return true;
			else if((year%4==0)&&(year%100==0)&&(year%400==0))
				return true;
			else if((year%4==0)&&(year%100==0)&&(year%400!=0))
				return false;
		}
		return false;
		}
		
		
	}

	
}
