package org.capgemini;

public class Consumer implements Runnable {

	private WareHouse wh;
	public Consumer(WareHouse wh){
		this.wh=wh;
	}
	
	@Override
	public synchronized void run(){
		while(true){
			int num1=wh.remove();
			System.out.println("Consumer:"+num1);
			
			try {
				Thread.sleep(500);
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
	
	}
}
