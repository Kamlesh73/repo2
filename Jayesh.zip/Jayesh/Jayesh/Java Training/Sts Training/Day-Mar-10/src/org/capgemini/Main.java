package org.capgemini;

public class Main {

	public static void main(String[] args) {
		 
		WareHouse wh2=new WareHouse();
		Consumer c1=new Consumer(wh2);
		Producer p1=new Producer(wh2);
	
		
		Thread t1=new Thread(p1);
		Thread t2=new Thread(c1);
		
		t1.start();
		t2.start();
		
	}

}
