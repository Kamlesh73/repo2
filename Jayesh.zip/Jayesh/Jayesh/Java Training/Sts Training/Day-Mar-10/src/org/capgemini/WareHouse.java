package org.capgemini;

import java.util.Stack;

public class WareHouse {

	private Stack<Integer> stack =new Stack <Integer>();

		public synchronized int add(int x) {
		if(stack.size()==10)
			try {
				wait();
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		return stack.push(x);
	}

		public synchronized int remove(){
			if(stack.isEmpty())
				try {
					wait();
				} catch (InterruptedException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			return stack.pop();
		}

	
	
}
