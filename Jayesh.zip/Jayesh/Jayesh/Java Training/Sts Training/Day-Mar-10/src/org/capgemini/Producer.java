package org.capgemini;

import java.util.Random;

public class Producer implements Runnable {

	private WareHouse wh;
	int num=0;
	public Producer(WareHouse wh){
		this.wh=wh;
	}
	
	@Override
	public synchronized void run(){
		while(true){
			int x=new Random().nextInt(500);
			num=wh.add(x);
			
			System.out.println("Producer:"+num);
			
			try {
				Thread.sleep(500);
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		notifyAll();
		}
	}
	
}
