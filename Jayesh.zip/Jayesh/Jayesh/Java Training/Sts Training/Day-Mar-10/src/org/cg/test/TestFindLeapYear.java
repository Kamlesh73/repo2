package org.cg.test;

import static org.junit.Assert.*;

import org.junit.Test;
import org.capgemini.*;
public class TestFindLeapYear {

	@Test
	public void testLeapYearDivByFour() {
		FindLeapYear lpy=new FindLeapYear();
		assertEquals(true, lpy.FindLeapYear(1996));
	}

	
	@Test
	public void testLeapYearDivByFourAndHundredAndFourHundred() {
		FindLeapYear lpy=new FindLeapYear();
		assertEquals(true, lpy.FindLeapYear(1600));
	}
	
	@Test
	public void testLeapYearDivByFourAndHundredButNotByFourHundred() {
		FindLeapYear lpy=new FindLeapYear();
		assertEquals(true, lpy.FindLeapYear(1900));
	}
		
	@Test(expected=java.lang.RuntimeException.class)
	public void testLeapYearNegative() {
	FindLeapYear lpy=new FindLeapYear();
	assertEquals(true, lpy.FindLeapYear(-1992));
	}
	
	
}
