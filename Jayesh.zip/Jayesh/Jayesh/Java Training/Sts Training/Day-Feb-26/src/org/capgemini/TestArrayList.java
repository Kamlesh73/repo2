package org.capgemini;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.ListIterator;

public class TestArrayList {

	public static void main(String[] args) {
		List<String> mylst=new ArrayList<>();
		
		mylst.add("Tom");
		mylst.add("Jeryy");
		mylst.add("Tom");
	//	mylst.add(null);
		mylst.add("ram");
		mylst.add("jack");
		mylst.add("jack");
		mylst.add("Emi");
		mylst.add("Tom");
		//mylst.add(null);
		mylst.add("null");
		
		
		for(String str:mylst){
			System.out.println(str);
		}
		
		
		// Iterator:
		/*Iterator<String> itr=mylst.iterator();
		while(itr.hasNext()){
			System.out.println(itr.next());
		}
		*/
		
		
		ListIterator<String>litr=mylst.listIterator();

		while(litr.hasNext()){
			String str=litr.next();
			if(str.equals("jack"))
				litr.remove();
			System.out.print(str+ "--->");
		}
		System.out.println();
		
	
		while(litr.hasPrevious()){
			System.out.print(litr.previous()+">-->");
		}
		System.out.println();
		mylst.add("Ramsingh");
			System.out.println(mylst);
		mylst.
	}

}
