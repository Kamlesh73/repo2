package org.cap.demo;

import java.util.Date;

public class Customer {

	private int custId;
	private String custName;
	private long regfees;
	private Date regDate;
	private String address;
	

public Customer(){}

public Customer(int custId, String custName, long regfees, Date regDate, String address) {
	super();
	this.custId = custId;
	this.custName = custName;
	this.regfees = regfees;
	this.regDate = regDate;
	this.address = address;
}

public int getCustId() {
	return custId;
}

public void setCustId(int custId) {
	this.custId = custId;
}

public String getCustName() {
	return custName;
}

public void setCustName(String custName) {
	this.custName = custName;
}

public long getRegfees() {
	return regfees;
}

public void setRegfees(long regfees) {
	this.regfees = regfees;
}

public Date getRegDate() {
	return regDate;
}

public void setRegDate(Date regDate) {
	this.regDate = regDate;
}

public String getAddress() {
	return address;
}

public void setAddress(String address) {
	this.address = address;
}

@Override
public String toString() {
	return "Customer [custId=" + custId + ", custName=" + custName + ", regfees=" + regfees + ", regDate=" + regDate
			+ ", address=" + address + "]";
}



}
