package org.cap.demo;

import java.util.Date;
import java.util.Scanner;


public class UserInteraction {

	public Customer getCustomerDetails(){
		Customer cus=new Customer();
		long custId;
		String custName;
		long regfee;
		String date;
		String address;
		
		
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter the Customer ID:");
		custId=sc.nextInt();
		System.out.println("Enter the Customer Name:");
		custName=sc.next();
		System.out.println("Enter the Customer Reg Fees:");
		regfee=sc.nextLong();
		System.out.println("Enter the Customer Date:");
		date=sc.next();
		System.out.println("Enter the Customer Address:");
		address=sc.next();
		
		cus.setCustId(custId);
		cus.setCustName(custName);
		cus.setRegfees(regfee);
		Date d=new Date(date);
		cus.setRegDate(d);
		cus.setAddress(address);
		return cus;
	}
}
