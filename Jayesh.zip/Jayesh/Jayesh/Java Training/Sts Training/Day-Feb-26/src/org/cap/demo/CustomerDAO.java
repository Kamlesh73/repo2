package org.cap.demo;

public class CustomerDAO {

	public void storeCustomer(Customer c);
	public void listAllCustomers();
	public void searchCustomer(int custId);
	
}
