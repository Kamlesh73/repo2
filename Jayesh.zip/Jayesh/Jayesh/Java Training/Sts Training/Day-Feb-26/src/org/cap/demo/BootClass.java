package org.cap.demo;

import java.util.Scanner;

public class BootClass {

	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		//Book book=new Book();
		UserInteraction ui=new UserInteraction();
		CustomerDAOImp custImp=new CustomerDAOImp();
		
		int option;
		do{
			System.out.println("1.Store Customer");
			System.out.println("2.List all Customers");
			System.out.println("3.Search Customer");
			System.out.println("Enter your option");
			option=sc.nextInt();
			if(option==1)
			{ 
				Customer customer=new Customer();
				customer=ui.getCustomerDetails();
				custImp.storeCustomer(customer);
								
			}
			else if(option==2)
			{
			
				custImp.listAllCustomers();
			}
			else if(option==3)
			{
				System.out.println("Enter customer id");
				int custId=sc.nextInt();
                                                                                                                                                                                                                                                                                                                                                                                                                             
			}
			else
			{
				System.out.println("Invalid Input");
			}
		}while(option==1||option==2||option==3);

	}

}
