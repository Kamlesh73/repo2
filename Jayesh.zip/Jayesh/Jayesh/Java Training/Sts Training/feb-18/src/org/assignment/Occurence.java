package org.assignment;

import java.util.Scanner;

public class Occurence {

public static void main(String[] args) {

    Scanner sc= new Scanner(System.in);
    String str;
    String s = null;
    int i=0;
    System.out.println("Enter the string:");
    str=sc.nextLine();
    
    
    int c = 0;
    for(i=0;i<=str.length();i++)
    {
    	if(str.charAt(i)==s.charAt(0))
    	{c++;
    	}
    	if(i>0)
    		System.out.print("Occurance:"+i);
    	else
    		System.out.println("Character not found");
    }
    
/*
    while(str.length()>0)
    {
        str.charAt(0);
       
        while(str.charAt(i)==str)
        {
               // count =count+i;
                i++;
        }*/
  
 /*   
      str.substring(count);
  //   System.out.println(ch);
     System.out.println(count);*/
}
}

