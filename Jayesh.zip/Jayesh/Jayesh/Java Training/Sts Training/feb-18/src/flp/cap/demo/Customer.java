package flp.cap.demo;

import java.util.Scanner;

public class Customer {

	private int custId=0;
	private String custName;
	private double regFees;
	private CustType customerType;
	
	public void chooseCustomerType(){
		
		Scanner sc=new Scanner(System.in);
		
		System.out.println("1.Silver:");
		System.out.println("2. Gold:");
		System.out.println("3. Diamond:");
		System.out.println("4. Platinum:");
		System.out.println("Choose the customer type:");
		int choice=sc.nextInt();
		
		switch(choice){
			case 1:
				customerType=CustType.SILVER;
				break;
			case 2:
				customerType=CustType.GOLD;
				break;
			case 3:
				customerType=CustType.DIAMOND;
				break;
			case 4:
				customerType=CustType.PLATINUM;
				break;	
		}
	}
		public void getCustomerDetails(){
			
			Scanner sc=new Scanner(System.in);
			
			System.out.println("Get Customer Id:");
			custId=sc.nextInt();
			System.out.println("Get Customer Name");
			custName=sc.next();
			System.out.println("Get Customer reg Fees");
			custName=sc.next();
			/*System.out.println("Get Customer Type:");
			custName=sc.next();*/
	}
	

	public void printCustomer(){
		System.out.println(custId+" , " + custName +" , " + customerType+" , " + regFees);
	}
	
	
	public static void main(String[] args){
		Customer cust=new Customer();
		cust.getCustomerDetails();
		cust.printCustomer();
	}
	
	
}
