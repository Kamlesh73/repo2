package flp.cap.demo;

public class ImplementationDiv {

	public void division(int num, int num1) {
		System.out.println("Division:"+num/num1);
	}

	public void mod(int num, int num1) {
		System.out.println("Mod:"+num%num1);
		
	}
}
