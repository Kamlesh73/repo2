package flp.cap.demo;
/*
public class PG_Student implements Student{

	@Override
	public void Display_Grade() {
		System.out.println("Display PG Students Grade");
		
	}

	@Override
	public void Attendance() {
		System.out.println("Display PG Students Attendance");
		
	}
*/


