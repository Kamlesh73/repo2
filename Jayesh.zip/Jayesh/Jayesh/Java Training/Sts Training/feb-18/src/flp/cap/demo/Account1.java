package flp.cap.demo;

import java.util.Scanner;

import balance.Account;

public class Account1 extends Account{

	public double salary;
	
	public double balance;
	
	
	public void getAccount1(){
		
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter salary");
		salary=sc.nextDouble();
		System.out.println("Enter Balance");
		balance=sc.nextDouble();
		}
	
	public void printAccount1()
	{
		
		System.out.println("salary:"+salary);
		System.out.println("balance:"+balance);
		
	}
}