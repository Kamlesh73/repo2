package flp.cap.demo;

import java.util.Scanner;

public class MainDiv {

	public static void main(String[] args) {
		int n1,n2;
		ImplementationDiv imp=new ImplementationDiv();
		System.out.println("Enter number");
		Scanner sc=new Scanner(System.in);
		n1=sc.nextInt();
		n2=sc.nextInt();
		imp.division(n1,n2);
		imp.mod(n1,n2);

	}

}
