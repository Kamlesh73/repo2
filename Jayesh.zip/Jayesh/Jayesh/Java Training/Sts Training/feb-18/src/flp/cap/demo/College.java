package flp.cap.demo;

import java.util.Scanner;

public class College {
	public static void main(String[] args) {
		int option;
		/*UG_Student ug=new UG_Student();
		PG_Student pg=new PG_Student();*/
		do{
			System.out.println("1 UG Students ");
			System.out.println("2 PG Students ");
			System.out.println("Enter option ");
		
		/*	Scanner sc=new Scanner(System.in);
			option=sc.nextInt();
		if(option==1)
			{ug.Display_Grade();
		ug.Attendance();
			}
		else if(option==1)
		{pg.Display_Grade();
		pg.Attendance();
		}
		else
		{
			
		}
		
	}
*/
		}while(option==1||option==2);
	}
}
