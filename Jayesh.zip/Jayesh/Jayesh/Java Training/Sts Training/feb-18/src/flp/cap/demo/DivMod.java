package flp.cap.demo;

public interface DivMod {
void division(int num,int num1);
void mod(int num,int num1);
}
