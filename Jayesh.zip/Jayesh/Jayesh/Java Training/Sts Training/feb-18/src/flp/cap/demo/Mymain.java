package flp.cap.demo;

public class Mymain {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Account1 acc=new Account1();
		acc.getAccount1();
		acc.printAccount1();
	}

}
