package flp.cap.demo;

public class Employe {

	private int empId;
	private String empName;


public Employe(){

}

public Employe(int empId, String empName){
	this.empId=empId;
	this.empName=empName;
}

}