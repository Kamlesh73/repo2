package flp.cap.demo;

/*public class Student {
	void Display_Grade();
	void Attendance();

}
*/