package flp.cap.demo;

public class MainMethod {

	public static void main(String[] args) {
		Employe e1=new Employe(1,"tom");
		Employe e2=new Employe(1,"tom");
	System.out.println(e1==e2);
	System.out.println(e1.equals(e2));
	}

}
