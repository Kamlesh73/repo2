package flp.cap.demo;

import java.util.Scanner;

public class Encrypt {
	String string;
	char ch;
	int count=0;
	public void getString()
	{
		System.out.println("Enter string");
		Scanner sc=new Scanner(System.in);
		string=sc.next();
		
	}
	public void encryptString()
	{
	//	String tmp=null;
		for(int i=0;i<string.length();i++)
		{
			int ascii=(int)string.charAt(i);
			ascii=ascii-1;
			System.out.print(ascii);
			
			
		}
	}

}
