package flp.cap.demo;

public class DemoMath {
	/*private double num1,num2*/
}
