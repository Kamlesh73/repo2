package flp.cap.demo;

public class Employee {

}
