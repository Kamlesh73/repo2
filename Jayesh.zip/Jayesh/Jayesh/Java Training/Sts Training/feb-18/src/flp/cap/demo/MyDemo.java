package flp.cap.demo;

public class MyDemo {

	public static void main(String[] args) {
		
		String str1="tom";
		String str2="tom";
		String myStr=new String("tom");
		System.out.println(str1==str2);
		System.out.println(str1==myStr);
		
		System.out.println(str1.equals(str2));
		System.out.println(str1.equals(myStr));
	}
	}

