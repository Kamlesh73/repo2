package flp.cap.demo;

public enum CustType {

	SILVER(0,100), GOLD(101,300),DIAMOND(301,500),PLATINUM(501,1000);
	
	
	private int minValue;
	private int maxValue;
	
	CustType(int minValue,int maxValue){
		this.minValue=minValue;
		this.maxValue=maxValue;
	}
	
	
	public int getMinValue(){
		return minValue;
	}
	
	public int getMaxValue(){
		return maxValue;
	}
	
}
