package flp.cap.demo;


/*public class UG_Student implements Student{

	public void Display_Grade() {
		System.out.println("Display UG Students Grade");
		
	}

	public void Attendance() {
		System.out.println("Display UG Students Attendance");
		
	}
}
*/