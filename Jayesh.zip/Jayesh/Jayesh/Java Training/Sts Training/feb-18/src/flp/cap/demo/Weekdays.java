package flp.cap.demo;

public enum Weekdays {
	
	
	MON,TUE,WED,THU,FRI,SAT,SUN;

}
