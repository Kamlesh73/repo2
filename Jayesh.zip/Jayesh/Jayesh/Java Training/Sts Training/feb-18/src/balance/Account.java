package balance;

public class Account {

	public void printAccount(){}
}
