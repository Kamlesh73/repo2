package org.capgemini;

public class Shape {
	//int shape;
	public void draw(){
		System.out.println("Shape class drow method:");

	}
	
}
