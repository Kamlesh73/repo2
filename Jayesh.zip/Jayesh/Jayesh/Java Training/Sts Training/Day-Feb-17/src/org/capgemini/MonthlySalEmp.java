package org.capgemini;

import java.util.Scanner;

public class MonthlySalEmp extends Employee {
	int numOfDays;
	int salPerDay;
	int monthSal;

	public void getMonthlyDetails(){
		Scanner sc=new Scanner(System.in);
		

		System.out.println("Enter Number of Days:");
		numOfDays=sc.nextInt();
		
		System.out.println("Enter Wages Per Hour:");
		salPerDay=sc.nextInt();
	}
	
	public void printMonthlyDetails(){
		System.out.println("Monthly Salary:"+ monthSal);
	}
	
	@Override
	public double calSal(){
		getMonthlyDetails();
	
		monthSal=numOfDays*salPerDay;
		printMonthlyDetails();
		System.out.println("Monthly Salary Is:"+ monthSal);
		return 0;
	}
}
	
	