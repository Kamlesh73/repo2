package org.capgemini;

public interface BookDoa {

	
	public void saveBook(Book book);
	public void listAllBooks();
	public void deleteBook();
	public void findBook();
	
}
