package org.capgemini;

import java.util.Scanner;

public class MyMainClass {

	public static void main(String[] args) {
		
		Employee emp=null;
		Scanner sc=new Scanner(System.in);
		System.out.println("1.Weekly Salary");
		System.out.println("2.Monthly Salary");
		System.out.println("Enter the option");
		int option=sc.nextInt();
 
		if(option==1)
			emp=new WeeklySalEmp();
		else if(option==2)
			emp=new MonthlySalEmp();

		emp.getEmp();
		emp.calSal();
		
		
	}

}
