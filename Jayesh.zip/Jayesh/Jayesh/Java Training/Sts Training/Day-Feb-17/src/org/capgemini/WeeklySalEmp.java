package org.capgemini;

import java.util.Scanner;

public class WeeklySalEmp extends Employee {
	int numOfHours;
	 int wagesPerHour;
		int weekSal;

	public void getWeeklyDetails(){
		Scanner sc=new Scanner(System.in);
		

		System.out.println("Enter Number of Hours:");
		numOfHours=sc.nextInt();
		
		System.out.println("Enter Wages Per Hour:");
		wagesPerHour=sc.nextInt();
	}

	
	public void printWeeklyDetails(){
		System.out.println("Weekly Salary:"+ weekSal);
	}
	@Override
	public double calSal() {
		getWeeklyDetails();
	
		weekSal=numOfHours*wagesPerHour;
		printWeeklyDetails();
		System.out.println("Weekly Salary Is:"+ weekSal);
		return 0;
	}
	
	

}
