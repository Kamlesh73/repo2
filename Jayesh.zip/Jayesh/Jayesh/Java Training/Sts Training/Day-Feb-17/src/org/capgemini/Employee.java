package org.capgemini;

import java.util.Scanner;

public abstract class  Employee{

	protected int empId;
	public String fName;
	public String lName;
	double sal;
	


public void getEmp(){
	Scanner sc=new Scanner(System.in);

	System.out.println("Enter Empolyee Id:");
	empId=sc.nextInt();
	
	System.out.println("Enter Firstname:");
	fName=sc.next();
	
	System.out.println("Enter Lastname:");
	lName=sc.next();

	System.out.println("Enter Salary:");
	sal=sc.nextDouble();
    }

public void printEmp(){
	System.out.println("Employment Id:"+ empId);
	System.out.println("First Name:"+ fName);
	System.out.println("Last Name:"+ lName);
}

public abstract double calSal();

}