package org.capgemini;

import java.util.Scanner;

public class MyMain {

	public static void main(String[] args) {
		Book book=new Book();
		
	    Scanner sc=new Scanner(System.in);
	    
		BookDoaImp bdi=new BookDoaImp();
		String choice;
	do{	
		System.out.println("1.Save Book");
		System.out.println("2.ListAll Books");
		System.out.println("3.findBook");
		System.out.println("4.deleteBook");
		System.out.println("Enter your option:");
		int option=sc.nextInt();

		if(option==1){
			book=book.getBookDetails();
			bdi.saveBook(book);
		}else if(option==2){
			bdi.listAllBooks();
		}else if(option==3){
			bdi.findBook();
	    }else if(option==4){
	    	bdi.deleteBook();
		
	    }
		System.out.println("Wish to Continue?[y|n]");
		choice=sc.next();
	
	}while(choice.charAt(0)=='Y'|| choice.charAt(0) =='y'||choice.charAt(0)=='N'|| choice.charAt(0) =='n');
	
}
}


