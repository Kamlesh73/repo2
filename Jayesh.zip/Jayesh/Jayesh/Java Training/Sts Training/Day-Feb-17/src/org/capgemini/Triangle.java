package org.capgemini;

public class Triangle {
	
	public void Draw(){
		System.out.println("Triangle class drow method:");
		
	}

}
