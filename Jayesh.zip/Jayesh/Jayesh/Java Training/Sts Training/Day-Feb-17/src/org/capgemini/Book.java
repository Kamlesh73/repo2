package org.capgemini;

import java.util.Scanner;

public class Book {
	
	public int bookId;
	public String bookName;
	public String author;
	public String publisher;
	public double price;
	

	public Book getBookDetails(){
		Book book=new Book();
	
		Scanner sc=new Scanner(System.in);

		System.out.println("Enter Book Id:");
		book.bookId=sc.nextInt();
		System.out.println("Enter Book name:");
		book.bookName=sc.next();		
		System.out.println("Enter Author of the book:");
		book.author=sc.next();
		System.out.println("Enter Publisher of the book:");
		book.publisher=sc.next();
		System.out.println("Enter Price:");
		book.price=sc.nextDouble();
		return book;
	    }

	public void showBookDetails(){
		System.out.println(bookId+"\t"+bookName+"\t"+author+"\t"+publisher+"\t"+ price);
		
	}
	
}
