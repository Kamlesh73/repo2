package org.capgemini;

public class Rectangle extends Circle {
    @Override
	public void draw(){
		System.out.println("Rectangle class draw method:");
		
	}
}
