package org.capgemini;

import java.util.Scanner;

public class BookDoaImp implements BookDoa{

	Book[] books;//// Book is a datatype
	int index;
	
	public BookDoaImp(){
		books=new Book[50];
	}
	
	
	@Override
	public void saveBook(Book book) {
		books[index]=book;
		index++;
		
	}

	@Override
	public void listAllBooks() {
		
		System.out.println("BookId\tBookName\tAuthor\tPublisher\tPrice");
		
		for(int i=0;i<index;i++)
			books[i].showBookDetails();
	}


	@Override
	public void findBook() {
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter the BookId:");
		int search=sc.nextInt();
		
			for(int j=0;j<index;j++)
			{
				if(books[j].bookId==search)
				books[j].showBookDetails();
			}
		
	}

	
	@Override
	public void deleteBook() {
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter the BookId:");
		int search1=sc.nextInt();
		
			for(int k=0;k<index;k++)
			{
				if(books[k].bookId==search1)
				books[k].showBookDetails();
				books[k]=books[k+1];
			}
		
	}

	
}
