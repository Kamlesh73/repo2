package flp.capgemini;

public interface Shape {

    float PI=3.14f;
	public void draw();
	
}
