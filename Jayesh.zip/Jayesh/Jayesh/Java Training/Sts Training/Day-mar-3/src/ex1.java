import java.util.ArrayList;
import java.util.List;
import java.util.ListIterator;

import javax.swing.text.html.HTMLDocument.Iterator;

public class ex1 {

	public static void main(String[]args){
	List str=new ArrayList<>();
	str.add("Pune");
	str.add("chennai");
	str.add("HYderabad");
	str.add("Mumbai");
	str.add(1);
	str.add(3.14f);
	
	ListIterator it=str.listIterator();
	it.next();
	it.previous();
	it.hasPrevious();
	it.next();
	it.next();
	it.previous();
	it.next();
	it.previous();
	System.out.println(it.next());
}
}