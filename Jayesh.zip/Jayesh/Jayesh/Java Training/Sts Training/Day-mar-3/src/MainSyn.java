
public class MainSyn {

	public static void main(String[] args) {
		
String1 s3=new String1();
	
/*Thread t1=new Thread(){
			public void run(){
				s3.printString("Capgemini");
			}
		};
		
		Thread t2=new Thread(){
			public void run(){
				s3.printString("Welcome");
			}
		};
		
		Thread t3=new Thread(){
			public void run(){
				s3.printString("Jack");
			}
		};
		
		
		t1.start();
		t2.start();
		t3.start();
		
	}

}*/


Runnable r1=new Runnable(){


public void run() {
		
s3.printString("Capgemini");
}
	
};
Thread t1=new Thread(r1);

t1.start();
	
}
}


