
public class String1 {

	private String s1;

		
	public void printString(String s1) {
System.out.println(Thread.currentThread().getName() + "-Started");
		
		synchronized (this) {
			for(int i=0;i<=s1.length();i++)
				System.out.println(s1.substring(0, i));
		}
		
		System.out.println(Thread.currentThread().getName() + "-Ended");
		
	}
}

