
public class MyStringSyn extends Thread {


	private String s2;
	
	@Override
	public void run(){
		
		
	}
}
