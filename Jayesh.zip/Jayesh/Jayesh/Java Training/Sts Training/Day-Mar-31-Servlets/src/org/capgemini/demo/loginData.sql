

CREATE TABLE LoginData(username VARCHAR(20), pass VARCHAR(20))

INSERT INTO LoginData VALUES("mayur","12345");
INSERT INTO LoginData VALUES('jayesh','23456');
INSERT INTO LoginData VALUES('ashish','34567');
SELECT * FROM logindata;