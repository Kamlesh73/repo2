package org.capgemini.demo;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;



/**
 * Servlet implementation class HelloServlet
 */
public class HelloServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see Servlet#init(ServletConfig)
	 */
	public void init(ServletConfig config) throws ServletException {
		System.out.println("Servlet Init- Started");
	}

	/**
	 * @see Servlet#destroy()
	 */
	public void destroy() {
		System.out.println("Servlet Destroy method started");
	}

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		PrintWriter out=response.getWriter();
		out.println("YOU LOGGED IN SUCCESSFULLY!!!!!!");
		
		boolean flag=false;
		String UserName=request.getParameter("uname");
		String UserPassword=request.getParameter("upwd");	
		
		/*out.println("Username:"+ UserName + "<br/>");
		out.println("Password:"+ UserPassword + "<br/>");	
		
		
		if(UserName.equals("Jayesh")&&UserPassword.equals("123456"))
			response.sendRedirect("pages/success.html");
			else
			response.sendRedirect("pages/loginform.html");
		*/
		Connection con=null;
		Statement st=null;
		ResultSet rs=null;
		
		try {
			Class.forName("com.mysql.jdbc.Driver");
			System.out.println("Class loaded");
			 con= DriverManager.getConnection("jdbc:mysql://localhost:3306/myServlet", "root", "Pass1234");
			System.out.println("Connection");
			st=con.createStatement();
			

			String query="select * from LoginData";
			rs=st.executeQuery(query);
		System.out.println(rs);
			while(rs.next())
			{
				if(UserName.equals(rs.getString(1))&& UserPassword.equals(rs.getString(2)))
					response.sendRedirect("pages/success.html");
				flag=true;
			}
			if(flag==false)
				response.sendRedirect("pages/Home.html");
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			((Throwable) e).printStackTrace();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		


		
		
		
		
	}

}
