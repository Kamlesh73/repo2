SELECT * FROM customer;
DELETE FROM customer;
SELECT * FROM logindata;