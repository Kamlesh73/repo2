USE myservlet;

CREATE TABLE Customer (custId INT PRIMARY KEY AUTO_INCREMENT, CustFN VARCHAR(25) NOT NULL,
	CustLN VARCHAR(25), Address VARCHAR(50),RegistrationDate DATE, Fees DOUBLE,
	CustomerType VARCHAR(15),Gendar VARCHAR(5));

INSERT INTO Customer (CustFN ,CustLN , Address ,RegistrationDate , Fees ,CustomerType ,Gendar) VALUES
('Jayesh','Sonkusare','121 south california','12-Apr-2000','20000','Golden','Male');
INSERT INTO Customer (CustFN ,CustLN , Address ,RegistrationDate , Fees ,CustomerType ,Gendar) VALUES
('AShish','badave','121 North california','12-Apr-2010','21000','Silver','Male');
INSERT INTO Customer (CustFN ,CustLN , Address ,RegistrationDate , Fees ,CustomerType ,Gendar) VALUES
('Mayur','Gavali','121 West california','12-Apr-2100','20500','Bronze','Male');

SELECT * FROM Customer;