package org.cap.springDemo;

public class Customer {

	private int custId;
	private String custName;
	private String contact;
	
	
	public Customer(){}
	
	
	public Customer(int custId, String custName, String contact) {
		super();
		this.custId = custId;
		this.custName = custName;
		this.contact = contact;
	}
	public int getCustId() {
		return custId;
	}
	public void setCustId(int custId) {
		this.custId = custId;
	}
	public String getCustName() {
		return custName;
	}
	public void setCustName(String custName) {
		this.custName = custName;
	}
	public String getContact() {
		return contact;
	}
	public void setContact(String contact) {
		this.contact = contact;
	}
	@Override
	public String toString() {
		return "Customer [custId=" + custId + ", custName=" + custName + ", contact=" + contact + "]";
	}
	
	
	
	
	
	
	
}
