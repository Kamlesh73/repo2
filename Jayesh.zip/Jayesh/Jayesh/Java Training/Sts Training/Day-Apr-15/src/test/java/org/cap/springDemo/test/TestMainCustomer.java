package org.cap.springDemo.test;

import org.cap.springDemo.Customer;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class TestMainCustomer {

	public static void main(String[] args) {
		
		
		
		ApplicationContext context=new ClassPathXmlApplicationContext("Beans.xml");
		
		Customer customer=(Customer) context.getBean("customer");
		
		System.out.println(customer);
		

	}

}
