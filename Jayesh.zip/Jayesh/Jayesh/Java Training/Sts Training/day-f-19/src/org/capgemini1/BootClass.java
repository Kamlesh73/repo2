package org.capgemini1;

public class BootClass {

	public static void main(String[] args) {
		Interaction interaction=new Interaction();
		Employe emp=interaction.getEmploye();
		
		System.out.println(emp);
		


	}

}
