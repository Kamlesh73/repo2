package org.capgemini1;

import java.util.Scanner;

public class Interaction {

	
	public Employe getEmploye(){
		Employe employee=new Employe();
		
		Scanner sc=new Scanner(System.in);
		boolean flag=false;
		int empid;
		String kinId;
		String firstname;
		String lastname;
		String address;
		String emailId,mobileno,dob,doj;
		
		
		do{
		System.out.println("Enter Employee Id:");
		empid=sc.nextInt();
		flag=ValidateEmp.isValidEmpId(empid);
			if(!flag)
				System.out.println("Please enter Valid EmployeeId!");
			
		}while(!flag);
		employee.setEmpId(empid);
		
		do{
			System.out.println("Enter KinID:");
			kinId=sc.next();
			
			flag=ValidateEmp.isValidKinid(kinId);
			/*if(!flag)
				System.out.println("InValid KinId. Please try Again!");
			if(Validation.isValidKinid(kinId)){
				System.out.println("Valid Id");
			}else
				System.out.println("InValid Id");*/
		}while(!flag);
		employee.setKinId(kinId);
		
		do{
			System.out.println("Enter First Name:");
			firstname=sc.next();
			
			flag=ValidateEmp.isValidFirstName(firstname);
			if(!flag)
				System.out.println("InValid Name. Please try Again!");
			/*if(Validation.isValidKinid(kinId)){
				System.out.println("Valid Id");
			}else
				System.out.println("InValid Id");*/
		}while(!flag);
		
		do{
			System.out.println("Enter Last Name:");
			lastname=sc.next();
			
			flag=ValidateEmp.isValidLastName(lastname);
			if(!flag)
				System.out.println("InValid Name. Please try Again!");
			/*if(Validation.isValidKinid(kinId)){
				System.out.println("Valid Id");
			}else
				System.out.println("InValid Id");*/
		}while(!flag);
		

		do{
			System.out.println("Address:");
			address=sc.next();
			
			flag=ValidateEmp.isValidAddress(address);
			if(!flag)
				System.out.println("InValid Address. Please try Again!");
			
		}while(!flag);
		
		do{
			System.out.println("EmailId:");
			emailId=sc.next();
			
			flag=ValidateEmp.isValidEmailId(emailId);
			if(!flag)
				System.out.println("InValid EmailId. Please try Again!");
		
		}while(!flag);
		
		do{
			System.out.println("Mobile No:");
			mobileno=sc.next();
			
			flag=ValidateEmp.isValidMobileNo(mobileno);
			if(!flag)
				System.out.println("InValid Mobile No. Please try Again!");
		
		}while(!flag);
		
		do{
			System.out.println("Date Of Birth:");
			dob=sc.next();
			
			flag=ValidateEmp.isValidDateOfBirth(dob);
			if(!flag)
				System.out.println("InValid Date of Birth. Please try Again!");
		
		}while(!flag);
		
		do{
			System.out.println("Date Of Joining:");
			doj=sc.next();
			
			flag=ValidateEmp.isValidDateOfJoining(doj);
			if(!flag)
				System.out.println("InValid date of joining. Please try Again!");
			/*if(Validation.isValidKinid(kinId)){
				System.out.println("Valid Id");
			}else
				System.out.println("InValid Id");*/
		}while(!flag);
		return employee;
	}

	}
