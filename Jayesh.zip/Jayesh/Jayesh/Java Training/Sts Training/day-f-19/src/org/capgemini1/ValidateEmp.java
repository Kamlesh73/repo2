package org.capgemini1;

public class ValidateEmp {

	public static boolean isValidEmpId(int empid){
		boolean flag=false;
		
		if(empid>=1000 && empid<=9999)
			flag=true;
			
			return flag;
	}
	
	

	public static boolean isValidFirstName(String firstName){
		return firstName.matches("[A-Z][a-z]+");
	}
	
	public static boolean isValidLastName(String lastname){
		return lastname.matches("[A-Z][a-z]+");
	}
	
	public static boolean isValidAddress(String address){
		return address.matches("[A-Z][a-z]+[#|-|/]");
	}
	
	public static boolean isValidEmailId(String emailId){
		return emailId.matches("[a-z]+[@][a-z]+[.][com|in]");
	}
	
	public static boolean isValidMobileNo(String mobileNo){
		return mobileNo.matches("[7|8|9]{10}");
	}
	
	public static boolean isValidDateOfBirth(String dob){
		return dob.matches("[123]\\d{2}-(jan|feb)-[12][890]\\d{4}");
	}
	
	public static boolean isValidDateOfJoining(String doj){
		return doj.matches("\\d{2}[dd-MM-YYYY]");
	}
	public static boolean isValidEmpID(String empId) {
		
		return empId.matches("[1000-9999]{4}");
	}


	public static boolean isValidKinid(String kinId) {
		// TODO Auto-generated method stub
		return kinId.matches("\\d{5}_[F|I|T][S]");
	}





	
}
