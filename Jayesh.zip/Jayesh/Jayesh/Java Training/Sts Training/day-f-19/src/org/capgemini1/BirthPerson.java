package org.capgemini1;

import java.util.Date;
import java.util.Scanner;
public class BirthPerson {

	public static void main(String[] args) {
	
		//Date myDate=new Date(0);
	
		String str="21-feb-1990";
		Date date=new Date(str);
		
		System.out.println(date);
		System.out.println(date.getYear());
		System.out.println(date.getMonth());
		System.out.println(date.getDate());
		
		
		System.out.println(date.getTime());
		
		Date date1=new Date();
		System.out.println(date1.getYear());
		//System.out.println(date1.getYear());
		System.out.println(date1.getMonth());
		System.out.println(date1.getDate());
		
		int ageyear=(date1.getYear()-date.getYear());
		int agemonth=(date1.getMonth()-date.getMonth());
		int agedate=(date1.getDate()-date.getDate());
		
		System.out.println("Present Year Age:"+ ageyear);
		System.out.println("Present Month Age:"+ agemonth);
		System.out.println("Present date Age:"+ agedate);
		
	//	Date date2=new Date();
		
		
	
	}
	
}
