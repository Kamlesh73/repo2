package org.capgemini1;

public class MyMainClass {

	public static void main(String[] args) {
		Employeee emp=new Employeee();
		emp.getDetails();
		emp.printEmployeee();

	}

}
