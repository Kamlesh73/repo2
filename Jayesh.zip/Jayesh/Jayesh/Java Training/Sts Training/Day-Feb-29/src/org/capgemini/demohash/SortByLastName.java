package org.capgemini.demohash;

import java.util.Comparator;

public class SortByLastName implements Comparator<EmployeeHash>{

	@Override
	public int compare(EmployeeHash lstName1, EmployeeHash lstName2) {
		if(lstName1.getLastName().compareTo(lstName2.getLastName())>0)
			return 1;
		else if(lstName1.getLastName().compareTo(lstName2.getLastName())<0)
			return -1;
		else
			return 0;
	}



	
		

	}


