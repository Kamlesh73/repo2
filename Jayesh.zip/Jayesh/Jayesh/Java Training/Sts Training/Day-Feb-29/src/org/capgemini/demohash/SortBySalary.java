package org.capgemini.demohash;

import java.util.Comparator;

public class SortBySalary implements Comparator<EmployeeHash>{

	@Override
	public int compare(EmployeeHash sal1, EmployeeHash sal2) {
		if(sal1.getSalary()>sal2.getSalary())
			return 1;
		else if(sal1.getSalary()<sal2.getSalary())
			return -1;
		else
			return 0;

	}

	}
