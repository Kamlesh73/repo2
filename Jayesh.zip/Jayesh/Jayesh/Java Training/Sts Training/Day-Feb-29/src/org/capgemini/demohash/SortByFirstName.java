package org.capgemini.demohash;

import java.util.Comparator;

public class SortByFirstName implements Comparator<EmployeeHash> {

	@Override
	public int compare(EmployeeHash fstName1, EmployeeHash fstName2) {
		if(fstName1.getFirstName().compareTo(fstName2.getFirstName())>0)
			return 1;
		else if(fstName1.getFirstName().compareTo(fstName2.getFirstName())<0)
			return -1;
		else
			return 0;
	}

	

}
