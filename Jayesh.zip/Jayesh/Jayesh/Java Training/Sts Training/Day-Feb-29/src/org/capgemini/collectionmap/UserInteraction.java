package org.capgemini.collectionmap;

import java.util.Date;
import java.util.Scanner;



public class UserInteraction {

	public Account getAccountDetails(){
	
		Account acc=new Account();
		
		Scanner sc=new Scanner(System.in);
	
		long accountId;
		String accountName;
		Date openDate;
		String accountType;
		double openBalance;
		
		System.out.println("Enter Account Name:");
		accountName=sc.next();
		acc.setAccountName(accountName);
		System.out.println("Enter the opening Date");
		String date=sc.next();
		Date d1=new Date(date);
		acc.setOpenDate(d1);
		System.out.println("Enter the account Type");
		accountType=sc.next();
		acc.setAccountType(accountType);
		System.out.println("Enter the openBalance");
		openBalance=sc.nextDouble();
		acc.setOpenBalance(openBalance);
		return acc;
		
	}
	
	public  long generateAccounId()
	{
		double m=Math.random();
		long m1=(long)m*1000000;
		return m1;
	}
}

