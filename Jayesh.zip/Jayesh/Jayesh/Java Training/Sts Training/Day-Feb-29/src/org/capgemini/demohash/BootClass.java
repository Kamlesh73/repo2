package org.capgemini.demohash;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Iterator;
import java.util.Scanner;
import java.util.TreeSet;



public class BootClass {

	public static void main(String[] args) {
		
		ArrayList<EmployeeHash> set=new ArrayList<>();
		//TreeSet<EmployeeHash> set=new TreeSet<>();
		set.add(new EmployeeHash(101, "Jack", "kumon", 2000));
		set.add(new EmployeeHash(201, "Seeta", "Manjur", 1500));
		set.add(new EmployeeHash(105, "Marry", "raje", 2000));
		set.add(new EmployeeHash(201, "Ram", "kanjur", 1500));
		set.add(new EmployeeHash(201, "Seeta", "Manjur", 1500));
		set.add(new EmployeeHash(105, "Marry", "raje", 2000));
		
	
		Scanner sc=new Scanner(System.in);
		String choice;
		int option;
		do{
			System.out.println("1.Sort By EmpId: ");
			System.out.println("2.Sort By FirstName: ");
			System.out.println("3.Sort By LastName: ");
			System.out.println("4.Sort By Salary:");
			System.out.println("Enter your option");
			option=sc.nextInt();
			if(option==1)
				Collections.sort(set);
			
			else if(option==2)
				Collections.sort(set,new SortByFirstName());
			else if(option==3)
				Collections.sort(set,new SortByLastName());
			else if(option==4)
				Collections.sort(set,new SortBySalary());
	//	}while(option==1||option==2||option==3||option==4);
			Iterator<EmployeeHash>itr=set.iterator();
			while(itr.hasNext())
				System.out.println(itr.next());
			
		System.out.println("Wish to Continue?[y|n]");
		choice=sc.next();
	
	}while(choice.charAt(0)=='Y'|| choice.charAt(0) =='y'||choice.charAt(0)=='N'|| choice.charAt(0) =='n');
	
	}

}
