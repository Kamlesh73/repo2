package org.capgemini.collectionmap;

import java.util.Collections;
import java.util.Iterator;
import java.util.Scanner;



public class BootClass {

	public static void main(String[] args) {
		
		Scanner sc=new Scanner(System.in);
		Account acc1=null;
		AccountDAO accd=new AccountDAO();
		UserInteraction intr=new UserInteraction();
		int option1,option2;
		String choice;
		do{
			
			System.out.println("1.Create Account");
			System.out.println("2.Delete Accounts");
			System.out.println("3.List All Account");
			System.out.println("4.Search Account");
			System.out.println("5.Update Account");
			System.out.println("6.Sort:");
			System.out.println("Enter your Option:");
			option1=sc.nextInt();
			
			if(option1==1)
			{
				 acc1=new Account();
				acc1=intr.getAccountDetails();
				 long accountId = intr.generateAccounId();
				accd.saveAccount(accountId,acc1);
				
				
			}
			if(option1==3)
			{		accd.listAllAccount();
				
			}
			
			System.out.println("Wish to continue(y/n)");
			choice=sc.next();
		}while(choice.charAt(0)=='y'||choice.charAt(0)=='Y');
		


	}
}

