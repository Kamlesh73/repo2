package org.capgemini.collectionmap;

public class X {

	public static void main(String[] args) {
		String str="Hello World";
		System.out.println(str.charAt(10));

	}

}
