package org.capgemini.demohash;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.TreeSet;

public class TestHash {

	public static void main(String[] args) {
		ArrayList<EmployeeHash> set=new ArrayList<>();
		//TreeSet<EmployeeHash> set=new TreeSet<>();
		set.add(new EmployeeHash(101, "Jack", "kumon", 2000));
		set.add(new EmployeeHash(201, "Seeta", "Manjur", 1500));
		set.add(new EmployeeHash(105, "Marry", "raje", 2000));
		set.add(new EmployeeHash(201, "Ram", "kanjur", 1500));
		set.add(new EmployeeHash(201, "Seeta", "Manjur", 1500));
		set.add(new EmployeeHash(105, "Marry", "raje", 2000));
		
		EmployeeHash emp=new EmployeeHash(204, "Harry","Gaolem", 20000);
		set.add(emp);
		set.add(emp);
	//	System.out.println(set);
		
		Collections.sort(set);
		
		
		Iterator<EmployeeHash>itr=set.iterator();
		while(itr.hasNext())
			System.out.println(itr.next());
		
	}
	

}
