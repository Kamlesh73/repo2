package org.capgemini.demo;

public class TestMain {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		SortArray array=new SortArray();
		
		array.getArrayElements();
		//array.printArrayElements();
		
		System.out.println("Reverse Elements");
		//array.sortArray();
		array.printrevArrayElements();
	}

}
