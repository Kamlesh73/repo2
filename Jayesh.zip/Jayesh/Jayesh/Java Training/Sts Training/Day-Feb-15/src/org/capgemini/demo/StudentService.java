package org.capgemini.demo;

import java.util.Scanner;

public class StudentService {

	Students[] student;
	
	public void initializeArray(int size){
		student=new Students[size];
	}
	
	Scanner sc=new Scanner(System.in);
	public void getStudents(){
		
		System.out.println("How many Students");
		int size=sc.nextInt();
		initializeArray(size);
		
		for(int i=0;i<size;i++){
			student[i]=new Students();
			student[i].getstudents();
	}

	
	public void printStudentDetails(){
		for(int i=0;i<student.length;i++)
			student[i].printStudentDetails();
	}
	
	public void sortfees(){
		Student stud=new Student();
		for(int i=0;i<student.length;i++)
		{
			for(int j=i+1;j<student.length:j++)
			{
				if(student[i].getfees()>student[j].getfees())
			
				{	
		Student temp=student[i];
		student[i]=student[j];
		student[j]=temp;
		
		}
			
		}
      }	
	}
}	