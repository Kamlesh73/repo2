package org.capgemini.demo;

import java.util.Scanner;

public class Students {

     private int studId;
	 private String firstName;
	 private String lastName;

	private double fees;

	Scanner sc=new Scanner(System.in);
	
	public void getstudents(){
		System.out.println("Enter Student Id:");
		studId=sc.nextInt();
			
		System.out.println("Enter Student First Name:");
		firstName =sc.next();
	
		System.out.println("Enter Student Last Name:");
		lastName=sc.next();
}

	
	public void printStudentDetails(){
		System.out.println("Id:"+ studId + "\t"+ firstName + "\t"+ lastName +"\t"+ fees);
	}
	
	public double getfees(){
		return fees;
	}
	
}	
