package org.capgemini.demo;

import java.util.Scanner;


public class Employee {
	// instance variable
	private int empId,c,cpp,java;
	private float total, average;
	
	public String firstName;
	
	private String lastName;
	private String address;
	double salary;

	public void getEmp(){
		Scanner sc=new Scanner(System.in);
		

		System.out.println("Enter Address:");
		firstName=sc.nextLine();
		
		System.out.println("Enter Empolyee Id:");
		empId=sc.nextInt();
		
		System.out.println("Enter Firstname:");
		firstName=sc.next();
		
		System.out.println("Enter Lastname:");
		lastName=sc.next();
	
		System.out.println("Enter Address:");
		address=sc.next();
		
		System.out.println("Enter Salary:");
		salary=sc.nextDouble();
		
		System.out.println("Enter marks of c:");
		c=sc.nextInt();
		
		System.out.println("Enter marks of cpp:");
		cpp=sc.nextInt();
		
		System.out.println("Enter marks of java:");
		java=sc.nextInt();
		
		total= c+cpp+java;
	}
	
	private float calculateAverage(){
		return (float)(c+cpp+java)/3;
	}

	public void printEmployee(){
	
		System.out.println("Emp Id:"+ empId);
		System.out.println("Firstname:"+ firstName);
		System.out.println("Lastname:"+ lastName);
		System.out.println("Salary:"+ salary);
		
		System.out.println("marks of c:"+ c);
		System.out.println("marks of cpp:"+ cpp);
		System.out.println("marks of java:"+ java);
		System.out.println("total="+ total);
		System.out.println("average="+ calculateAverage());
		
	//	average=calculateAverage()
	//	return empId;
		
	}
	}
	
	

