package org.capgemini.demo;

public class MainClassStudent {
	public static void main(String[]args){
		StudentService service=new StudentService();
		service.getStudents();
		service.printStudentDetails();
		service.sortfees();
	}

}
