package org.capgemini.demo;

public class MainClass {

	public static void main(String[] args) {
			//Create object
			//emp-->reference && new
		
		Employee emp=new Employee();
		
		emp.getEmp();
		emp.printEmployee();
	}

}
