package org.capgemini.demo;

import java.util.Scanner;

public class SortArray {

	int[] myArray[];
	
	public void initializeArray(int size){
		myArray=new int[size];
	}

	
	public void getArrayElements(){
		Scanner sc=new Scanner(System.in);
		System.out.println("What is the size of Array");
		int size=sc.nextInt();
		
		initializeArray(size);
		
		
		System.out.println("Enter Array Elements");
		
		for(int i=0;i<myArray.length;i++)
			myArray[i]=sc.nextInt();
	}
	
/*	public void printArrayElements(){
		for(int i=0;i<myArray.length;i++)
		System.out.print(myArray[i]);
		System.out.println(myArray[i]);
	*/
		///print reverse element
		public void printrevArrayElements(){
			for(int i=myArray.length-1;i>=0;i--){
			System.out.println(myArray[i]);
		//	System.out.println(myArray[i]);
		}
	}
	
	public void sortArray(){
		for(int i=0;i<myArray.length;i++){
			for(int j=i+1;j<myArray.length;j++){
					int temp=myArray[i];
				if (myArray[i]>myArray[j]){
					myArray[i]=myArray[j];
					myArray[j]=temp;
				
			   }
			}
		}
	}
	
}
	
