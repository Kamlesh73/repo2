package org.capgemini.demo;

import java.util.Scanner;

public class OddEvenSeries {

	public static void main(String[] args) 
    {
        int n,i,j;
        final int step=3;
        
        Scanner sc =new Scanner (System.in);
        System.out.println("Enter the elements of an array");
        n=sc.nextInt();
          
        for(i = 0 ; i < n ; i+=step*2)
        {
            
        for (j = 0; j <n; j++) 
        {
        	
        	System.out.print(i+j*2+1);
        }
  //      
        for(j = 0 ; j <step;j++)
        {
        	 System.out.print(i+j*2);
        }
       
      
       } 
    }
}
