public class TransMatrix {
 /** Main method */
  public static void main(String[] args) {
 Scanner sc = new Scanner(System.in);
 System.out.print("Enter the number of rows (1-10): ");
 int rows = input.nextInt();
 System.out.print("Enter the number of columns (1-10): ");
 int cols = input.nextInt();

 // Create originalMatrix as rectangular two dimensional array
 int[][] originalMatrix = new int[rows][cols];

 // Assign random values to originalMatrix
 for (int row = 0; row < originalMatrix.length; row++)
  for (int col = 0; col < originalMatrix[row].length; col++) {
    originalMatrix[row][col] = (int) (Math.random() * 1000);
  }

 // Print original matrix
 System.out.println("\nOriginal matrix:");
 printMatrix(originalMatrix);

 // Transpose matrix
 int[][] resultMatrix = TransposeMatrix(originalMatrix);


 // Print transposed matrix
 System.out.println("\nTransposed matrix:");
 printMatrix(resultMatrix);
}

 /** The method for printing the contents of a matrix */
   public static void printMatrix(int[][] matrix) {
 for (int row = 0; row < matrix.length; row++) {
  for (int col = 0; col < matrix[row].length; col++) {
    System.out.print(matrix[row][col] + "  ");
  }
  System.out.println();
} 
}


 /** The method for transposing a matrix */
}