import java.util.Scanner;
public class Fibonaci
{
	public static void main(String[] args)
	{
		int i,n=10;
		int a=0;
		int b=1;
		int c;
				
		for(i=0;i<n;i++);
		 {
			c= a+b;
			a=b;
			b=c;
			System.out.print(c);
		 
		 }
	}

}