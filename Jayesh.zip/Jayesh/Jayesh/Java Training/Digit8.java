import java.util.Scanner;
public class Digit8
{
	public static void main(String[] args)
	{
		int row=5,col=4;
		
		int i=0,j=0;
		
		for(i=0;i<row;i++){
			for(j=0;j<col;j++){
				if(i%2==0 || j==col-1 || j==0)
				System.out.print("*");
				else
				System.out.print(" ");
			}
			System.out.println();
		}
	}
}