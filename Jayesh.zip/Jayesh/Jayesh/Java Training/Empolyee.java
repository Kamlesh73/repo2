import java.util.scanner;
public class Employee
{
	public static void main(_String[] args)
	{
	String ename;
	double salary,bonus;
	
	Scanner sc=new scanner(System.in);
	
	System.out.println("Enter name:");
	ename=sc.next();
	
	System.out.println("Enter name:");
	salary=sc.nextDouble();

	if(salary>2000000)
	{ bonus=salary*.15;
		else if(salary>1000000){
		bonus=salary*.20;
		}else if(salary>500000){
		bonus=salary*.25;
		}else
		{bonus=salary*.30;}
		System.out.println("Bonus" + (bonus));
	}
	}
	}
	}
}