import java.util.Scanner;
public class DemoTwoDimensional{
	public static void main(String[] args){
	
		//int[][] myArr= new int [3][3];
		//int[] myArr[]= new int [3][3]; c
		int myArr[][]= new int [3][3];
		
			Scanner sc=new Scanner(System.in);
		
		for(int i=0;i<3;i++)
		{	for(int j=0;j<3;j++)
				{
					myArr[i][j]=sc.nextInt();
				}
		}			
		
	System.out.println("\n\n");
		for(int i=0;i<3;i++)
		{	for(int j=0;j<3;j++)
				{
					System.out.print(myArr[i][j] +"\t");
				}
	    System.out.println();
		}
	}
	}