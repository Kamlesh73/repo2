import java.util.scanner;

public class Bisgest{

	public static void main(String[] args){
		int n1,n2,n3;
		
Scanner sc=new scanner (System.in);

System.out.println("Enter first number n1");
n1=sc.nextInt();

System.out.println("Enter first number n2");
n2=sc.nextInt();

System.out.println("Enter first number n3");
n3=sc.nextInt();

if(n1>n2&&n1>n3)
{ 
     System.out.println("n1 is bigher among all");
     
}elseif(n2>n3)
	{
	System.out.println("n2 is bigher among all");
	}
else{
	System.out.println("n3 is bigher among all");
}

}
}