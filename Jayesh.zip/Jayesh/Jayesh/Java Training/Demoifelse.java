class Demoifelse{
	public static void main(String[] args){

	int num=34;
	if(num>0){
		System.out.println("Positive");
		System.out.println("Num"+ num);
	}else{
		System.out.println("negative");
	}
	System.out.println("Program completed");
	}
}