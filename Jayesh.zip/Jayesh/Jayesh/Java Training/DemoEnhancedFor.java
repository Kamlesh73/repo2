public class DemoEnhancedFor{
	public static void main(String[] args){
	String names={"tom", "jerry", "jack"};
	
		for (int i=0;i<names.length;i++)
		System.out.println(names[i]);
		
		System.out.println("\n\n\n");
		for(String str:names)
		System.out.println(names[i]);
		}
	}

	
	
	
//////Errors:
