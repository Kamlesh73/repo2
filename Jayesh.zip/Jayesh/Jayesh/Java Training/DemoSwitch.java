import java.util.Scanner;
public class DemoSwitch
{
	public static void main(String[] args)
	{		char chr='j';
	
	
		switch(chr){
			default:
				System.out.println("Other Colour");
				break;
			case 'r':
			case 'R':
				System.out.println("RED");
				break;
			case 'g':
			case 'G':
				System.out.println("Green");
				break;
			case 'b':
			case 'B':
				System.out.println("Blue");		
		}
	}
}	