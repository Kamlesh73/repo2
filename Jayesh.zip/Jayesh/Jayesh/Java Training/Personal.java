import java.util.Scanner;

public class Personal {
	public static void main(String[] args){
		String firstName;
		String lastName;
		String address;
		int java;
		int sql;
		int html;
		float average;
		int total;

Scanner sc=new Scanner (System.in);

System.out.println("Enter firstName:");
firstName=sc.next();
System.out.println("Enter lastName:");
lastName=sc.next();
System.out.println("Enter address:");
 address=sc.next();
/*// option = sc.nextInt ();
System.out.println("Road"); 
address=sc.nextline();
//String string1 = sc.nextLine ();
System.out.println("Area");
//String string2 = sc.nextLine ();
*/
System.out.println("Marks obtained for Java:");
java=sc.nextInt();
System.out.println("Marks obtained for Sql:");
sql=sc.nextInt();
System.out.println("Marks obtained for Html:");
html=sc.nextInt();



	System.out.println("Average of all subjects=" + ((java+sql+html)/3));
	System.out.println("Total of all subjects=" + (java+sql+html));
	}

}