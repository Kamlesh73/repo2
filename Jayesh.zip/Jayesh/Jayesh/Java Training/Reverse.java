import java.util.Scanner;
public class Reverse{
	public static void main(String[] args){
			final int SIZE=10;
			//int i;
	
			//int [] my Arr={10,20,30,40,50};
			
			Scanner sc=new Scanner(System.in);
			int myArr[]=new int[SIZE];		
					
					//store the elements in the array
			System.out.println("ENTER 10 Numbers:");		
			for(int i=0;i<SIZE;i++)
			myArr[i]=sc.nextInt();
					
					//Retrive the element f4rom the aray
			for(int i=SIZE-1;i>=0;i--){
				System.out.println(myArr[i]);
				}
			}
}			