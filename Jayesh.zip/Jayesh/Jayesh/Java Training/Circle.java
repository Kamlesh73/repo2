import java.util.Scanner;

public class Circle {
	public static void main(String[] args){
		float radius;
		final float pi =3.14f;
Scanner sc=new Scanner (System.in);

/*pi =

*/

System.out.println("Enter Radius:");
radius=sc.nextFloat();
	System.out.println("Area :" + (pi*radius*radius));
	}

}