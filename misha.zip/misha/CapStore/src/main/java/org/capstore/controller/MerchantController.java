//** The Controller contains code that is is invoked based on certain events*/

package org.capstore.controller;
import org.capstore.domain.Category;
import org.capstore.domain.chat;
import org.capstore.domain.Discount;
import org.capstore.domain.Images_Electronics;
import org.capstore.domain.chat;
import org.capstore.domain.coupon;
import org.capstore.domain.images_furnitures;
import org.capstore.domain.product;
import org.capstore.domain.sub_category;
import org.capstore.service.CategoryService;
import java.util.List;
import java.util.Map;
import javax.persistence.Query;
import javax.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;

@Controller
public class MerchantController 
{

	
	//****************************************************************************************/
	@Autowired
	private CategoryService categoryService;

     //Display the Page
	//****************************************************************************************/
	@RequestMapping(value="/MostViewed",method=RequestMethod.GET,
			produces={"application/json"})
	public  String getAll()
	{
		
		return "MostViewed";
	}	

	
	/****************************************************************************************/
	@RequestMapping(value="/mostviewed",method=RequestMethod.GET,
			produces={"application/json"})

	public  @ResponseBody List<product> getmost()
	{
		List<product> mostviewed=categoryService.getmostVisitedFurniture();

		return mostviewed;

	}
	
	//****************************************************************************************/
	
	@RequestMapping(value="/chat",method=RequestMethod.GET,
			produces={"application/json"})

	public  @ResponseBody List<chat> getChat1()
	{
		List <chat> chat=categoryService.getChat();
		System.out.println(chat);

		return chat;
	}
	 //Display the Page
	//****************************************************************************************/
	
	 @RequestMapping(value="/Ascending",method=RequestMethod.GET,
			produces={"application/json"})
	public  String getAscending()
	{
		
		return "Ascending";
	}

	
	
	 //****************************************************************************************/
	@RequestMapping(value="/ascending",method=RequestMethod.GET,
			produces={"application/json"})

	public  @ResponseBody List<product> getascending()
	{
		List<product> ascending=categoryService.getAscendingPrice();

		return ascending;

	}	 
	 
	//****************************************************************************************/
	
	 @RequestMapping(value="/ShowCoupon",method=RequestMethod.GET,
			produces={"application/json"})
	 
	 public String showAccountPage(Map<String, Object> map)
	 {
			
			map.put( "coupon", new coupon());
		
			return "ShowCoupon";
	}

	 //****************************************************************************************/
	 
	 @RequestMapping(value={"/GenerateCoupon","/updateCoupon"},method=RequestMethod.GET)
		public String showCouDetails(Map<String, Object> map,
				
				@Valid @ModelAttribute("coupon") coupon coupon, BindingResult result){
		 
			
			System.out.println(coupon);					
			return "GenerateCoupon";
			
		}	 
	 
	
	 //****************************************************************************************/
	
	@RequestMapping(value="/showcoupon",method=RequestMethod.GET,
			produces={"application/json"})

	public  @ResponseBody List<product> getcoupon()
	{
		List<product> showcoupon=categoryService.getCoupon();

		return showcoupon;


	} 
	 
	 //Display the Page
	//****************************************************************************************/
	 
	 @RequestMapping(value="/Rating",method=RequestMethod.GET,
			produces={"application/json"})
	public  String getRating()
	{
		
		return "Rating";
	}
	
	//****************************************************************************************/
	
	@RequestMapping(value="/rating",method=RequestMethod.GET,
			produces={"application/json"})

	public  @ResponseBody List<product> getrating()
	{
		List<product> rating=categoryService.getRating();

		return rating;


	}
	 //Display the Page
	//****************************************************************************************/
	
	 @RequestMapping(value="/Descending",method=RequestMethod.GET,
			produces={"application/json"})
	public  String getDescending()
	{
		/*List<Category> categories=categoryService.getAllCategories();
		map.put("categories", categories);
		System.out.println(categories);*/
		return "Descending";
	}
	
	 //****************************************************************************************/
	
	@RequestMapping(value="/descending",method=RequestMethod.GET,
			produces={"application/json"})

	public  @ResponseBody List<product> getdesc()
	{
		List<product> descending=categoryService.getDescendingPrice();

		return descending;

	} 
	 //Display the Page
	//****************************************************************************************/
	


	@RequestMapping(value="/HomePage",method=RequestMethod.GET,
			produces={"application/json"})
	public  String getAllCategories()
	{
		
		return "HomePage";
	}

	 //Display the Page
	//****************************************************************************************/

	@RequestMapping(value="/Furniture",method=RequestMethod.GET,
			produces={"application/json"})
	public  String getAllFurniture()
	{
		
		return "Furniture";
	}


	 //Display the Page
	//****************************************************************************************/



	@RequestMapping(value="/Kitchenware",method=RequestMethod.GET,
			produces={"application/json"})

	public  String getAllKitchen()
	{
		
		return "Kitchenware";
	}


	 //Display the Page
	//****************************************************************************************/
	
	

	@RequestMapping(value="/HomeAppliance",method=RequestMethod.GET,
			produces={"application/json"})

	public  String getAllHome()
	{
		
		return "HomeAppliance";
	}
	 //Display the Page
	//****************************************************************************************/
	@RequestMapping(value="/Chat",method=RequestMethod.GET,
			produces={"application/json"})

	public  String getAllChat()
	{
		
		return "Chat";
	}
	
	
	//****************************************************************************************/
	

	
	
	@RequestMapping(value="/view",method=RequestMethod.GET,
			produces={"application/json"})
	public  @ResponseBody List<product> getview()
	{
		List<product> view=categoryService.getmostVisitedFurniture();

		return view;
	}
	
	
	//****************************************************************************************/
	

	@RequestMapping(value="/categories",method=RequestMethod.GET,
			produces={"application/json"})
	public  @ResponseBody List<Category> getCategories()
	{
		List<Category> categories=categoryService.getAllCategories();

		return categories;
	}


	
	//****************************************************************************************/

	@RequestMapping(value="/furnitures",method=RequestMethod.GET,
			produces={"application/json"})

	public  @ResponseBody List<product> getFurniture()
	{
		List<product> furnitures=categoryService.getAllFurniture();

		return furnitures;
	}

	//****************************************************************************************/

	@RequestMapping(value="/kitchen",method=RequestMethod.GET,
			produces={"application/json"})

	public  @ResponseBody List<product> getKitchen()
	{
		List<product> kitchen=categoryService.getAllKitchen();

		return kitchen;

	}
	
	//****************************************************************************************/

	@RequestMapping(value="/home",method=RequestMethod.GET,
			produces={"application/json"})

	public  @ResponseBody List<product> getHome()
	{
		List<product> home=categoryService.getAllHome();
		return home;

	}

	//****************************************************************************************/
	@RequestMapping(value="/subcategories",method=RequestMethod.GET,

			produces={"application/json"})

	public @ResponseBody List<sub_category> getAllSubCategories()
	{
		List<sub_category> subcategories=categoryService.getsubcategory1();
		System.out.println(subcategories);

		return subcategories;
	}

	//****************************************************************************************/

//**** Save Coupon****/
	
	@RequestMapping(value="/saveCoupon",method=RequestMethod.POST)
	public ModelAndView saveAccount(@Valid @ModelAttribute("coupon") coupon coupon,
			BindingResult result)	
	{
		
		if(!result.hasErrors())
		{
			System.out.println(coupon);
			categoryService.saveCoupon(coupon);		
		}
		
		else
		{
			return new ModelAndView("HomePage");
		}
			
		return new ModelAndView("redirect:HomePage");
	
	}

	 //Display the Page
	//****************************************************************************************/

@RequestMapping(value={"/Uploade","/updateCoupon"},method=RequestMethod.GET)
public String showDetails(Map<String, Object> map,
		
		@Valid @ModelAttribute("Images_Electronics") Images_Electronics Images_Electronics, BindingResult result){
 
	
	   System.out.println(Images_Electronics);		
		
		return "Uploade";
	
}



//*****************************************************************************************
//**** Save Coupon****/

	@RequestMapping(value="/saveImage",method=RequestMethod.POST)
	public ModelAndView saveAccount(@Valid @ModelAttribute("Images_Electronics") Images_Electronics Images_Electronics,
			BindingResult result)
	
	{
		
		if(!result.hasErrors()){
			System.out.println(Images_Electronics);
			categoryService.saveImage(Images_Electronics);
			
			
		}
		
		else
		{
			return new ModelAndView("HomePage");
		}
			
			return new ModelAndView("redirect:HomePage");
	
	}


//************************************************************************************


	@RequestMapping(value={"/startChat","/updateCoupon"},method=RequestMethod.GET)
	public String showDetails(Map<String, Object> map,
			
			@Valid @ModelAttribute("chat") chat chat, BindingResult result){
	 
		
		System.out.println(chat);
		
			return "startChat";
		
	}


	//*****************************************************************************************
	//**** Save Coupon****/

		@RequestMapping(value="/saveDiscount",method=RequestMethod.POST)
		public ModelAndView saveAccount(@Valid @ModelAttribute("Discount") Discount Discount,
				BindingResult result)
		
		{
			
			if(!result.hasErrors()){
				System.out.println(Discount);
				categoryService.saveDiscount(Discount);
				
				
			}
			
			else
			{
				return new ModelAndView("HomePage");
			}
				
				return new ModelAndView("redirect:HomePage");
		
		}
		
		
		
		
		//**** Save Coupon****/
		//**************************************************************************************************************

			@RequestMapping(value="/saveChat",method=RequestMethod.POST)
			public ModelAndView saveAccount(@Valid @ModelAttribute("chat") chat chat,
					BindingResult result)
			
			{
				
				if(!result.hasErrors())
				{
					System.out.println(chat);
					categoryService.saveChat(chat);				
					
				}
				
				else
				{
					return new ModelAndView("startChat");
				}
					
					return new ModelAndView("redirect:startChat");
			
			}

}







	


