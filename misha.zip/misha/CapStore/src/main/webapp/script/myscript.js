//***************************Script File that contains Module and Ctrl of Angular JS*****/

var app=angular.module("myApp",[]);

app.controller("ctrl",function($scope,$http){
	$http.get('http://localhost:8080/CapStore/categories').
	success(function(data){
		$scope.category=data;
	});


});
//***************************************************************************************

app.controller("ctrl1",function($scope,$http){
	$http.get('http://localhost:8080/CapStore/subcategories').
	success(function(data){
		$scope.subcategory=data;

	});


});
//***************************************************************************************

app.controller("ctrl2",function($scope,$http){
	$http.get('http://localhost:8080/CapStore/furnitures').
	success(function(data){
		$scope.furniture=data;

	});


});

//***************************************************************************************
app.controller("ctrl3",function($scope,$http){
	$http.get('http://localhost:8080/CapStore/kitchen').
	success(function(data){
		$scope.kitchen=data;

	});


});

//***************************************************************************************

app.controller("ctrl4",function($scope,$http){
	$http.get('http://localhost:8080/CapStore/home').
	success(function(data){
		$scope.home=data;

	});


});

//***************************************************************************************

app.controller("ctrl5",function($scope,$http){
	$http.get('http://localhost:8080/CapStore/mostviewed').
	success(function(data){
		$scope.mostviewed=data;

	});


});

//***************************************************************************************

app.controller("ctrl6",function($scope,$http){
	$http.get('http://localhost:8080/CapStore/ascending').
	success(function(data){
		$scope.ascending=data;

	});


});

//***************************************************************************************
app.controller("ctrl7",function($scope,$http){
	$http.get('http://localhost:8080/CapStore/descending').
	success(function(data){
		$scope.descending=data;

	});


});

//***************************************************************************************
app.controller("ctrl8",function($scope,$http){
	$http.get('http://localhost:8080/CapStore/rating').
	success(function(data){
		$scope.rating=data;

	});


});


//***************************************************************************************
app.controller("ctrl9",function($scope,$http){
	$http.get('http://localhost:8080/CapStore/showcoupon').
	success(function(data){
		$scope.showcoupon=data;

	});


});

//***************************************************************************************



app.controller("ctrl10",function($scope,$http){
	$http.get('http://localhost:8080/CapStore/chat').
	success(function(data){
		$scope.chat=data;

	});


});
//***************************************************************************************

$('input[type=file]').change(function () {
	console.log(this.files[0].mozFullPath);
});


