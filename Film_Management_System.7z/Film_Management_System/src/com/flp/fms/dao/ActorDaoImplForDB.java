package com.flp.fms.dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;


import com.flp.fms.domain.Actor;

public class ActorDaoImplForDB implements IActorDao{

	@Override
	public List<Actor> addActor() {
		// TODO Auto-generated method stub
		return null;
	}

	
	
	public Connection  getConnection(){
		
		Connection connection=null;
		try {
			Class.forName("com.mysql.jdbc.Driver");
			System.out.println("Driver Registered");
			connection=DriverManager.getConnection("jdbc:mysql://localhost:3306/fms_bd", "root", "Pass1234");
			System.out.println("connection created");
			
			
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		return connection;
	} 


	@Override
	public List<Actor> getActorList() {
		List<Actor> actors=new ArrayList<>();
		
		FilmDaoImplForDB filmDao=new FilmDaoImplForDB();
		Connection con= filmDao.getConnection();
		
		String sql="select * from Actors";
		try {
			PreparedStatement pst=con.prepareStatement(sql);
			ResultSet rs=pst.executeQuery();
			
			while(rs.next())
			{
				Actor actor=new Actor();
				actor.setActor_id(rs.getInt(1));
				actor.setActor_FirstName(rs.getString(2));
				actor.setActor_LastName(rs.getString(3));
				
				actors.add(actor);
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return actors;
	

	}

	//Adding Actors to the Database

	public int saveActor(Actor actor)
	{

		Connection con=getConnection();

		String sql="INSERT INTO actors (firstName,lastName)VALUES(?,?)";				

		int id = 0,count=0;
		try 
		{
			PreparedStatement pst=con.prepareStatement(sql);
			pst.setString(1, actor.getActor_FirstName());
			pst.setString(2, actor.getActor_LastName());
			
			count=pst.executeUpdate();
			con.close();
		}
		catch(Exception e){}

		return count;
	}


//Deleting Actor from the Database
	
	public boolean deleteActor(int actorId)
	{
		
		Connection con=getConnection();		
		boolean flag=false;

		String sql="delete from actors where actor_id =?";
		
		
		try {
			PreparedStatement pst=con.prepareStatement(sql);
		
			pst.setInt(1, actorId);			

			int count=pst.executeUpdate();			

			if(count>0)
				flag=true;
			con.close();
		} 
		catch (SQLException e)
		{

			e.printStackTrace();
		}	
		return flag;
		
		
	}
	
//Retrieving all actors from Database


	public List<Actor> getAllActors() 
	{
		List<Actor> actorList=new ArrayList<>();

		//String sql="SELECT * FROM actors ORDER BY firstname ASC ";
		String sql="SELECT * FROM actors ORDER BY actor_id ";
		
		Connection con=getConnection();
		try {
			PreparedStatement pst=con.prepareStatement(sql);
			ResultSet rs=pst.executeQuery();

			while(rs.next())
			{
				Actor actor=new Actor();
				actor.setActor_id(rs.getInt(1));
				actor.setActor_FirstName(rs.getString(2));
				actor.setActor_LastName(rs.getString(3));
				//Adding Actor into List
				actorList.add(actor);
			}

			con.close();
		} 
		catch (SQLException e)
		{

			e.printStackTrace();
		}
		return actorList;
}

	


}














	
	

	




	
	


	
