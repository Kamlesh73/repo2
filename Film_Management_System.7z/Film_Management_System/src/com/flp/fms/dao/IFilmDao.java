package com.flp.fms.dao;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import com.flp.fms.domain.Category;
import com.flp.fms.domain.Film;
import com.flp.fms.domain.Language;
import com.flp.fms.domain.UserLogin;

public interface IFilmDao {
	
	public List<Language> getLanguages();

	public List<Category> getCategory();
	
	public int addFilm(Film film);
	
	public ArrayList<Film> getAllFilms();
	
	public Boolean deleteFilm(int film_id);

	public List<Film> searchFilm(Film film);

	public Film getFilmByID(int id);

	public int updateFilm(int id, Film film);
	
	boolean isValidUser(UserLogin login);
}
