package com.flp.fms.service;

import java.util.List;

import com.flp.fms.dao.ActorDaoImplForDB;
import com.flp.fms.dao.IActorDao;
import com.flp.fms.domain.Actor;

public class ActorServiceImpl implements  IActorService {

	ActorDaoImplForDB actorDao=new ActorDaoImplForDB();
	
	@Override
	public List<Actor> addActor() {
		//return added actor
		return actorDao.addActor();
	}

	@Override
	public List<Actor> getActorList() {
	
		//return actors list;
		return actorDao.getActorList();
	}

	
	public List<Actor> getAllActors(){
		//return all actors	
		return actorDao.getAllActors();
	}
	
	
	public int saveActor(Actor actor){
		//return saved actor
		return actorDao.saveActor(actor);
	}
	
	
	public boolean deleteActor(int actorId){
		//return deleted actor
		return actorDao.deleteActor(actorId);
	}

	
}

