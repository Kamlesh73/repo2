package com.flp.fms.service;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import com.flp.fms.dao.FilmDaoImplForDB;
import com.flp.fms.dao.IFilmDao;
import com.flp.fms.domain.Actor;
import com.flp.fms.domain.Category;
import com.flp.fms.domain.Film;
import com.flp.fms.domain.Language;
import com.flp.fms.domain.UserLogin;

public class FilmServiceImpl implements IFilmService {

	IFilmDao filmDao=new FilmDaoImplForDB();
	
	
	@Override
	public boolean isValidUser(UserLogin login) {
	
		return filmDao.isValidUser(login);
	}

	
	@Override
	public List<Language> getLanguages() {
		
		return filmDao.getLanguages();
	}

	@Override
	public List<Category> getCategory() {
		
		return filmDao.getCategory();
	}

	@Override
	public int addFilm(Film film) {
		
		return filmDao.addFilm(film);
		
	}

	@Override
	public ArrayList<Film> getAllFilms() {
		
		return filmDao.getAllFilms();
	}

	@Override
	public boolean deleteFilm(int film_id) {
		
		return filmDao.deleteFilm(film_id);
	}

	@Override
	public List<Film> searchFilm(Film film) {
		
		return filmDao.searchFilm(film);
	}
	@Override
	public Film getFilmByID(int id) {
		
		return filmDao.getFilmByID(id);
	}
	@Override
	public int updateFilm(int id, Film film) {
		
		return filmDao.updateFilm(id, film);
	}


	
	
}
	