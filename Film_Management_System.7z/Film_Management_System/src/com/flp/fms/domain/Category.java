package com.flp.fms.domain;

public class Category {

	private int Category_id;
	private String Category_name;
	//private int Film_id;

//No Argument Constructor
	public Category(){}

// Argument Constructor
	public Category(int category_id, String category_name) {
		super();
		Category_id = category_id;
		Category_name = category_name;
		
	}

//getter and setter
	public int getCategory_id() {
		return Category_id;
	}

	public void setCategory_id(int category_id) {
		Category_id = category_id;
	}

	public String getCategory_name() {
		return Category_name;
	}

	public void setCategory_name(String category_name) {
		Category_name = category_name;
	}

	

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + Category_id;
		result = prime * result + ((Category_name == null) ? 0 : Category_name.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj) {
			return true;
		}
		if (obj == null) {
			return false;
		}
		if (!(obj instanceof Category)) {
			return false;
		}
		Category other = (Category) obj;
		if (Category_id != other.Category_id) {
			return false;
		}
		if (Category_name == null) {
			if (other.Category_name != null) {
				return false;
			}
		} else if (!Category_name.equals(other.Category_name)) {
			return false;
		}
		return true;
	}

	@Override
	public String toString() {
		return "Category [Category_id=" + Category_id + ", Category_name=" + Category_name + "]";
	}
	
	


	

}
