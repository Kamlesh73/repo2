package com.flp.fms.test;

import static org.junit.Assert.*;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.junit.Test;

import com.flp.fms.dao.ActorDaoImplForDB;
import com.flp.fms.dao.FilmDaoImplForDB;
import com.flp.fms.domain.Actor;
import com.flp.fms.domain.Category;
import com.flp.fms.domain.Film;
import com.flp.fms.domain.Language;
import com.flp.fms.service.FilmServiceImpl;

public class TestClass {
	
	FilmDaoImplForDB filmDao=new FilmDaoImplForDB();
	ActorDaoImplForDB actorDao=new ActorDaoImplForDB();

	
	//Test Case to check if Lists return null value
	
		@Test
		public void testForLanguageList() {
			
			FilmDaoImplForDB filmlist = new FilmDaoImplForDB();
		
			assertNotEquals(filmlist.getLanguages(), null);

		}

		@Test
		public void testForCategoryList() {
			
			FilmDaoImplForDB categorylist = new FilmDaoImplForDB();
			
			assertNotEquals(categorylist.getCategory(), null);
			
		}
		
		@Test
		public void testGetAllFilms() {
			
			FilmDaoImplForDB getallfilms = new FilmDaoImplForDB();
			
			assertNotEquals(getallfilms.getAllFilms(), null);
		}
	


//TEST CASE FOR LIST OF LANGUAGES
@Test
public void testGetLanguages(){


	List<Language>languages=new ArrayList<>();
	
	
	languages.add(new Language(1,"English"));
	languages.add(new Language(2, "HIndi"));
	languages.add(new Language(3, "Marathi"));
	languages.add(new Language(4, "Tamil"));
	languages.add(new Language(5, "Malayalam"));
	languages.add(new Language(6, "Telagu"));
	languages.add(new Language(7, "Punjabi"));
	
	assertEquals(languages, filmDao.getLanguages());

}


//TEST CASE FOR LIST FOR CATEGORY
@Test
public void testGetCategory(){

	List<Category> category=new ArrayList<>();

	category.add(new Category(1, "Romantic"));
	category.add(new Category(2, "Acton"));
	category.add(new Category(3, "Comedy"));
	category.add(new Category(4, "Horror"));
	category.add(new Category(5, "Si-Fi"));
	category.add(new Category(6, "Rom-Com"));
	category.add(new Category(7, "Family Drama"));

	assertEquals(category, filmDao.getCategory());

}

//TEST CASE FOR ACTOR LIST
@Test
public void testGetActor(){
	
	List<Actor> actor=new ArrayList<>();

	actor.add(new Actor(1, "Amir", "Khan"));
	actor.add(new Actor(2, "Salman ", "Khan"));
	actor.add(new Actor(3, "Akshay", "Kumar"));
	actor.add(new Actor(4, "Ajay", "Devgn"));
	actor.add(new Actor(5, "Varun", "Dhawan"));
	actor.add(new Actor(6, "John", "Abraham"));
	actor.add(new Actor(7, "Ranbir", "Kapur"));
	
	assertNotEquals(actor, actorDao.getActorList());

}


//UPDATE FILM
@Test
public void testUpdateFilm(){

	Film film=new Film();
	film.setFilm_id(5);
	film.setTitle("The notebook");
	film.setDescription("aaaa");
	Date d=new Date("15-apr-2016");
	film.setReleaseYear(d);

	Language lang=new Language();
	lang.setLanguage_id(1);
	film.setOriginalLanguage(lang);
	Date d1=new Date("13-may-2016");
	film.setRentalDuration(d1);
	film.setLength(11);
	film.setReplacementCost(1111);
	film.setRatings(2);
	film.setSpecialFeature("asdfg");
	Category category=new Category();
	category.setCategory_id(1);
	film.setCategory(category);

	List<Language> langs=new ArrayList<>();
	Language lang1=new Language();
	lang1.setLanguage_id(2);
	langs.add(lang);
	langs.add(lang1);
	film.setLanguages(langs);

	List<Actor> actors=new ArrayList<>();
	Actor actor1=new Actor();
	actor1.setActor_id(1);
	Actor actor2=new Actor();
	actor2.setActor_id(2);
	actors.add(actor1);
	actors.add(actor2);
	film.setActors(actors);

	assertEquals(1, filmDao.updateFilm(15, film));


}

/*
//TEST CASE FOR ADD FILM
@Test
public void testAddFilm(){

	Film film=new Film();
	film.setTitle("The notebook");
	film.setDescription("abcd");
	Date d=new Date("12-apr-2016");
	film.setReleaseYear(d);
	Language lang=new Language();
	lang.setLanguage_id(1);
	film.setOriginalLanguage(lang);
	Date d1=new Date("13-apr-2017");
	film.setRentalDuration(d1);
	film.setLength(11);
	film.setReplacementCost(1111);
	film.setRatings(2);
	film.setSpecialFeature("asdfg");
	Category category=new Category();
	category.setCategory_id(1);
	film.setCategory(category);

	List<Language> langs=new ArrayList<>();
	Language lang1=new Language();
	lang1.setLanguage_id(2);
	langs.add(lang);
	langs.add(lang1);
	film.setLanguages(langs);

	List<Actor> actors=new ArrayList<>();
	Actor actor1=new Actor();
	actor1.setActor_id(1);
	Actor actor2=new Actor();
	actor2.setActor_id(2);
	actors.add(actor1);
	actors.add(actor2);
	film.setActors(actors);
	
	assertEquals(1,filmDao.addFilm(film));
}
*/

/*
//TEST CASE FOR DELETE FILM
@Test
public void testFilmDeleted(){

	assertEquals(2,filmDao.removeFilm(5));
}

*/



}