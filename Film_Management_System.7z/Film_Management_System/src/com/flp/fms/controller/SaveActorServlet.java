package com.flp.fms.controller;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.flp.fms.domain.Actor;
import com.flp.fms.service.ActorServiceImpl;


public class SaveActorServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

		// Create Instance of service and domain for get and set data	
		Actor actor = new Actor();
		ActorServiceImpl actorservice = new ActorServiceImpl();
	
		//Retervie  the data from various fields in the AddFilm Servlet

		actor.setActor_FirstName(request.getParameter("firstName"));			
		actor.setActor_LastName(request.getParameter("lastName"));
		
		// Invoke the saveFilm Method in the FilmImplementation table
		actorservice.saveActor(actor);
		PrintWriter out=response.getWriter();		
		out.println("<html><body>");
		out.println("<h1>Actor Details Added Successfully</h1>");
		out.println("</body></html>");

	}

	}


