package com.flp.fms.controller;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.flp.fms.domain.UserLogin;
import com.flp.fms.service.FilmServiceImpl;


public class LoginServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		UserLogin login=new UserLogin();
		FilmServiceImpl filmService=new FilmServiceImpl();
		
		String user=request.getParameter("uname");
		String pass=request.getParameter("pass");
		
		login.setUsername(user);
		login.setPassword(pass);
		
		
		if(filmService.isValidUser(login))
			response.sendRedirect("pages/home.html");
		else
			response.sendRedirect("pages/login.html");
		
	}

}
