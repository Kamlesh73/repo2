package com.flp.fms.controller;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.flp.fms.domain.Actor;
import com.flp.fms.service.ActorServiceImpl;

public class DeleteActorServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		ActorServiceImpl actorservice = new ActorServiceImpl();
		List<Actor> actorList = actorservice.getActorList();
		
		
		PrintWriter out=response.getWriter();
		
		//Structure for the html page.
		out.println("<html>");
		out.println("<head><h1> Actor Details </h1>"
				+ "<link rel='stylesheet' type='text/css' href='css/MyStyles.css'></head>"
				+ "<body><center>"
				+ "<table border='2' align='center'>"
				+ "<tr>"				
				+ "<th>Actor Id</th>"
				+ "<th>Actor First Name</th>"
				+ "<th>Actor Last Name</th>"
				+ "<th>Delete Link</th>"
				+ "</tr>");
		
        // Retrive the data from list into the html page
		
		for(Actor actor:actorList)
		{
			out.println("<tr>");
			out.println("<td>"+actor.getActor_id()+"</td>");
			out.println("<td>"+actor.getActor_FirstName()+"</td>");
			out.println("<td>"+actor.getActor_LastName()+"</td>");
			out.println("<td><a href='DeleteActorListServlet?actor_Id="+actor.getActor_id()+"'>Delete</a></td>");

			
			out.println("</td>");
			out.println("</tr>");
		}

		out.println("</table></center></body>");		
		out.println("</html>");	

	}
	}

	

