package com.flp.fms.controller;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.flp.fms.domain.Actor;
import com.flp.fms.service.ActorServiceImpl;


public class AddActorServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		ActorServiceImpl actorservice=new ActorServiceImpl();
		List<Actor> actor=actorservice.getAllActors();

		PrintWriter out=response.getWriter();
		out.println("<html>");
		out.println("<head><center><h1>Add Film Details</h1><hr></center>"
				+ "<link rel='stylesheet' type='text/css' href='css/MyStyles.css'>"
				+ "</head>"
				+"<script type='text/javascript' src='script/Validation.js'></script>");	


		out.println("<body><center>"

				+"<form name='Film' method='post' action='SaveActorServlet'>"

					 			+"<div>"	
					 			+ "<table>"
					 			+"<tr>"
					 			+" <td>Actor First Name</td>"
					 			+"<td><input type='text' name='firstName' >"
					 			+"</td>" 
					 			+"</tr>"

								+ "<tr>"				
								+ "<td>Actor Last Name</td>"
								+ "<td><input type='text' name='lastName'>"
								+"</td>" 
								+"</tr>");

		out.println("<tr>"+
				"<td></td>"+
				"<td><input class='myBtn' type='submit' value='Save' ><input class='myBtn' type='reset' value='Clear'></td>"+	
				"</td>"+
				"</tr>"+

				"</table>");		

		out.println("</table></div></form></center></body>");

		out.println("</html>");


	}
}




