package com.flp.fms.controller;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.flp.fms.domain.Actor;
import com.flp.fms.domain.Category;
import com.flp.fms.domain.Language;
import com.flp.fms.service.ActorServiceImpl;
import com.flp.fms.service.FilmServiceImpl;
import com.flp.fms.service.IActorService;


public class UserInteractionServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		PrintWriter out=response.getWriter();
		
		FilmServiceImpl filmService=new FilmServiceImpl();
		IActorService actorService=new ActorServiceImpl();	
		
			
		List<Actor> actor=actorService.getActorList();
		
		List<Language> languages=filmService.getLanguages();
		
		List<Category> categorys=filmService.getCategory();
			


		out.println("<html>");
		out.println("<head>");
		
	//	out.println( "<script type='text/javascript' src='script/FormValidation.js'></script>");
		
		out.println("<link rel='stylesheet' href='//code.jquery.com/ui/1.11.4/themes/smoothness/jquery-ui.css'>");
		out.println("<script src='//code.jquery.com/jquery-1.10.2.js'></script>");
		out.println(" <script src='//code.jquery.com/ui/1.11.4/jquery-ui.js'></script>");
		
		
		out.println( "<script>");
		out.println(  "  $(function() {");
		out.println(  "    $( '#datepicker').datepicker({  maxDate: '0'});");
		out.println( "  });");
		out.println(  "  </script>");
		
		out.println( "<script>");
		out.println(  "  $(function() {");
		out.println(  "  $( '#datepicker1').datepicker({  maxDate: '0', dateFormat:'dd-M-yy'});");
		out.println( "  });");
		out.println(  "  </script>");
		
		out.println(  "<script type='text/javascript' src='script/Validation.js'> </script>");
		out.println(  "");
	
		
	
		out.println("<title>Film Details</title>");
		out.println("</head>");
		out.println("<body style='background-color:#ccccff'>");
		
		
		out.println("<form name='addfilm'  method='post' action='SaveFilmServlet' onsubmit='return validateForm()'>");
		
		out.println("<h2><center>Film Registration Form</center></h1>");
		out.print("<table>");


		out.println("<tr>"
			+"<td>FilmTitle:</td>"
			+"<td><input type='text' name='filmTitle' size='20'>"
			+"<div id='titleerr' class='errMsg'> </div>"
			+"</td>"
			+"</tr>");
			
			
		out.println("<tr>"
			+"<td>Film Description:</td>"
			+"<td>"
			+"<textarea rows='4' name='filmDescription' cols='25' ></textarea>"
			+"<div id='descerr' class='errMsg'> </div> "
			+"</td>"
			+"</tr>");
			
			
		out.println("<tr>"
			+"<td>Release Year:</td>"
			+"<td>"
			+"<input type='text' name='releaseYear' id='datepicker' size='25'>"
			+"<div id='relasedaterr' class='errMsg'> </div> "
			+"</td>"
			+"</tr>");
		
		
		
		out.println("<tr>"
			+"<td>Rental Duration:</td>"
			+"<td>"
			+"<input type='text' name='rentalDuration'  id='datepicker1' size='25'>"
			+"<div id='rentaldurationerr' class='errMsg'> </div> "
			+"</td>"
			+"</tr>");
			
	
		out.println("<tr>"
				+"<td>Original Language:</td>"
				+"<td><select name='originalLanguage'>");
				
				for(Language lang:languages){
					out.print("<option value='"+lang.getLanguage_id()+"'>"+lang.getLanguage_id()+" "+lang.getLanguage_name()+"</option>");
				}
		out.print("</select></td></tr>");
			
			
		
		out.println("<tr>"
			+"<td>Other Languages:</td>"
			+"<td><select name='otherLanguage' multiple=''>");
			
			for(Language lang:languages){
				out.print("<option value='"+lang.getLanguage_id()+"'>"+lang.getLanguage_id()+" "+lang.getLanguage_name()+"</option>");
			}
		out.print("</select></td></tr>");
		
		
		
		out.println("<tr>"
			+"<td>FilmLength:</td>"
			+"<td><input type='text' name='filmLength' size='20' >"
			+"<div id='lenghterr' class='errMsg'> </div>"
			+"</td>"
			+"</tr>"
			+"<tr>");
			
		out.println("<tr>"
			+"<td>Replacement Cost:</td>"
			+"<td><input type='text' name='replacementcost' size='20'>"
			+"<div id='replacementcosterr' class='errMsg'> </div> "
			+"</td>"
			+"</tr>");
			
			
		out.println("<tr>"
				+"<td>Film Rating:</td>"
				+"<td>"
				+"<select name='frating'>"
				+"<option value='Default'> Default</option>"
					+"<option value='1'>1</option>"
					+"<option value='2'>2</option>"
					+"<option value='3'>3</option>"
					+"<option value='4'>4</option>"
					+"<option value='5'>5</option>"
				+"</select>"
				+"</td>"
				+"</tr>");
			
			
			
		out.println("<tr>"
			+"<td>Special Features:</td>"
			+"<td>"	
				+"<textarea rows='4' name='specialfeature' cols='25'></textarea>"
			+"</td>"
			+"</tr>");
			
		
		out.print("<tr><td>Actor</td>"
					+ "<td><select name='actor'>");
			for(Actor actor1:actor){
				out.print("<option value='"+actor1.getActor_id()+"'> "+actor1.getActor_id()+"-"+actor1.getActor_FirstName()+" "+actor1.getActor_LastName()+"</option>");
			}
		out.print("</select></td></tr>");
			
			
			
	
		out.print("<tr><td>Category</td>"
				
					+ "<td><select name='category'>");
			for(Category category1:categorys){
				out.print("<option value='"+category1.getCategory_id()+"'>"+category1.getCategory_id()+"- "+category1.getCategory_name()+"</option>");
			}
		out.print("</select></td></tr>");
		
		
				
			
			
		out.println("<tr>"
				+"<td></td>"
				+"<td><input class='btn'  type='submit' value='Save'>"
				+"<input class='btn' type='reset' value='Clear'>"
				 +"</td>"
			+"</tr>");
			
       	out.println("</table>");
       	out.println("</form>");

       	out.println("</body>");
		out.println("</html>");

		
		
	}
		
		
		
	}

	

