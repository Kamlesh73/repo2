package com.flp.fms.controller;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.flp.fms.service.ActorServiceImpl;
//import com.flp.fms.service.FilmServiceImpl;


public class DeleteActorListServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		// Create Instance of service impl class for get and set data	
		ActorServiceImpl actorservice = new ActorServiceImpl();
		
		String actorid=request.getParameter("actor_Id");
		//FilmServiceImpl filmservice = new FilmServiceImpl();

		boolean flag=actorservice.deleteActor(Integer.parseInt(actorid));	
		
		if(flag)
		{
				
			PrintWriter out=response.getWriter();	
			out.println("<html><body>");
			out.println("<h1>Actor Record Deleted  Successfully</h1>");
			out.println("</body></html>");

		}
	}

}