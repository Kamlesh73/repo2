package com.flp.fms.controller;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.flp.fms.domain.Actor;
import com.flp.fms.domain.Category;
import com.flp.fms.domain.Film;
import com.flp.fms.domain.Language;
import com.flp.fms.service.FilmServiceImpl;
import com.flp.fms.service.IFilmService;


public class SaveFilmServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;


	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		
		IFilmService loginService=new FilmServiceImpl();
		PrintWriter out=response.getWriter();
		Film film=new Film();
		Category cat=new Category();
		Actor actor=new Actor();
		Language lang=new Language(); 
		
	
		film.setTitle(request.getParameter("filmTitle"));
		film.setDescription(request.getParameter("filmDescription"));
		film.setLength(Integer.parseInt(request.getParameter("filmLength")));
		
		lang.setLanguage_id(Integer.parseInt(request.getParameter("originalLanguage")));
		film.setOriginalLanguage(lang);
		
		ArrayList<Language> languages=new ArrayList<>();
		String[] str=request.getParameterValues("otherLanguage");
		for(String str1:str){
			Language lang1=new Language(); 
			lang1.setLanguage_id(Integer.parseInt(str1));
			languages.add(lang1);
		}
		film.setLanguages(languages);
		
		
		film.setRatings(Integer.parseInt(request.getParameter("frating")));
			
		film.setReleaseYear(new Date(request.getParameter("releaseYear")));
		
		film.setRentalDuration(new Date(request.getParameter("rentalDuration")));
		
		film.setReplacementCost(Double.parseDouble(request.getParameter("replacementcost")));
		
		/*cat.setCategory_Id(Integer.parseInt(request.getParameter("")));
		film.setCategory(cat);*/
		//film.setLanguages(request.getParameter(""));
		film.setSpecialFeature(request.getParameter("specialfeature"));
		
		//Set<Actor> actors=new HashSet<>();
		
		 List<Actor> actors=new ArrayList<>();
	
		String[] str3=request.getParameterValues("actor");
		for(String str1:str3){
			Actor actor1=new Actor(); 
			actor1.setActor_id(Integer.parseInt(str1));
			actors.add(actor1);
		}
		film.setActors(actors);
		
		
		Category cat1=new Category();
		cat1.setCategory_id(Integer.parseInt(request.getParameter("category")));
		film.setCategory(cat1);
		
		
		int count=loginService.addFilm(film);
		
		
		if(count==1){
			out.println("<head>");
			out.print("<link rel='stylesheet' type='text/css' href='css/mystyles.css'>");
			out.println("</head>");
			out.println("<body><br/><br/><br/><h2><center>Film added successfully!!!!!</center></h2></body>");
		
		}
	}



}
