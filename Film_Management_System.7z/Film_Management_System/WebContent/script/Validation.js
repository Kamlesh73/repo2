function validateForm()

{

 var flag=true;
	
	
	
	var title = addfilm.filmTitle.value;
	
	var length = addfilm.filmLength.value;
	
	var cost=addfilm.replacementcost.value;
	
	var rentalDate = addfilm.rentalDuration.value;
	
	var releaseyear=addfilm.releaseYear.value;
	
	var letters = /^[A-Za-z0-9_ ]*$/;
	

	 
		
	if((title=="" || title==null) || !title.match(letters) )
	
	{
		
		document.getElementById("titleerr").innerHTML="* Please enter a title";
		
		flag=false;
	}
	
	else
	 {
		document.getElementById("titleerr").innerHTML="";
	 }
	
   if((length == ""||length == null) || length > 1000)
   
   {
		
		document.getElementById("lenghterr").innerHTML="*Please enter a value below 1000";
		
		flag = false;
	}
   
	else
	 {
		document.getElementById("lenghterr").innerHTML="";
	    
	 }
   
   
   if((cost==""||cost==null) || cost < 1000)
   {
		
		document.getElementById("replacementcosterr").innerHTML="*Enter Valid Replacement Cost";
		
		flag = false;
	}
		
	else
		
		{
		document.getElementById("replacementcosterr").innerHTML="";
		
		}
  
   
   if((rentalDate==""||rentalDate==null) && (rentalDate<releaseyear) )
   {
		
		document.getElementById("rentaldurationerr").innerHTML="*RentalDate should be Greater than ReleaseDate";
		
		flag = false;
	}
		
	else
		{
		document.getElementById("rentaldurationerr").innerHTML="";
		}
   
   
   if((releaseyear==""||releaseyear==null))
   {
		
		document.getElementById("relasedaterr").innerHTML="*Invalid release date";
		
		flag = false;
	}
		
	else
		{
		document.getElementById("relasedaterr").innerHTML="";
		}
     
  
   	return flag;
 
}




 
   