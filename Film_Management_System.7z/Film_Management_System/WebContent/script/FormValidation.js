
//Film Title Validation
function validateTitle()  
{   
		var title=film.filmTitle.value;
		
		var letters = /^[A-Za-z]+$/;  
		
		if(title.match(letters))  
		{  
			document.getElementById("titleerr").innerHTML="";
			return true;  
		}  
		else  
		{  
			document.getElementById("titleerr").innerHTML="*Title should only contain alphabet"; 
			filmTitle.focus();  
			return false;  
		}  
}  

//Film Description Validation
   function validateDescription()  
   {   
		var description=film.filmDescription.value;
		
		var letters = /^[A-Za-z]+$/;   
		
		if(description.match(letters))  
		{  
			document.getElementById("descerr").innerHTML="";
			return true;  
		}  
		else  
		{  
			document.getElementById("descerr").innerHTML="*Description should contain alphabets only "; 
			filmDescription.focus();  
			return false;  
		}  
}  
   
   
 //Rental Duration Validation 
   function validateRentalDuration(){
		
		var ReleaseDate=film.releaseYear.value;
		var RentalDuration=film.rentalDuration.value;

	    if(RentalDuration>ReleaseDate){
	    	
	    	document.getElementById("rentaldurationerr").innerHTML="";
			return true;  
	    }
	    else
	    {
	    	document.getElementById("rentaldurationerr").innerHTML="*RentalDuration shhould be Greater than ReleaseDate"; 
	    	rentalDuration.focus();  
			return false; 
	    }
	    
		
	}

 //Length Validation
   function validateLength(){
		
		var length=film.filmLength.value;

	    if( length>=1 && length<=1000){
	    	
	    	document.getElementById("lenghterr").innerHTML="";
			
	    	return true;  
	    }
	    else
	    {
	    	document.getElementById("lenghterr").innerHTML="*Length should be between 1 to 1000"; 
	    	filmLength.focus();  
			return false; 
	    }	
	}
   
 //Rating Validation
   function validateRating(){
	   
	   var rating=film.frating.value;
	   
	   if(rating.value != "Default"){  
   	  
		   document.getElementById("ratingerr").innerHTML="";
		   return true; 
	   }  
	   else  
	   {  
		   document.getElementById("ratingerr").innerHTML="*Please Select any one Rating"; 
		   frating.focus();  
		   return false; 
   	
	   }  


   }  


  