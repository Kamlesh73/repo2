package com.flp.fms.dao;

import java.util.Set;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import com.flp.fms.domain.Actor;

public class ActorDaoImplForDB implements IActorDao{

	@Override
	public List<Actor> getActors() {
		
		List<Actor> actors = new ArrayList<>();
		
		ConnectionClass conClass = new ConnectionClass();
		Connection con = conClass.getConnection();
		
		String sql="select * from actors";
				
		PreparedStatement stmt;
		try {
			
			stmt = con.prepareStatement(sql);
			ResultSet rs = stmt.executeQuery();
			
			while(rs.next()){
				
				Actor actor = new Actor();
				
				actor.setActor_id(rs.getInt(1));
				actor.setActor_FirstName(rs.getString(2));
				actor.setActor_LastName(rs.getString(3));
				
				actors.add(actor);
			}
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		return actors;

	}
	
}
