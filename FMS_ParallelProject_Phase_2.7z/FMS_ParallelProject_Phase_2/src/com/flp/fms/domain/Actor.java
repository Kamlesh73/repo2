package com.flp.fms.domain;

	public class Actor {

	//private fields
	private int actor_id;
	private String actor_FirstName;
	private String actor_LastName;
	private int film_Id;
	
	//no args constructor
	public Actor(){
		
	}
	// parametrized contructor
	public Actor(int actor_id, String actor_FirstName, String actor_LastName,int film_Id){
		super();
		this.actor_id=actor_id;
		this.actor_FirstName=actor_FirstName;
		this.actor_LastName=actor_LastName;
		this.film_Id = film_Id;
		
	}
	
	// getters and setters
	public int getActor_id() {
		return actor_id;
	}
	public void setActor_id(int actor_id) {
		this.actor_id = actor_id;
	}

	public String getActor_FirstName() {
		return actor_FirstName;
	}
	public void setActor_FirstName(String actor_FirstName) {
		this.actor_FirstName = actor_FirstName;
	}
	
	public String getActor_LastName() {
		return actor_LastName;
	}
	public void setActor_LastName(String actor_LastName) {
		this.actor_LastName = actor_LastName;
	}
	
	public int getFilm_Id() {
		return film_Id;
	}
	public void setFilm_Id(int film_Id) {
		this.film_Id = film_Id;
	}
	
	
//hashcode method
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((actor_FirstName == null) ? 0 : actor_FirstName.hashCode());
		result = prime * result + ((actor_LastName == null) ? 0 : actor_LastName.hashCode());
		result = prime * result + actor_id;
		result = prime * result + film_Id;
		return result;
	}

	
//equals method
	@Override
	public boolean equals(Object obj) {
		if (this == obj) {
			return true;
		}
		if (obj == null) {
			return false;
		}
		if (!(obj instanceof Actor)) {
			return false;
		}
		Actor other = (Actor) obj;
		if (actor_FirstName == null) {
			if (other.actor_FirstName != null) {
				return false;
			}
		} else if (!actor_FirstName.equals(other.actor_FirstName)) {
			return false;
		}
		if (actor_LastName == null) {
			if (other.actor_LastName != null) {
				return false;
			}
		} else if (!actor_LastName.equals(other.actor_LastName)) {
			return false;
		}
		if (actor_id != other.actor_id) {
			return false;
		}
		if (film_Id != other.film_Id) {
			return false;
		}
		return true;
	}
	
	
//ToString mthd

	@Override
	public String toString() {
		return "Actor [actor_id=" + actor_id + ", actor_FirstName=" + actor_FirstName + ", actor_LastName="
				+ actor_LastName + ", film_Id=" + film_Id + "]";
	}

	
	
	
	
}
