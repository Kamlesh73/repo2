package com.flp.fms.domain;

public class Language {

// private fields
	private int language_id;
	private String language_name;
	private int film_id;
	
//no args constructor
	public Language(){
		
	}
	
// parameterized constructor
	public Language(int language_id, String language_name, int film_id) {
		super();
		this.language_id = language_id;
		this.language_name = language_name;
		this.film_id = film_id;
	}
	
	
// getters and setters
	
	public int getLanguage_id() {
		return language_id;
	}
	public void setLanguage_id(int language_id) {
		this.language_id = language_id;
	}

	
	public String getLanguage_name() {
		return language_name;
	}
	public void setLanguage_name(String language_name) {
		this.language_name = language_name;
	}

	
	public int getFilm_id() {
		return film_id;
	}
	public void setFilm_id(int film_id) {
		this.film_id = film_id;
	}
	
//hashcode method
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + film_id;
		result = prime * result + language_id;
		result = prime * result + ((language_name == null) ? 0 : language_name.hashCode());
		return result;
	}

//equals method
	@Override
	public boolean equals(Object obj) {
		if (this == obj) {
			return true;
		}
		if (obj == null) {
			return false;
		}
		if (!(obj instanceof Language)) {
			return false;
		}
		Language other = (Language) obj;
		if (film_id != other.film_id) {
			return false;
		}
		if (language_id != other.language_id) {
			return false;
		}
		if (language_name == null) {
			if (other.language_name != null) {
				return false;
			}
		} else if (!language_name.equals(other.language_name)) {
			return false;
		}
		return true;
	}

//toString mthd
	@Override
	public String toString() {
		return "Language [language_id=" + language_id + ", language_name=" + language_name + ", film_id=" + film_id
				+ "]";
	}
}
