package flp.capgemini.demo;

public interface Shape {
	
	public float PI=3.14f;
	public void draw();
	public void findArea();

}
