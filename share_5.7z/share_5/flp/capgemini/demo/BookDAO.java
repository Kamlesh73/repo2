package flp.capgemini.demo;

public interface BookDAO {
	void saveBook(Book book);
	void listAllBooks();
	void searchBook(int bookId);
	void deleteBook(int bookId);

}
