package flp.capgemini.demo;

import java.util.Scanner;

public class Book {
	int bookId;
	String bookName;
	String author;
	String publisher;
	long price;
	public Book getBookDetails()
	{
		Scanner sc=new Scanner(System.in);
		
		Book book=new Book();
		System.out.println("Enter book id");
		book.bookId=sc.nextInt();
		System.out.println("Enter book name");
		book.bookName=sc.next();
		System.out.println("Enter author");
		book.author=sc.next();
		System.out.println("Enter publisher");
		book.publisher=sc.next();
		System.out.println("Enter price");
		book.price=sc.nextLong();
		return book;
		
	}
	public void showBookDetails()
	{
		System.out.println(bookId+"\t"+bookName+"\t"+author+"\t"+publisher+"\t"+price);
	}

}
