package flp.capgemini.demo;

public class Circle implements Shape ,Color{

	@Override
	public void draw() {
		System.out.println("Draw Circle");
		
	}

	@Override
	public void findArea() {
		System.out.println("Area Circle");
		
	}

	@Override
	public void getColor() {
		System.out.println("getColor");
	}

	@Override
	public void fillCOlor() {
		System.out.println("fill Color");
		
	}
	public void myCircleInfo()
	{
		System.out.println("Information");
		
	}

}
