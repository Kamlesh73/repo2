package flp.capgemini.demo;

public class BookDAOImplementation implements BookDAO{

	Book [] bookRepository;
	int i=0;
	public BookDAOImplementation()
	{
		bookRepository=new Book[50];
	}
	@Override
	public void saveBook(Book book) {
		
		bookRepository[i]=book;
		i++;
		
		
	}

	@Override
	public void listAllBooks()
	{
		System.out.println("bookId\tbookName\tauthor\tpublisher\tprice");
		for(int j=0;j<i;j++)
		{
			bookRepository[j].showBookDetails();
		}
		
	}
	@Override
	public void searchBook(int bookId) {
		for(int j=0;j<i;j++)
		{
			if(bookRepository[j].bookId==bookId)
			{
				bookRepository[j].showBookDetails();
			}
		}
		
	}
	@Override
	public void deleteBook(int bookId) {
		int j;
		for(j=0;j<i;j++)
		{
			if(bookRepository[j].bookId==bookId)
			{
				break;
			}
		}
		for(int k=j;k<i;k++)
		{
			bookRepository[k]=bookRepository[k+1];
		}
		i--;
	}

}
