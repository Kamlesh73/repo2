import java.util.Scanner;
public class Addevenodd{
 public static void main(String[] args){
 int size,i,even=0,odd=0;
Scanner sc=new Scanner(System.in);
System.out.println("Enter the size:");
size=sc.nextInt();
int []myarr=new int [size];//Storing in array.
System.out.println("Enter array:");
for(i=0;i<size;i++)
myarr[i]=sc.nextInt();
for(i=0;i<myarr.length;i++)
{
if(myarr[i]%2==0)
{
even=even+myarr[i];
}
else
{
odd=odd+myarr[i];
}
}
System.out.println("Addition of even numbers:"+even);
System.out.println("Addition of odd numbers:"+odd);
}
 }