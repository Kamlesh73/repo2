public class DigitalFormat{
    public static void main(String[] args){
	int i,j,row=5,col=3;
	for(i=0;i<row;i++)
	{
	for(j=0;j<col;j++)
	{
	if(i%2==0||j==col-1)
	{
	System.out.print("*");
	}
	else
	{
	System.out.print(" ");
	}
	
	}
	System.out.println();
	}
	}
	}