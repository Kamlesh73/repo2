public class DemoFor{
public static void main(String[] args){
for(int i=1,j=100;i<10;i++,j--)
System.out.println(i+"---"+j);
}
}