import java.util.Scanner;
public class ArraySum{
 public static void main(String[] args){
 int size,i,sum=0;
Scanner sc=new Scanner(System.in);
System.out.println("Enter the size:");
size=sc.nextInt();
int []myarr=new int [size];//Storing in array.
System.out.println("Enter array:");
for(i=0;i<size;i++)
myarr[i]=sc.nextInt();
for(i=0;i<myarr.length;i++)//sum of array elements
sum=sum+myarr[i];
System.out.println(sum);
 }
 }