import java.util.Scanner;
 public class Fibo{
    public static void main(String[] args){
		int f=0,s=1,n,series=0;
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter the number:");
		n=sc.nextInt();
		System.out.println("Fibonassi Series is:\n"+f+"\n"+s);
			while(n-2!=0)
			{
			series=f+s;
			f=s;
			s=series;
			n--;
			System.out.println(series);
			}
	}
	}
	