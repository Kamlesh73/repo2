import java.util.Scanner;
public class Reverse{
public static void main(String [] args)
{
int size,i;
Scanner sc=new Scanner(System.in);
System.out.println("Enter the size:");
size=sc.nextInt();
int []myarr=new int [size];//Storing in array.
System.out.println("Enter array:");
for(i=0;i<size-1;i++)
myarr[i]=sc.nextInt();
for(i=myarr.length-1;i>=0;i--)//Reverse array
System.out.println(myarr[i]);
}
}