public class Armstrong{
    public static void main(String[] args){
	int i,n,j,sum;
	for(i=1000;i>=1;i--)
	{
		j=i;
			sum=0;
			while(j!=0)
			{
			n=j%10;
			sum=sum+(n*n*n);
			j=j/10;
			}
			if(i==sum)
			{
			System.out.println(i);
			}
	}
	System.out.println("This are the Armstrong number between 1 to 1000");
	}
	}