import java.util.Scanner;
public class Sort{
public static void main(String [] args)
{
int size,i,j;
int t[]={0};
Scanner sc=new Scanner(System.in);
System.out.println("Enter the size:");
size=sc.nextInt();
int []myarr=new int [size];//Storing in array.
System.out.println("Enter array:");
for(i=0;i<size;i++)
myarr[i]=sc.nextInt();
for(i=0;i<=myarr.length-2;i++)
{
for(j=i+1;j<myarr.length;j++)
{
if(myarr[i]>myarr[j])
{
t[0]=myarr[i];
myarr[i]=myarr[j];
myarr[j]=t[0];
}
}
}
for(i=0;i<myarr.length;i++)
System.out.println(myarr[i]);
}
}