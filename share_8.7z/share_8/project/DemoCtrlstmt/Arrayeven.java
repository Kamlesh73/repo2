import java.util.Scanner;
public class Arrayeven{
 public static void main(String[] args){
 int size,i;
Scanner sc=new Scanner(System.in);
System.out.println("Enter the size:");
size=sc.nextInt();
int []myarr=new int [size];//Storing in array.
System.out.println("Enter array:");
for(i=0;i<size;i++)
myarr[i]=sc.nextInt();
for(i=0;i<myarr.length;i++)
if(myarr[i]%2==0)
{
System.out.println(myarr[i]);
}
else
{
System.out.println("No even number");
}
}
 }