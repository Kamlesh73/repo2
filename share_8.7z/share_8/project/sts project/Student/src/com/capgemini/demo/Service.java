package com.capgemini.demo;

public class Service {
public static void main(String[] args)
{
	StudentService ss=new StudentService();
	ss.getStudents();
	ss.sort();
	ss.printStudents();
}
}
