package com.capgemini.demo;

import java.util.Scanner;

public class StudentDetails {
	private int studentid;
	private String firstname,lastname;
	private double fees;
	
	public void getStudentDetails()
	{
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter Student Id:");
		studentid=sc.nextInt();
		System.out.println("Enter Student FirstName:");
		firstname=sc.next();
		System.out.println("Enter Student lastname:");
		lastname=sc.next();
		System.out.println("Enter Fees:");
		fees=sc.nextDouble();
	}
	public void getPrintDetails()
	{
		System.out.println("\nId:"+studentid+"\tName:"+firstname+" "+lastname+"\tFees:"+fees);
	}
	public double getFees()
	{
		return fees;
	}

}
