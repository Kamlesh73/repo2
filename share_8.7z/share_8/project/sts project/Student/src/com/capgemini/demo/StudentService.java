package com.capgemini.demo;

import java.util.Scanner;

public class StudentService {
	int size;
StudentDetails[] students;
StudentDetails stud;
	public void initializeArray(int size)
	{
		students=new StudentDetails[size];
		stud =new StudentDetails();
	}
	public void getStudents()
	{
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter how many students data you want to enter:");
		size=sc.nextInt();
		initializeArray(size);
		for(int i=0;i<size;i++)
		{
			students[i]=new StudentDetails();
			students[i].getStudentDetails();
		}
		
	}
	public void sort()
{
		for(int i=0;i<students.length;i++){
			for(int j=i+1;j<students.length;j++){
				if(students[i].getFees()>students[j].getFees())
				{
					stud=students[i];
					students[i]=students[j];
					students[j]=stud;
		
	}
			}
			}
}
	public void printStudents()
	{
		for(int i=0;i<students.length;i++)
		{
			students[i].getPrintDetails();
		}
	}

}
