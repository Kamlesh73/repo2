package org.capgemini.series;

public class TestClass {
	public static void main(String[] args)
	{
		CalculateSeries cs=new CalculateSeries();
		cs.solveSeries();
		cs.printOutput();
	}

}
