package org.capgemini.series;

import java.util.Scanner;

public class CalculateSeries {
	public int num,i;
	public double sum=0.0;
	
	public void getInput()
	{
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter the number:");
		num=sc.nextInt();
	}
public long findFactorial(int num)
{
	int fact=1;
	for(i=1;i<=num;i++)
	{
		fact=fact*i;
	}
	return fact;
}
public long powerCalculate(int base,int power)
{
	int p=1;
	for(i=1;i<=base;i++)
	{
		p=p*power;
	}
	return p;
}
public double solveSeries()
{
	getInput();
	if(num>=1)
	{
	for(i=1;i<=num;i++)
	{
		sum=sum+((double)(powerCalculate(i,i)/findFactorial(i)));
	}
	return sum;
	}
	else
		return sum;
	
}
public void printOutput()
{
	System.out.println("Series calcution is:"+sum);
}
}

