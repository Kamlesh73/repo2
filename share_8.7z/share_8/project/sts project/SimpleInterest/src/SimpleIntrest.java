import java.util.Scanner;

public class SimpleIntrest {
float p,n,r,si=0;
Scanner sc=new Scanner(System.in);
public void getInput()
{
	System.out.println("Enter the p,n,r:");
	p=sc.nextFloat();
	n=sc.nextFloat();
	r=sc.nextFloat();
}
public void findInterest()
{
	si=(p*n*r)/100;
	System.out.println("Simple Ineterst is:"+si);
}
}
