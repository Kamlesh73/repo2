
public class Testclass {
public static void main(String[] args)
{
	SimpleIntrest sim=new SimpleIntrest();
	sim.getInput();
	sim.findInterest();
}
}
