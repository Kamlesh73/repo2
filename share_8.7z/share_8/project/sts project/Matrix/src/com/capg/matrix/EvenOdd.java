package com.capg.matrix;

import java.util.Scanner;

public class EvenOdd {
	int i=1,j=1,value=0,num;
	Scanner sc=new Scanner(System.in);
	public void print()
	{
		System.out.println("Enetr the value:");
		value=sc.nextInt();
	while(value!=0)
	{
		odd();
	}
	}
		public void odd()
		{
			num=3;
			while(value!=0)
			{
			while(num!=3)
			{
				i=j;
				if(i%2!=0)
				{
					System.out.println(i);
				}
				i++;
				num--;
				value--;
			}
			even();
			}
		}
		public void even()
		{
			num=3;
			while(value!=0)
			{
			while(num!=3)
			{
				while(value!=0)
				i=j;
				if(i%2==0)
				{
					System.out.println(i);
				}
				i++;
				num--;
				value--;
			}
			odd();
		}
		}
	
	public static void main(String [] args)
	{
		EvenOdd e=new EvenOdd();
	e.print();
	}
		

}

