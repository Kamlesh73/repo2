package com.capg.matrix;
import java.util.Scanner;
public class MatrixMultiplication {


	public static void main(String[] args)
	{
	int i,j;
	int a[][]=new int[3][3];
	int b[][]=new int[3][3];
	int c[][]=new int[3][3];
	Scanner sc=new Scanner(System.in);
   System.out.println("Enter the first matrix:");
   for(i=0;i<3;i++)
   {
	   for(j=0;j<3;j++)
	   {
		   a[i][j]=sc.nextInt();
	   }
   }
   System.out.println("Enter the Second matrix:");
   for(i=0;i<3;i++)
   {
	   for(j=0;j<3;j++)
	   {
		   b[i][j]=sc.nextInt();
	   }
   }
   System.out.println("Multiplication of matrix is:");
   for(i=0;i<3;i++)
   {
	   for(j=0;j<3;j++)
	   {
		   c[i][j]=a[i][j]*b[i][j];
	   }
	   for(i=0;i<3;i++)
	   {
		   for(j=0;j<3;j++)
		   {
			   System.out.println(c[i][j]);
		   }
}
}
}
}

