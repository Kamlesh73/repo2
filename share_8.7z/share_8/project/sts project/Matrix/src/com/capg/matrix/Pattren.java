package com.capg.matrix;

import java.util.Scanner;

public class Pattren {
	public static void main(String[] args)
	{
	int i,j;
	int a[][]=new int[3][3];
	Scanner sc=new Scanner(System.in);
   System.out.println("Enter the first matrix:");
   for(i=0;i<3;i++)
   {
	   for(j=0;j<3;j++)
	   {
		   a[i][j]=sc.nextInt();
	   }
   }
   for(i=0;i<3;i++)
   {
	   for(j=0;j>=i;j++)
	   {
		   System.out.println(a[i][j]);
	   }
	   System.out.println("\n");
   }
   for(i=0;i<3;i++)
   {
	   for(j=2;j>=1;j--)
	   {
		   System.out.println(a[i][j]);
	   }
	   System.out.println("\n");
   }

}
}
