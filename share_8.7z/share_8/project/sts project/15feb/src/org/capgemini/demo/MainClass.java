package org.capgemini.demo;

public class MainClass {
	public static void main(String[] args)
	{
		Employee emp=new Employee();
		//System.out.println(emp.getEmpid());
		//System.out.println(emp.lastname);
		//System.out.println(emp.salary);
emp.getEmployee();
emp.printEmployee();
}
}
