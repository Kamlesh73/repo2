package org.capgemini.demo;

import java.util.Scanner;

public class Employee {
private int empid;
protected String lastname,firstname;
double salary;
public void getEmployee()
{
	Scanner sc=new Scanner(System.in);
	System.out.println("Enter the Empid:");
	empid=sc.nextInt();
	System.out.println("Enter the Firstname:");
	firstname=sc.next();
	System.out.println("Enter the Lastname:");
	lastname=sc.next();
	System.out.println("Enter the Salary:");
	salary=sc.nextInt();
}
public void printEmployee()
{
	System.out.println("\nEmployee Id"+empid+"\nFirstname:"+firstname+"\nLastname:"+lastname+"Salary:"+salary);
}
public int getEmpid(){
return empid;
}
}
