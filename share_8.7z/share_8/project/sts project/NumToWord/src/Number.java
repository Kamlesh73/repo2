import java.util.Scanner;

public class Number {
	public static void main(String[] args)
	{
	
Scanner sc=new Scanner(System.in);
System.out.println("Enter Four didgit no.:");
int num=sc.nextInt();
int d4=num%10;
num=num/10;
int d3=num%10;
num=num/10;
int d2=num%10;
num=num/10;
int d1=num%10;
num=num/10;
switch(d1)
{
case 1:System.out.print("one thousand ");
		break;
case 2:System.out.print("two thousand ");
break;
case 3:System.out.print("three thousand ");
break;
case 4:System.out.print("four thousand ");
break;
case 5:System.out.print("five thousand ");
break;
case 6:System.out.print("six thousand ");
break;
case 7:System.out.print("seven thousand ");
break;
case 8:System.out.print("eight thousand ");
break;
case 9:System.out.print("nine thousand ");
break;
default:System.out.print(" ");
}
switch(d2)
{
case 1:System.out.print("hundred ");
		break;
case 2:System.out.print("two hundred ");
break;
case 3:System.out.print("three hundred ");
break;
case 4:System.out.print("four hundred ");
break;
case 5:System.out.print("five hundred ");
break;
case 6:System.out.print("six hundred ");
break;
case 7:System.out.print("seven hundred ");
break;
case 8:System.out.print("eight hundred ");
break;
case 9:System.out.print("nine hundred ");
break;
default:System.out.print(" ");
}
switch(d3)
{
case 1:System.out.print("ten ");
		break;
case 2:System.out.print("twenty ");
break;
case 3:System.out.print("thirty ");
break;
case 4:System.out.print("fourty ");
break;
case 5:System.out.print("fifty ");
break;
case 6:System.out.print("sixty ");
break;
case 7:System.out.print("seventy ");
break;
case 8:System.out.print("eighty ");
break;
case 9:System.out.print("ninty ");
break;
default:System.out.print(" ");
}
switch(d4)
{
case 1:System.out.print("one");
		break;
case 2:System.out.print("two");
break;
case 3:System.out.print("three");
break;
case 4:System.out.print("four");
break;
case 5:System.out.print("five");
break;
case 6:System.out.print("six");
break;
case 7:System.out.print("seven");
break;
case 8:System.out.print("eight");
break;
case 9:System.out.print("nine");
break;
default:System.out.print(" ");
}
}
}
