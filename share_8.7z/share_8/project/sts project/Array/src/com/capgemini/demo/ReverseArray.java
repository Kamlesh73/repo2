package com.capgemini.demo;

import java.util.Scanner;

public class ReverseArray {
	
//	int[] myArray;
	
	public int[] initializeArray(int size,int[] myArray){
		myArray=new int[size];
		return myArray;
	}

	
	
	public int[] getArrayElements(int[] myArray){
		Scanner sc=new Scanner(System.in);
		System.out.println("What is a size?");
		int size=sc.nextInt();
		
		myArray=initializeArray(size,myArray);
		
		System.out.println("Enter Array Elements:");
		
		for(int i=0;i<myArray.length;i++){
			myArray[i]=sc.nextInt();
		}
		return myArray;
	}
	
	public void printArrayElements(int[]  myArray){
		for(int i=myArray.length-1;i<=0;i--)
			System.out.print(myArray[i] + "   ");
		System.out.println();
	}
}
	