package com.capgemini.demo;

import java.util.Scanner;

public class SortArray {
	
//	int[] myArray;
	
	public int[] initializeArray(int size,int[] myArray){
		myArray=new int[size];
		return myArray;
	}

	
	
	public int[] getArrayElements(int[] myArray){
		Scanner sc=new Scanner(System.in);
		System.out.println("What is a size?");
		int size=sc.nextInt();
		
		myArray=initializeArray(size,myArray);
		
		System.out.println("Enter Array Elements:");
		
		for(int i=0;i<myArray.length;i++){
			myArray[i]=sc.nextInt();
		}
		return myArray;
	}
	
	public void printArrayElements(int[]  myArray){
		for(int i=0;i<myArray.length;i++)
			System.out.print(myArray[i] + "   ");
		System.out.println();
	}
	
	
	public int[] sortArray(int[] myArray){
		for(int i=0;i<myArray.length;i++){
			for(int j=i+1;j<myArray.length;j++){
				if(myArray[i]>myArray[j]){
					int temp=myArray[i];
					myArray[i]=myArray[j];
					myArray[j]=temp;
				}
			}
		}
		return myArray;
	}
	
}