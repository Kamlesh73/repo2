package com.capgemini.demo;

import java.util.Scanner;

public class Address {
public int doorno,pincode;
public String street,city,state;
public Address()
{
	this.doorno=0;
	this.street=null;
}
public Address(int doorno,String street,String city,int pincode,String state)
{
	this.doorno=doorno;
	this.street=street;
	this.city=city;
	this.pincode=pincode;
	this.state=state;
}
public void getAddress()
{
	Scanner sc=new Scanner(System.in);
	System.out.println("Enter Doorno.");
	doorno=sc.nextInt();
	System.out.println("Enter Street Name:");
	street=sc.next();
	System.out.println("Enter city");
	city=sc.next();
	System.out.println("Enter state");
	state=sc.next();
	System.out.println("Enter pincode");
	pincode=sc.nextInt();
}
public void printAddress()
{
	System.out.println("Address is:"+doorno+","+street+" "+city+" "+pincode+" "+state);
}
}
