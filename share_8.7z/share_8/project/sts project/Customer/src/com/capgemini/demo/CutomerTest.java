package com.capgemini.demo;

public class CutomerTest {

	public static void main(String[] args) {
		CustomerDetails cd=new CustomerDetails();
		cd.getCustomer();
		cd.printCustomer();

	}

}
