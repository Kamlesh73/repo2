package com.capgemini.demo;

import java.util.Scanner;

public class CustomerDetails {
public int cusid;
public String name;
Address ad;
public double fees;
public CustomerDetails()
{
}
public CustomerDetails(int cusid, String name,Address ad,double fees)
{
	this.cusid=cusid;
	this.name=name;
	this.ad=ad;
	this.fees=fees;
}
public void getCustomer()
{
	Scanner sc=new Scanner(System.in);
	System.out.println("Enter the customer id:");
	cusid=sc.nextInt();
	System.out.println("Enter the Name:");
	name=sc.next();
	System.out.println("Enter the Address:");
	ad=new Address();
	ad.getAddress();
	System.out.println("Enter the fees:");
	fees=sc.nextDouble();
	
}
public void printCustomer()
{
	System.out.println("Customer Details are:Id"+cusid+"\n"+name+"\nFees:"+fees);
	ad.printAddress();
}
}
