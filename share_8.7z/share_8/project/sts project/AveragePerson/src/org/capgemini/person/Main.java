package org.capgemini.person;

public class Main {

	public static void main(String[] args) 
	{
		Person p=new Person();
		p.getpersonDetails();
		p.calculateAverage();
		p.printPersonDetails();

	}

}
