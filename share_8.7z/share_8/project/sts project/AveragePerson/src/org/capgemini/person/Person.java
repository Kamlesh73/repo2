package org.capgemini.person;

import java.util.Scanner;

public class Person 
{
	
	public int personid,c,cpp,java;
	public double total,average;
	public String name,address;

	public void getpersonDetails()
	{
			Scanner sc=new Scanner(System.in);
			System.out.println("Enter the Name:");
			name=sc.nextLine();
			System.out.println("Enter the Address:");
			address=sc.nextLine();
			System.out.println("Enter the Personid:");
			personid=sc.nextInt();
			System.out.println("Enter the Marks of Subjects:\n For c:");
			c=sc.nextInt();
			System.out.println("\n For CPP:");
			cpp=sc.nextInt();
			System.out.println("\nFor Java:");
			java=sc.nextInt();
	}
	public void calculateAverage()
	{
			total=c+cpp+java;
			average=total/3;
	}
	public void printPersonDetails()
	{
			System.out.println("\nPerson Id"+personid+"\nName:"+name+"\nAddress:"+address+"\nC Marks:"+c+"\nCPP Marks:"+cpp+"\nJava Marks:"+java+"\nTotal Marks:"+total+"\nAverage:"+average);
	}
}
