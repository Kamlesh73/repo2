class Biggest{
public static void main(String[] args){
int i=1,j=2,k=3;
if(i>j&&i>k)
{
System.out.println("I is greater");
}
else if(j>i&&j>k)
{
System.out.println("j is greater");
}
else if(k>i&&k>j)
{
System.out.println("k is greater");
} 
else
{
System.out.println("All are same");
}
}
}