import java.util.Scanner;
public class Bonus{
    public static void main(String[] args){
String name;
int salary;
Scanner sc=new Scanner(System.in);
System.out.println("Enter the name:");
name=sc.nextLine();
System.out.println("Enter the salary:");
salary=sc.nextInt();
if(salary>200000)
{
System.out.println("Bonus is:"+((salary*15)/100));
}
else if(salary<200000&&salary>100000)
{
System.out.println("Bonus is:"+((salary*20)/100));
}
else if(salary<100000&&salary>500000)
{
System.out.println("Bonus is:"+((salary*25)/100));
}
else if(salary<500000)
{
System.out.println("Bonus is:"+((salary*30)/100));
}
}
}