import java.util.Scanner;
public class Circle{
    public static void main(String[] args){
float r;
float pi=3.14f;
Scanner sc=new Scanner(System.in);
System.out.println("Enter Radius:");
r=sc.nextFloat();
System.out.println("Area :"+(pi*r*r));
}
}
