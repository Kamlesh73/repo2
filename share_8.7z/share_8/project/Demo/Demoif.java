class Demoif{
public static void main(String[] args){
int i=13;
if(i<11)
{
System.out.println("Less than 10");
}
else
{
System.out.println("Greater than 10");
}
}
}