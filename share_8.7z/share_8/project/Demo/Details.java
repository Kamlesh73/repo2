import java.util.Scanner;
public class Details{
    public static void main(String[] args){
String firstname,lastname,address;
int java,servlet,html;
Scanner sc=new Scanner(System.in);
System.out.println("Enter Address:");
address=sc.nextLine();

System.out.println("Enter First name:");
firstname=sc.next();
System.out.println("Enter last name:");
lastname=sc.next();

System.out.println("Enter Marks of subjects:");
System.out.println("Enter for  java:");
java=sc.nextInt();
System.out.println("Enter for  Servlet:");
servlet=sc.nextInt();
System.out.println("Enter for  HTML:");
html=sc.nextInt();
System.out.println("Student Details:NAME"+firstname+" "+lastname);
System.out.println("Address is:"+address);
System.out.println("Marks of Subjects are:Java:" +java+"Servlet:"+servlet+"HTML:"+html);
System.out.println("Total:"+(java+servlet+html));
System.out.println("Average:"+((java+servlet+html)/3));
}
}
