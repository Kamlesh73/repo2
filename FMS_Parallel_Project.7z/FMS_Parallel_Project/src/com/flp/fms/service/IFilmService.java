package com.flp.fms.service;

import java.util.Date;
import java.util.List;
import java.util.Map;

import com.flp.fms.domain.Actor;
import com.flp.fms.domain.Category;
import com.flp.fms.domain.Film;
import com.flp.fms.domain.Language;

public interface IFilmService
{
	public List<Language> getLanguages();
	public List<Category> getCategory();
	
	public void addFilm(Film film);
	public Map<Integer, Film> getAllFilms();
	
//methods for search operation
	public Film searchFilm(int filmId);
	public Film searchFilm(String title);
	public List<Film> searchFilmByRating(int rating);
	public List<Film> searchFilm(Actor actor);
	public List<Film> searchFilm(Language language);
	public Film searchFilm(String title, Date releaseDate, int rating);
		
		
		
//methods for delete operation
	public void removeFilm(int filmId);
	public void removeFilm(String title);
	public void removeFilm(Actor actor);
	public void removeFilmByRating(int rating);

//methods for update operation
	public void updateFilm(Film film);

	}


