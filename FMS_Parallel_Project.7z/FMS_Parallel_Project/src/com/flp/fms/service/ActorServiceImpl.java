package com.flp.fms.service;

import java.util.Set;

import com.flp.fms.dao.ActorDaoImplForSet;

import com.flp.fms.dao.IActorDao;

import com.flp.fms.domain.Actor;


public class ActorServiceImpl implements IActorService {

	private IActorDao actorDao=new ActorDaoImplForSet();
	
	@Override
	public Set<Actor> getActors() {


		return actorDao.getActors();
	}

}