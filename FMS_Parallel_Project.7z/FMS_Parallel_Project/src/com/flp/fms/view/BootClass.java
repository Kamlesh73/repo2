package com.flp.fms.view;

import java.util.Collection;
import java.util.List;
import java.util.Map;
import java.util.Scanner;

import com.flp.fms.domain.Film;
import com.flp.fms.domain.Language;
import com.flp.fms.service.ActorServiceImpl;
import com.flp.fms.service.FilmServiceImpl;
import com.flp.fms.service.IActorService;
import com.flp.fms.service.IFilmService;

public class BootClass {

	public static void main(String[] args) {
		
		Scanner sc=new Scanner(System.in);
		int option;
		
		UserInteraction userInteraction=new UserInteraction();
		IFilmService filmService=new FilmServiceImpl();
		IActorService actorService=new ActorServiceImpl();
		
		String choice;
		do{
		menuSelection();
		System.out.println("Enter your option:[1-6]");
		option=sc.nextInt();
		switch(option){
			case 1://Add film
				Film film=userInteraction.addFilm(filmService.getLanguages(),filmService.getCategory(),actorService.getActors());
				filmService.addFilm(film);
				
				break;
			case 2://Modify Film
				int filmId = userInteraction.readFilmId();
				film = filmService.searchFilm(filmId);
				if(film==null)
					System.out.println("Entered Film does not Exsist");
					
				else{
					
					userInteraction.printFilm(film);
					film = userInteraction.addFilm(filmService.getLanguages(), filmService.getCategory(),
							actorService.getActors());
					film.setFilm_id(filmId);
					filmService.updateFilm(film);       
					}
				break;
			case 3://Remove film
				System.out.println("\t1.remove by id\n\t2.remove by title\n\t3.remove by rating\n"
						+ "\t4.remove film by actor\n");
				System.out.println("enter your option");
				int opt=sc.nextInt();
				switch (opt) {
				
					case 1://remove film by filmId
						filmService.removeFilm(userInteraction.readFilmId());
						break;
						
					case 2://remove film by title
						filmService.removeFilm(userInteraction.readTitle());
						break;
						
					case 3://remove film by rating
						filmService.removeFilmByRating(userInteraction.readRating());
						break;
						
					case 4://remove film by actor
						filmService.removeFilm(userInteraction.selectActor(actorService.getActors()));
						break;

						default:
						filmService.removeFilmByRating(userInteraction.readRating());
						break;
					}
				
				break;
			
			case 4://Search film
				System.out.println("\t1.search by Id\n\t2.search by Title\n\t3.search by Rating\n"
						+ "\t4.search by Actor\n\t5.search by Language");
				System.out.println("Enter your option");
				int op=sc.nextInt();
				
				switch(op){
				
					case 1://search by filmId
						film = filmService.searchFilm(userInteraction.readFilmId());
						userInteraction.printFilm(film);
						break;
						
					case 2://search by Title
						film = filmService.searchFilm(userInteraction.readTitle());
						userInteraction.printFilm(film);
						break;
						
					case 3://search by Rating
						List<Film> films = filmService.searchFilmByRating(userInteraction.readRating());
						userInteraction.getAllFilm(films);;
						break;
						
					case 4://search by Actor
						List<Film> selectedFilms = filmService.searchFilm(userInteraction.selectActor(actorService.getActors()));
						userInteraction.getAllFilm(selectedFilms);
						break;
						
					case 5://search by Language
						List<Language> allLanguages = filmService.getLanguages();
						List<Film> selectedFilms2 = filmService.searchFilm(userInteraction.selectLanguage(allLanguages));
						userInteraction.getAllFilm(selectedFilms2);
						break;
						
					default:
						System.out.println("Wrong Option Entered");
				}
				break;
			
			case 5://Get all film records
				userInteraction.getAllFilm(filmService.getAllFilms().values());
				break;

				default:
				System.out.println("Wrong Option Entered");
			
		}
		
		System.out.println("\nDO YOU WANT TO PROCEED TO MAIN MENU? [y/n]");
			choice = sc.next();
			
		} while (choice.charAt(0)=='y'||choice.charAt(0)=='Y');
		System.out.println("You are successfully Exited");
	}
	
		
//static method to display menu selection
	public static void menuSelection(){
		
		System.out.println("**MENU SELECTION:-->");
		System.out.println("1.Add Film");
		System.out.println("2.Modify Film");
		System.out.println("3.Remove Film");
		System.out.println("4.Search Film");
		System.out.println("5.Get All Film");
		
	}

}//end of class
	
	