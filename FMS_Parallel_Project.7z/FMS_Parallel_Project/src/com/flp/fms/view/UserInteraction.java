package com.flp.fms.view;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Date;
import java.util.HashSet;
import java.util.List;
import java.util.Scanner;
import java.util.Set;

import com.flp.fms.domain.Actor;
import com.flp.fms.domain.Category;
import com.flp.fms.domain.Language;
import com.flp.fms.domain.Film;
import com.flp.fms.util.*;


public class UserInteraction {
		
		Scanner sc=new Scanner(System.in);

	//Function to prompt the user to enter the Film_Id
		public int readFilmId(){
			System.out.println("Enter Film Id:");
			return sc.nextInt();
		}
				
	//Function to prompt the user to enter the Title
		public String readTitle(){
			System.out.println("Enter Film Title:");
			String title = sc.nextLine();
			return title;
		}
	
	//Function to prompt the user to enter the Actor's FirstName
		public String readFirstName(){
			System.out.println("Enter First Name of Actor");
			return sc.next();
		}
				
	//Function to prompt the user to enter the Actor's LastName
		public String readLastName(){
			System.out.println("Enter Last name of Actor:");
			return sc.next();
		}
				
	//Function to prompt the user to enter the Film Rating
		public int readRating(){
			System.out.println("Enter Film Rating");
			return sc.nextInt();
		}


	//Return fully qualified film object
	public Film addFilm(List<Language> languages,List<Category> categories,Set<Actor> actors){
		
		Film film = new Film();
		boolean flag=true;
		
	//Get Title and validate it
		String title=null;
		do{
		System.out.println("Enter Film Title");
		
		title=sc.nextLine();
		
		flag=Validate.isValidTitle(title);
			
		if(!flag)
			System.out.println("Invalid Title. Please Enter Valid Title!");
		}while(!flag);
		
		film.setTitle(title);
		
	//To get Film Description
		String description=null;
		System.out.println("Enter description");
		description=sc.nextLine();
		film.setDescription(description);
		
	//To get Special Feature
		String SpecialFeature=null;
		System.out.println("Enter SpecialFeature");
		SpecialFeature=sc.nextLine();
		film.setSpecialFeature(SpecialFeature);
	
	//To get Release Date and Validate it.
		String releaseDate;
		boolean date_flag=false;
		Date release_Date=null;
		do{
			
			do{
				System.out.println("Enter Release Date:");
				releaseDate=sc.next();
				flag=Validate.isValidDate(releaseDate);
				if(!flag)
					System.out.println("Please enter date in this Format(dd-MMM-yyyy)!");
			}while(!flag);
			
			Date today=new Date();
			release_Date=new Date(releaseDate);
			if(release_Date.before(today)|| release_Date.equals(today))
				date_flag=true;
		
			if(!date_flag)
				System.out.println("Invalid Date! Date should be current date or Past Date!");
		}while(!date_flag);
		film.setReleaseYear(release_Date);
	
	
	//To get Rental duration and Validate it.
		String rentalDate=null;
		boolean date_flag1=false;
		Date rental_Date=null;
		do{
			do{
			System.out.println("Enter RentalDuration:");
			rentalDate=sc.next();
			flag=Validate.isValidDate(rentalDate);
			if(!flag)
				System.out.println("Please enter date in this Format(dd-MMM-yyyy)!");
			}while(!flag);
		
			rental_Date=new Date(rentalDate);
				if(rental_Date.after(release_Date));
			date_flag1=true;
			if(!date_flag1)
			System.out.println("Invalid Date! Date should be current date or After current Date!");
		}while(!date_flag1);
		film.setRentalDuration(rental_Date);
		
	//To get Film Length and Validate it.
		int length=0;

		do{
			System.out.println("Enter Length between[1-1000]");
			length=sc.nextInt();
			flag=Validate.isValidLength(length);
			if(!flag)
			System.out.println("Invalid Length. Please Enter Valid Length!");
		}while(!flag);
		film.setLength(length);
	
	// To Get Replacement Cost
		double replacementcost=0;
		do{
			System.out.println("Enter replacement cost (greater than 1000)");
			replacementcost=sc.nextDouble();
			flag=Validate.isValidReplacementCost(replacementcost);
			if(!flag)
				System.out.println("Invalid replacementcost. Please Enter Valid replacementcost!");
		}while(!flag);
		film.setReplacementCost(replacementcost);

	//To get and Validate Rating
		int rating=0;
		do{
			System.out.println("Enter rating");
			rating=sc.nextInt();
			flag=Validate.isValidRating(rating);
				if(!flag)
					System.out.println("Invalid rating. Please Enter Valid rating [1-5]!");
			}while(!flag);
			film.setRatings(rating);
		
		
	//To Choose Language
			System.out.println("Choose Original Language");
			Language language= selectLanguage(languages);
			
			film.setOriginalLanguage(language);
			
			System.out.println("Choose Category ");
			Category category= selectCategory(categories);
			film.setCategory(category);
			
	//Add all languages
			List<Language> languages2=new ArrayList<>();
			String choice;
			boolean flag_langs;
			do{
				System.out.println("Choose All Languages for the Film:");
				Language language1= selectLanguage(languages);
				
				
				flag_langs=Validate.checkDuplicateLanguage(languages2, language1);
				if(!flag_langs)
					languages2.add(language1);
				else
					System.out.println("Language already Exists. Please try other languages!");
				
				
				System.out.println("Wish to add More Languages?[y|n]");
				choice=sc.next();
			}while(choice.charAt(0)=='y'||choice.charAt(0)=='Y');
			film.setLanguage(languages2);
			
	//Add All actors	
			HashSet<Actor> allActors=new HashSet<>();
			//allActors = new HashSet<>();
			
			String choice1;
			do{	
				System.out.println("Choose Actor:");
		       
				Actor actor1=selectActor(actors) ;
		        allActors.add(actor1);
		        
				System.out.println("Wish to add More Actors?[y|n]");
				choice=sc.next();
			
			}while(choice.charAt(0)=='y'||choice.charAt(0)=='Y');
			
	  		film.setActors(allActors);
			
			return film;
		}
			
	//Choose valid language object from the list:
		public Language selectLanguage(List<Language>  languages){
		
			Language sel_language=null;
			boolean flag;
			do{	
		//Print Langauge Details
			for(Language language:languages)
				System.out.println(language.getLanguage_id() + "\t" + language.getLanguage_name());
			
			System.out.println("Choose the Language:");
			int option=sc.nextInt();
			
			flag=false;
		//Check the Language Object
			for(Language language: languages)
			{
				if(option==language.getLanguage_id())
				{
					sel_language=language;
					flag=true;
					break;
				}
			}
	   //Print Error Message
			if(!flag)
				System.out.println("Please select valid Language Id");
		}while(!flag);	
		
		return sel_language;

	}
		
	//Choose valid category  object from the list:
	public Category selectCategory(List<Category>  categories){
	
			Category sel_category=null;
			boolean flag;
			do{	
		//Print Category Details
				for(Category category:categories)
					System.out.println(category.getCategory_id() + "\t" + category.getCategory_name());
		
				System.out.println("Choose the category:");
				int option=sc.nextInt();
		
				flag=false;
		
		//Check the Category Object
				for(Category category:categories)
				{
					if(option==category.getCategory_id())
					{
						sel_category= category;
						flag=true;
						break;
					}
				}
		//Print Error Message
				if(!flag)
					System.out.println("Please select valid category Id");
			}while(!flag);	
	
			return sel_category;
	}
	
//Choose Valid Actor Object from the list of Actors
	public Actor selectActor(Set<Actor> actors) {
		//public Actor selectActor(List<Actor> actors){
		
		Actor selectedActor=null;
		
		boolean flag;
		do{	
			//Print Actor Details
			System.out.println("\tACTORS");
			for(Actor actor1 : actors)
				System.out.println(actor1.getActor_id()+""+actor1.getActor_FirstName()+""+actor1.getActor_LastName());
			
			System.out.println("Choose the Actor:");
			int option=sc.nextInt();
			
			flag=false;
			
			//Checking whether the entered Actor Id is valid
			for(Actor actor1: actors)
			{
				if(option==actor1.getActor_id())
				{
					selectedActor=actor1;
					flag=true;
					break;
				}
			}
			
			//Print Error Message for invalid Actor Id
			if(!flag)
				System.out.println("Please select valid Actor Id");
		
		}while(!flag);	
		
		return selectedActor;
	}
		
// To get all film
		public void getAllFilm(Collection<Film> films) {
			
			//getting all the films in the Film repository
				if(films.isEmpty())
				System.out.println("No Film Exists!");
			
				else{
				
				System.out.println("FILM ID"+ "\t" + " TITLE" + "\t" + "DESCRIPTION" +"\t"
					+ "RELEASE_YEAR" + "\t" + "ORIGINAL_LANGUAGE" + "\t" + "OTHER_LANGUAGES" + "\t"
					+ "RENTAL_DURATION"	+ "\t" + "LENGTH" + "\t" + "REPLACEMENT_COST" + "\t"
					+ "RATING" + "\t" + "SPECIAL_FEATURES" + "\t" + "ACTORS" + "\t" + "CATEGORY");
						
					for(Film film: films){
							
					printFilm(film);
				}
			}
		}
		
		//Function to Print the Film
		public void printFilm(Film film){
			
			if (film!=null) {
				
				String otherLanguages = "";
				String allActors = "";
				
			//getting the name of all languages in which film is released
				for (Language language : film.getLanguage()) {

					otherLanguages = otherLanguages + language.getLanguage_name() + ", ";
				}
			//getting the name of all the actors in the film
				for (Actor actor : film.getActors()) {

					allActors = allActors + actor.getActor_FirstName() + " " + actor.getActor_LastName() + ", ";
				}
				System.out.println("\n" + film.getFilm_id() + "\t" + film.getTitle() + "\t" + film.getDescription() + "\t"
						+ film.getReleaseYear() + "\t" + film.getOriginalLanguage().getLanguage_name() + "\t"
						+ otherLanguages + "\t" + film.getRentalDuration() + "\t" + film.getLength() + "\t"
						+ film.getReplacementCost() + "\t" + film.getRatings() + "\t" + film.getSpecialFeature() + "\t"
						+ allActors + "\t" + film.getCategory().getCategory_name());
			}
			
			else
				System.out.println("Film does not exist!");
		
		
		}

		
		
}//end of the class
		
