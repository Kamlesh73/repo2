package com.flp.fms.domain;


public class Category {
	
//private fields
	private int Category_id;
	private String Category_name;
	private int Film_id;

//No Argument Constructor
	public Category(){}

// Argumented Constructor
	public Category(int category_id, String category_name, int film_id) {
		super();
		this.Category_id = category_id;
		this.Category_name = category_name;
		this.Film_id = film_id;
	}
	
//getters and setters
	public int getCategory_id() {
		return Category_id;
	}
	public void setCategory_id(int category_id) {
		Category_id = category_id;
	}
	public String getCategory_name() {
		return Category_name;
	}
	public void setCategory_name(String category_name) {
		Category_name = category_name;
	}
	public int getFilm_id() {
		return Film_id;
	}
	public void setFilm_id(int film_id) {
		Film_id = film_id;
	}
	
//ToString method
	@Override
	public String toString() {
		return "Category [Category_id=" + Category_id + ", Category_name=" + Category_name + ", Film_id=" + Film_id
				+ "]";
	}
	
}

