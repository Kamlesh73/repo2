package com.flp.fms.dao;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Date;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;

import com.flp.fms.domain.Actor;
import com.flp.fms.domain.Category;
import com.flp.fms.domain.Film;
import com.flp.fms.domain.Language;

public class FilmDaoImplForList implements IFilmDao{

	private Map<Integer, Film> film_Repository=new HashMap<>();

	//method for adding list all languages
	@Override
	public List<Language> getLanguages() {
		List<Language> languages=new ArrayList<>();
		languages.add(new Language(1, "English",0));
		languages.add(new Language(2, "Hindi",0));
		languages.add(new Language(3, "Marathi",0));
		languages.add(new Language(4, "Telagu",0));
		languages.add(new Language(5, "Kannada",0));
		languages.add(new Language(6, "Tamil",0));
		languages.add(new Language(7, "Malayalam",0));


		return languages;
	}

	//method for adding list all Categories
	@Override
	public List<Category> getCategory() {
		List<Category> categories=new ArrayList<>();
		categories.add(new Category(1, "Drama",0));
		categories.add(new Category(2, "Comedy",0));
		categories.add(new Category(3, "Horror",0));
		categories.add(new Category(4, "Scientific",0));
		categories.add(new Category(5, "Romantic",0));
		categories.add(new Category(6, "Action",0));



		return categories;
	}

	//CURD Operations

	//adding all films
	@Override
	public void addFilm(Film film) {
		film_Repository.put(film.getFilm_id(), film);

	}

	//getting all films
	@Override
	public Map<Integer, Film> getAllFilms() {

		return film_Repository;
	}

	//Searching Film by Film_Id
	@Override
	public Film searchFilm(int filmId) {

		return film_Repository.get(filmId);
	}

	//Searching Film by Title
	@Override
	public Film searchFilm(String title) {

		Film result = null;

		Collection<Film> films = film_Repository.values();
		Iterator<Film> itr = films.iterator();

		while(itr.hasNext()){

			Film film = itr.next();
			if(film.getTitle().equals(title)){

				result = film;
				break;
			}
		}

		return result;
	}

	//Searching Film by Rating
	@Override
	public List<Film> searchFilmByRating(int rating) {

		List<Film> selectedFilms = new ArrayList<>();

		Collection<Film> films = film_Repository.values();
		Iterator<Film> itr = films.iterator();

		while(itr.hasNext()){

			Film film = itr.next();

			if(film.getRatings()==rating){

				selectedFilms.add(film);
			}
		}
		return selectedFilms;
	}

	//Searching Film by Actor
	@Override
	public List<Film> searchFilm(Actor actor) {

		List<Film> selectedFilms = new ArrayList<>();

		Collection<Film> films = film_Repository.values();
		Iterator<Film> itr = films.iterator();

		while(itr.hasNext()){

			Film film = itr.next();
			Set<Actor> actors = new HashSet<>();
			actors = film.getActors();

			for(Actor act : actors){

				if(act.getActor_id()==actor.getActor_id()){

					selectedFilms.add(film);
				}

			}
		}
		return selectedFilms;
	}

	//Searching Film by Language
	@Override
	public List<Film> searchFilm(Language language) {

		List<Film> selectedFilms = new ArrayList<>();

		Collection<Film> films = film_Repository.values();
		Iterator<Film> itr = films.iterator();

		while(itr.hasNext()){

			Film film = itr.next();

			//if original language is same as entered language
			if(film.getOriginalLanguage().getLanguage_id() == language.getLanguage_id()){

				selectedFilms.add(film);
			}

			//if film is released in entered language
			else{

				List<Language> languages = new ArrayList<>();
				languages = film.getLanguage();

				for(Language lang : languages){

					if(lang.getLanguage_id()==language.getLanguage_id()){

						selectedFilms.add(film);
					}
				}
			}

		}

		return selectedFilms;
	}

	//Search Film by Release Date
	@Override
	public Film searchFilm(String title, Date releaseDate, int rating) {
		Film result=null;

		Collection<Film> films = film_Repository.values();
		Iterator<Film> itr = films.iterator();

		while(itr.hasNext()){

			Film film = itr.next();

			if(film.getTitle().equals(title) && film.getReleaseYear().equals(releaseDate) && film.getRatings()==rating){

				result =film;
				break;
			}
		}
		return result;
	}

	//remove Film by Film_Id 
	@Override
	public void removeFilm(int filmId) {
		film_Repository.remove(filmId);

	}

	//remove Film by Title
	@Override
	public void removeFilm(String title) {
		Collection<Film> allFilms = film_Repository.values();
		Iterator<Film> itr = allFilms.iterator();

		int filmId=0;

		while(itr.hasNext()){

			Film film = itr.next();

			if(film.getTitle().equals(title)){

				filmId = film.getFilm_id();
				break;
			}
		}

		film_Repository.remove(filmId);	
	}

	//remove Film by Rating
	@Override
	public void removeFilmByRating(int rating) {
		Collection<Film> allFilms = film_Repository.values();
		Iterator<Film> itr = allFilms.iterator();

		Set<Integer> selectedFilmIds = new HashSet<>();

		while(itr.hasNext()){

			Film film = itr.next();

			if(film.getRatings() == rating){

				selectedFilmIds.add(film.getFilm_id());	
			}
		}

		for(Integer filmId : selectedFilmIds){

			film_Repository.remove(filmId);
		}
	}

	//remove Film by Actor
	@Override
	public void removeFilm(Actor actor) {
		Collection<Film> films = film_Repository.values();
		Iterator<Film> itr = films.iterator();

		Set<Integer> selectedFilmIds = new HashSet<>();

		while(itr.hasNext()){

			Film film = itr.next();

			//getting the name of all actors in the film
			Set<Actor> actors = new HashSet<>();
			actors = film.getActors();

			for(Actor act : actors){

				if(act.getActor_id() == actor.getActor_id()){

					selectedFilmIds.add(film.getFilm_id());
				}

			}
		}

		for(Integer filmId : selectedFilmIds){

			film_Repository.remove(filmId);
		}

	}

	//Update Film
	@Override
	public void updateFilm(Film film) {
		addFilm(film);

	}


}

