package com.flp.fms.dao;

import java.util.Set;
import java.util.HashSet;
import java.util.List;
import com.flp.fms.domain.Actor;

public class ActorDaoImplForSet implements IActorDao{

//method adding actors in set
	public Set<Actor> getActors() {
		
		Set<Actor> actors=new HashSet<>();
		
		actors.add(new Actor(1, "Varun", "Dhawan",0));
		actors.add(new Actor(2, "Sid", "Malhotra",0));
		actors.add(new Actor(3, "Tom","Cruise",0));
		actors.add(new Actor(4, "Akshay","Kumar",0));
		actors.add(new Actor(5, "Brad","Pitt",0));
		actors.add(new Actor(6, "Amir","Khan",0));
		actors.add(new Actor(7, "Salman","Khan",0));
		actors.add(new Actor(8, "John","Abrahm",0));
		
		
		return actors;
	}
	
//Adding actors in List
	/*public List<Actor> getActors(){
		
		
		//List of Actors
		List<Actor> actors=new ArrayList<>();
		
		actors.add(new Actor(1, "Varun", "Dhawan",0));
		actors.add(new Actor(2, "Sid", "Malhotra",0));
		actors.add(new Actor(3, "Tom","Cruise",0));
		actors.add(new Actor(4, "Akshay","Kumar",0));
		actors.add(new Actor(5, "Brad","Pitt",0));
		actors.add(new Actor(6, "Amir","Khan",0));
		actors.add(new Actor(7, "Salman","Khan",0));
		actors.add(new Actor(8, "John","Abrahm",0));
		
		return actors;
	}*/
	
}
