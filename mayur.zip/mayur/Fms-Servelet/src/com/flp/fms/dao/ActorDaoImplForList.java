package com.flp.fms.dao;


import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import com.flp.fms.domain.Actor;

public class ActorDaoImplForList implements IActorDao {

	/*@Override
	public Set<Actor> getActor() {
	Set<Actor> actors=new HashSet<>();
	
	actors.add(new Actor(101,"Tom","Jerry"));
	actors.add(new Actor(102,"Shahrukh","Khan"));
	actors.add(new Actor(103,"salman","Jerry"));
	actors.add(new Actor(104,"amir","Jerry"));
	actors.add(new Actor(105,"kamal","Jerry"));
	actors.add(new Actor(106,"hasan","Jerry"));
	
		return actors;*/
	
	
	
	
	@Override
	public List<Actor> addActor() {
		
		// TODO Auto-generated method stub
		return null;
	}

		
	
public Connection getConnection(){
		
		Connection connection=null;
		
		try {
			Class.forName("com.mysql.jdbc.Driver");
			connection=DriverManager.getConnection("jdbc:mysql://localhost:3306/filmmanagement1","root","Pass1234");
			
			
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	
		return connection;
	}

	@Override
	public List<Actor> getActorList()
	{
		List<Actor> actor=new ArrayList<>();
		FilmDaoImplForList film=new FilmDaoImplForList();
		
		Connection con=film.getConnection();
		
		
		
		String sql="select * from ACTOR1";
		try {
			PreparedStatement pst=con.prepareStatement(sql);
			ResultSet rs=pst.executeQuery();
			
		
			while(rs.next())
			{
				Actor act1=new Actor();
				act1.setActor_Id(rs.getInt(1));
				act1.setFirstName(rs.getString(2));
				act1.setLastNAME(rs.getString(3));
				actor.add(act1);
				
			}
			
			
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return actor();
	}

	private List<Actor> actor() {
		// TODO Auto-generated method stub
		return null;
	}




}





