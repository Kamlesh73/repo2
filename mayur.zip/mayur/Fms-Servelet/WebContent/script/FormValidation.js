/**
 * 
 */


function istitlevalidate()  
{   
		var filmtitle=filmf.filmtitle.value;
		
		var letters = /^[A-Za-z]+$/;  
		if(filmtitle.match(letters))  
		{  
			document.getElementById("titleerr").innerHTML="";
			return true;  
		}  
		else  
		{  
			document.getElementById("titleerr").innerHTML="*Title should only contain alphabet"; 
			filmtitle.focus();  
			return false;  
		}  
}  

   function isdescriptionvalidate()  
   {   
		var filmdescription=filmf.filmdescription.value;
		
		var letters = /^[A-Za-z]+$/;  
		if(filmdescription.match(letters))  
		{  
			document.getElementById("descerr").innerHTML="";
			return true;  
		}  
		else  
		{  
			document.getElementById("descerr").innerHTML="*Title should only contain alphabet"; 
			filmdescription.focus();  
			return false;  
		}  
}  


   function islengthvalid(){
		
		var filmlength=filmf.filmlength.value;

	    //if(isNaN(filmlength)||filmlength>1 || filmlength<1000){
	    	
	    	 if(isNaN(filmlength)&& filmlength>=1 && filmlength<=1000){
	    	
	    	
	    	document.getElementById("lenghterr").innerHTML="";
			return true;  
	    }
	    else
	    {
	    	document.getElementById("lenghterr").innerHTML="*Length should be between 1 to 1000"; 
	    	filmlength.focus();  
			return false; 
	    }	
	}
   
   
   function isrentaldurationvalid(){
		
		var ReleaseDate=filmf.releasedate.value;
		var RentalDuration=filmf.rentalduration.value;


	    	
	    	 if(RentalDuration>ReleaseDate){
	    	
	    	
	    	document.getElementById("rentaldurationerr").innerHTML="";
			return true;  
	    }
	    else
	    {
	    	document.getElementById("rentaldurationerr").innerHTML="*RentalDate shhould be Greater than ReleaseDate"; 
	    	rentalduration.focus();  
			return false; 
	    }
	    
		
	}

   
   