package com.flp.fms.controller;

import java.io.IOException;
import java.io.PrintWriter;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.List;
import java.util.Set;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.flp.fms.domain.Actor;
import com.flp.fms.domain.Category;
import com.flp.fms.domain.Film;
import com.flp.fms.domain.Language;
import com.flp.fms.service.ActorServiceImpl;
import com.flp.fms.service.FilmServiceImpl;
import com.flp.fms.service.IFilmService;

/**
 * Servlet implementation class EditServelet1
 */
public class EditServelet1 extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public EditServelet1() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		
		
		
			PrintWriter out=response.getWriter();
		
			//creating an instance for filmserviceImp
			
			FilmServiceImpl filmser=new FilmServiceImpl();
			
			//creating an instance for an actor service impl
			ActorServiceImpl actorService=new ActorServiceImpl();
			
			
			//creating an instance for an sipmle date format
			DateFormat df=new SimpleDateFormat("dd-MM-yyyy");
			
			//getting an all actor which is stored in an db
			List<Actor> actor=actorService.getActorList();
			
			//getting list of an language which is stored in db
			List<Language> languages=filmser.getLanguages();
			
			//getting an list of an category which is stored in db
			List<Category> category=filmser.getCategory();
			
			
			//
			int id=Integer.parseInt(request.getParameter("id"));
			
			
			Film film=filmser.getSearchFilmByID(id);

			List<Language>langFilm=film.getLanguages();
			
			
			System.out.println("edit");
			System.out.println(film);
			
			out.print("<head>");
		
			
			//importing an css file
			out.print("<script type='text/javascript' src='scripts/validate.js'></script>"
					+"<link rel='stylesheet' href='//code.jquery.com/ui/1.11.4/themes/smoothness/jquery-ui.css'>"
					+ "<script src='//code.jquery.com/jquery-1.10.2.js'></script>"
					+"<script src='//code.jquery.com/ui/1.11.4/jquery-ui.js'></script>"
					+ " <link rel='stylesheet' type='text/css' href='css/mystyles.css'>"
					+ "<script type='text/javascript' src='scripts/jquery-1.8.3.js'></script>"
					+ "<script type='text/javascript' src='scripts/jquery-ui-1.9.2.custom.js'></script>"
					+ "<script type='text/javascript' src='scripts/jquery-ui-1.9.2.custom.min.js'></script>"
					+ "<script type='text/javascript' src='scripts/dateSelector.js'></script>");
	
			
			// creating an update form and validating it..
			out.print("</head>");
			out.print("<html>");
			out.print("<body>");
			out.print("<form name='film' method='post' action='EditServelet2'>");
			out.print("<h1 align='center'>Fill The Details of Film</h1>");
			out.println("<center><h1 style='color:red;'>Form Details</h1></center>");
			out.print("<table style='color: #FF0000;font-size:26px'>");
			
	
			out.println("<center> "
					+ "<table border=2px; style='color:red;'>"
					+ "<tr>"
					+ "<td><label>Film Title</label></td>"
					+ "<td>:</td>"
					+ "<td><input type='text' name='title' onmouseout='return validateDetails()' value='"+film.getTitle()+"'>"
					+ "<div id='titleErr'></div>"
					+ "</td>"
					+ "</tr>");
			out.print("<tr>"
					+ "<td><label>Description</label></td>"
					+ "<td>:</td>"
					+ "<td><textarea rows='4' name='desc' cols='25'>"+film.getDescription()+"</textarea></td><"
					+ "/tr>");
			
			out.print("<tr>"
					+ "<td>Release Year</td>"
					+ "<td>:</td><td>"
					+ "	<input type='text' name='release'  id='relYear' value='"+df.format(film.getRealeaseYear())+"' />"
					+ "</td>"
					+ "</tr>");
		
			out.print("<tr><td>Original Language</td><td>:</td>"
					+ "<td><select name='orgLang'>");
			
			
			
			//getParameter() returns http request parameters. Those passed from the client to the server.  Can only return String 
			
				for(Language lang:languages){
				if(lang.getLanguage_Name().equals(film.getOriginalLanguage().getLanguage_Name())){
					out.print("<option value='"+lang.getLanguage_Id()+"' selected>"+lang.getLanguage_Id()+" "+lang.getLanguage_Name()+"</option>");
					
				}
				else
				out.print("<option value='"+lang.getLanguage_Id()+"'>"+lang.getLanguage_Id()+" "+lang.getLanguage_Name()+"</option>");
				}
			
			
			
			
			out.print("<tr>"
					+ "<td>Rental Duration</td>"
					+ "<td>:</td><td>"
					+ "	<input type='text' name='rentD'  id='rentalDur' value='"+df.format(film.getRentalDuration())+"' />"
					+ "</td>"
					+ "</tr>");
			
			out.print("<tr>"
					+ "<td>Length Of Film</td>"
					+ "<td>:</td>"
					+ "<td><input type='text' name='length' size='20' value='"+film.getLength()+"'></td>"
					+ "</tr>");
			
			out.print("<tr>"
					+ "<td>Replacement Cost</td>"
					+ "<td>:</td>"
					+ "<td><input type='text' name='cost' size='20' value='"+film.getReplacementCost()+"'></td>"
					+ "</tr>");
			
			out.print("<tr>"
					+ "<td>Ratings</td>"
					+ "<td>:</td>"
					+ "<td><select name='rating' onchange='return isratingSelected()'>");
				for(int i=0;i<=5;i++){
					if(i==film.getRatings()){
						out.print("<option value='"+i+"' selected>"+i+"</option>");
						}
					else
						out.print("<option value='"+i+"' >"+i+"</option>");
				}
					
					out.print( "</select></td>"
					+ "</tr>");
			
		out.print("</select></td></tr>");
			out.print("<tr>"
					+ "<td><label>Special Features:</td>"
					+ "<td>:</td>"
					+ "<td><textarea rows='4' name='spec' cols='25'>"+film.getSpecialFeatures()+"</textarea></td>"
					+ "</tr>");
		
		
			
			
		//FOR CATEGORY
		out.print("<tr><td>Category</td><td>:</td>"
				+ "<td><select name='category'>"
				+ "<option value=''>Select category</option>");
		
		//getParameter() returns http request parameters. Those passed from the client to the server.  Can only return String 
		
		for(Category category1:category){
			if(category1.getCategory_Name().equals(film.getCategory().getCategory_Name())){ //if the category in the dropdown box is alrweady selected
			out.print("<option value='"+category1.getCategory_id()+"' selected>"+category1.getCategory_id()+" "+category1.getCategory_Name()+"</option>");// than cretereive the selected category 
			}
			else
				out.print("<option value='"+category1.getCategory_id()+"'>"+category1.getCategory_id()+" "+category1.getCategory_Name()+"</option>");
		}
	   out.print("</select></td></tr>");

	   //FOR ACTORS
		out.print("<tr><td>Actor</td><td>:</td>"
				+ "<td><select name='actor' multiple=''>"
				+ "<option value''>Select actors</option>");
		boolean flag=false;
		int id1=0;
		
		
			for(Actor actor1:actor)
			{
			for(Actor actt:actor){
				
			if(actor1.getFirstName().equals(actt.getFirstName()) && actor1.getLastNAME().equals(actt.getLastNAME())){
				flag=true;
				 id1=actor1.getActor_Id();
			}
				//out.print("<option value='"+actor1.getActor_Id()+"' selected>"+actor1.getActor_Id()+" "+actor1.getActor_Fname()+" "+actor1.getActor_Lname()+"</option>");
		}
			
			if(flag==true && id1==actor1.getActor_Id())
				out.print("<option value='"+actor1.getActor_Id()+"' selected>"+actor1.getActor_Id()+" "+actor1.getFirstName()+" "+actor1.getLastNAME()+"</option>");
			else
				out.print("<option value='"+actor1.getActor_Id()+"' >"+actor1.getActor_Id()+" "+actor1.getFirstName()+" "+actor1.getLastNAME()+"</option>");
			
		}
		out.print("</select></td></tr>");
		
		
		
			out.print("<tr><td>Other Language</td><td>:</td>"
					+ "<td><select name='othrlang' multiple='' class='ui fluid dropdown'>"
					+ "<option value=''>Select languages</option>");
			boolean flag1=false;
			int id2=0;
			for(Language lang:languages){
				
				for(Language lng:langFilm){
					
					if(lang.getLanguage_Name().equals(lng.getLanguage_Name())){
						flag1=true;
						 id2=lang.getLanguage_Id();
					}
						//out.print("<option value='"+actor1.getActor_Id()+"' selected>"+actor1.getActor_Id()+" "+actor1.getActor_Fname()+" "+actor1.getActor_Lname()+"</option>");
				}
					if(flag1==true && id2==lang.getLanguage_Id())
						out.print("<option value='"+lang.getLanguage_Id()+"' selected>"+lang.getLanguage_Id()+" "+lang.getLanguage_Name()+"</option>");
					else
						out.print("<option value='"+lang.getLanguage_Id()+"'>"+lang.getLanguage_Id()+" "+lang.getLanguage_Name()+"</option>");
					
				
			}
		out.print("</select></td></tr>"
				+ "<tr><td><input type='hidden' name='film_id' value='"+id+"'");
		
		out.print("<tr><td></td>"
				+ "<td><input type='submit' value='Submit'</td>"
				+ "</tr>");
				
			
			
			out.print("</html");
		}

	}