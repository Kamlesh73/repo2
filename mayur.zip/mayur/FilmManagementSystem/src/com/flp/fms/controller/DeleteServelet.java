package com.flp.fms.controller;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.flp.fms.domain.Actor;
import com.flp.fms.domain.Film;
import com.flp.fms.domain.Language;
import com.flp.fms.service.FilmServiceImpl;

/**
 * Servlet implementation class DeleteServelet
 */
public class DeleteServelet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public DeleteServelet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
	
		PrintWriter out=response.getWriter();
		
		// creating an instance for filmservice implementation
		FilmServiceImpl filmservice=new FilmServiceImpl();
		// Retreving the film from the db
		List<Film> film=filmservice.getAllFilms();
		
		
	

		out.println("<head>");
		out.print("<link rel='stylesheet' type='text/css' href='css/mystyles.css'>");
		out.println("</head>");
		
		//craetion of an html form
		
		out.println("<body>"
	
				+ "<h2 align='center'>List Of Films</h2>"
				+"<center>"
				+ "<table border=2px style='color:red;'>"
			
				+ "<tr>"
				+ "<th>Film Id</th>"
				+ "<th>Title</th>"
				+ "<th>Description</th>"
				+ "<th>Release Year</th>"
				+ "<th>Original Language</th>"
				+ "<th>Languages</th>"
				+ "<th>Rental Duration</th>"
				+ "<th>Length</th>"
				+ "<th>Replacement Cost</th>"
				+ "<th>Ratings</th>"
				+ "<th>Special Features</th>"
				+ "<th>Actors</th>"
				+ "<th>Category</th>"
				+ "<th>Delete</th>"
				+ "</tr>");
		
		
		
		//craeting an film instance and getting the daTa to languages
			for(Film film1:film){
			List<Language> languages=film1.getLanguages();
			
			String langs="";
			for(Language lang:languages)
			{
				langs=langs+lang.getLanguage_Name()+","; /// language may contain the multiple value so binding it and stored in string
			}
			
			List<Actor> actors=film1.getActors();// same as languages
			String actors1="";
			for(Actor actor:actors)
			{
				actors1=actors1+actor.getFirstName()+" "+actor.getLastNAME()+",";
			}
			out.println("<tr>");
			out.println("<td>"+film1.getFilm_Id()+"</td>");
			out.println("<td>"+film1.getTitle()+"</td>");
			out.println("<td>"+film1.getDescription()+"</td>");
			out.println("<td>"+film1.getRealeaseYear()+"</td>");
			out.println("<td>"+film1.getOriginalLanguage().getLanguage_Name()+"</td>");
			out.println("<td>"+langs+"</td>");
			out.println("<td>"+film1.getRentalDuration()+"</td>");
			out.println("<td>"+film1.getLength()+"</td>");
			out.println("<td>"+film1.getReplacementCost()+"</td>");
			out.println("<td>"+film1.getRatings()+"</td>");
			out.println("<td>"+film1.getSpecialFeatures()+"</td>");
			out.println("<td>"+actors1+"</td>");
			out.println("<td>"+film1.getCategory().getCategory_Name()+"</td>");
			out.print("<td><a href='DeleteServelet1?id="+film1.getFilm_Id()+"'><h5 style='color:#E45E9D;''>delete</h5></a></td>");
			out.println("</tr>");
		}
			out.println("</table></body>");
	}

		
	}
