package com.flp.fms.controller;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class AddActorServlet
 */
public class AddActorServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public AddActorServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
	

		PrintWriter out=response.getWriter();
		
		out.print("<html>");
		out.print("<head>");
		out.print("<script type='text/javascript' src='scripts/validate.js'></script>"
				+ " <link rel='stylesheet' type='text/css' href='../css/mystyle1.css'>");
		out.print("</head>");
		
		out.print("<body>");
		out.print("<form name='actor' method='post' action='AddActor'>");
		out.println("<center><h1 style='color:red;'>The Details of Actors</h1></center>");
		
		
		out.println("<center> "
				+ "<table style='color:red;'>"
				
				+ "<tr>"
				+ "<td><label>First Name</label></td>"
				+ "<td>:</td>"
				+ "<td><input type='text' name='aFName' onmouseout='return validateDetails()'>"
				+ "<div id='fNameErr'></div>"
				+ "</td>"
				+ "</tr>");
		out.println("<tr>"
				+ "<td><label>Last Name</label></td>"
				+ "<td>:</td>"
				+ "<td><input type='text' name='aLName' onmouseout='return validateDetails()'>"
				+ "<div id='lNameErr'></div>"
				+ "</td>"
				+ "</tr>");
		
		out.print("<tr><td></td>"
				+ "<td><input type='submit' value='Submit'</td>"
				+ "</tr>");
				
		out.print("</table>"
				+ "</center>"
				+ "</body>"
				+ "</html");
	}

	
}
