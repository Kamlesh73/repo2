package com.flp.fms.controller;

import java.io.IOException;

import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.flp.fms.domain.Actor;
import com.flp.fms.domain.Category;
import com.flp.fms.domain.Film;
import com.flp.fms.domain.Language;
import com.flp.fms.service.FilmServiceImpl;

/**
 * Servlet implementation class AddFilm1
 */
public class AddFilm1 extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public AddFilm1() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
			PrintWriter out=response.getWriter();
		// creating the instance of an film service and film
		  FilmServiceImpl filmService=new FilmServiceImpl();
		  Film film=new Film();
		  
		  //  retrieve the input values from HTML page. reterving all the values..
		  
		  film.setTitle(request.getParameter("filmtitle"));
		  film.setDescription(request.getParameter("filmdescription"));
		  film.setRealeaseYear(new Date(request.getParameter("releasedate")));
		  film.setSpecialFeatures(request.getParameter("specialfeature"));
		  film.setLength(Integer.parseInt(request.getParameter("filmlength")));
		  film.setReplacementCost(Double.parseDouble(request.getParameter("replacementcost")));
		  film.setRatings(Integer.parseInt(request.getParameter("rating")));
		  film.setRentalDuration(new Date(request.getParameter("rentalduration")));/// showing depercation because sts 1.7 onwards it supports 
		
		  
		  //creating an object for an language here reteriving data from html page and it is converted into Integar value using parseInt
		  // and it set language_Id in the language table ...setting the value of original language via instance lang in the film.
		  
		  	Language lang=new Language();
		  	lang.setLanguage_Id(Integer.parseInt(request.getParameter("orgLang")));
		  	film.setOriginalLanguage(lang);
		  
		  //same as above as language
		  
		  Category category=new Category();
		  category.setCategory_id(Integer.parseInt(request.getParameter("category")));
		  film.setCategory(category);
		  
		//getting actors  values from an html page ..and multiple actors value
		
		  
		  String [] actors=request.getParameterValues("actor");
		  List<Actor> actor1=new ArrayList<>();
		  
		
		  for(String str:actors){                     //Creating an instance for the string "str" stored all retreved value within it
			  Actor act=new Actor();                  //importing actor from an pojo class and craeting the instance of it   
			  act.setActor_Id(Integer.parseInt(str)); // reteriving the value from string instance converting this into parseInt from that value setting the actorID
			  actor1.add(act);                        // ACTOR ID IS ADDED IN THE ACTOR INSTANCE
			  
		  }
		   film.setActors(actor1);        //setting the value of an actors in the film
		   
		   // retreving the LANGUAGE VALUE from an html page  similar to that of actor
		   
		   String [] lang1=request.getParameterValues("orgLang");
		   List<Language> langs=new ArrayList<>();
		   for(String lang2:lang1)
		   {
			   Language lang3=new Language();
			   lang3.setLanguage_Id(Integer.parseInt(lang2));
			   langs.add(lang3);
		   }
		  film.setLanguages(langs);
		   
		  
		  
		 int count=filmService.addFilm1(film); //adding the value of an film in the Film Service instance 
		 if(count==1)
			{
				out.println("<head>");
				out.print("<link rel='stylesheet' type='text/css' href='css/mystyles.css'>");
				out.println("</head>");
				out.println("<body><br/><br/><br/><h2><center>Film added successfully!!!!!</center></h2></body>");
			}
				out.print("Hello");
			
		}
	}