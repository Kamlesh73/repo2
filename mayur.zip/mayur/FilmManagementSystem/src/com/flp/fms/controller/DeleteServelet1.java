package com.flp.fms.controller;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.flp.fms.service.FilmServiceImpl;

/**
 * Servlet implementation class DeleteServelet1
 */
public class DeleteServelet1 extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public DeleteServelet1() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		
		
		PrintWriter out=response.getWriter();
		
		
		//
		int id=Integer.parseInt(request.getParameter("id"));
		FilmServiceImpl filmservice=new FilmServiceImpl();
		int count=filmservice.removeFilm(id);// by taking the filmid it goes in the film service implementation 
		
		
		out.println("<head>");
		out.print("<link rel='stylesheet' type='text/css' href='css/mystyles.css'>");
		out.println("</head>");
		out.print("<body>");
		System.out.println(count);
		if(count>0){
			request.getRequestDispatcher("DeleteServelet").forward(request, response);
		}
		out.print("</body>");
		
		
	}

}
