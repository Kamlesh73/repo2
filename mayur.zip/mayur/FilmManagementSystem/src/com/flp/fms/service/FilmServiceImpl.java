package com.flp.fms.service;

import java.util.ArrayList;
import java.util.List;

import java.util.Map;
import java.util.Set;

import com.flp.fms.dao.FilmDaoImplForList;
import com.flp.fms.dao.IFilmDao;
import com.flp.fms.domain.Category;
import com.flp.fms.domain.Film;
import com.flp.fms.domain.Language;
import com.flp.fms.domain.UserLogin;

public class FilmServiceImpl implements IFilmService {
	
	FilmDaoImplForList filmDao=new FilmDaoImplForList();

	@Override
	
	//listing the languages 
	public List<Language> getLanguages() {
		
		return filmDao.getLanguages();
	}

	
	//listing the category
	@Override
	public List<Category> getCategory(){
		return filmDao.getCategory();
	}

	// this method is used for removing film 
	public Map<Integer, Film> removeFilm() {
		return filmDao.RemoveFilm();
		
	}

	/// adding the film method
	@Override
	public int addFilm1(Film film) {
		// TODO Auto-generated method stub
		return filmDao.addFilm1(film) ;
	}

	
	//this method is used to listing all the film
	@Override
	public List<Film> getAllFilms() {
	
		return filmDao.getAllFilms();
		
	
	}

	//this method is used for removing a film by film id
	@Override
	public int removeFilm(int id) {
		
	return filmDao.removeFilm(id);
		
	}
	//this method is used for updating the film by film id
		@Override
		public int updateFilm(int id, Film film) {
			return filmDao.updateFilm(id,film);
		
		}
		

// this method is used to search a film 

	@Override
	public List<Film> searchFilm(Film film) {
		return filmDao.searchFilm(film);
		
	}

	
	///this method is used to search the film by film-id
	public Film getSearchFilmByID(int id) {
		
		return filmDao.getSearchFilmByID(id);
	}

	
	/// this is for loginUser 
	@Override
	public boolean isValidUser(UserLogin login) {
		
		
		return filmDao.isValidUser(login);
	}


	}




