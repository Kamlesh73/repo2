package com.flp.fms.service;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import com.flp.fms.domain.Category;
import com.flp.fms.domain.Film;
import com.flp.fms.domain.Language;
import com.flp.fms.domain.UserLogin;

public interface IFilmService   {
	///METHOD DEFINE 
	public List<Language> getLanguages();
	public List<Category> getCategory();

//adding the film  
public int addFilm1(Film film);


// retreiving the film
public List<Film> getAllFilms();

//removing the film
public int removeFilm(int id);

//seraching the film
List<Film> searchFilm(Film film);



//updating the film by using the film id
public int updateFilm(int id,Film film);


//login method
public boolean isValidUser(UserLogin login);



}