package com.flp.fms.service;

import java.util.List;
import java.util.Set;

import com.flp.fms.domain.Actor;

public interface IActorService {
	
	
	public List<Actor>addActor();

	
	///listing the actors
	List<Actor> getActorList();
	
	
	
	//adding the actors

	public int addActor(Actor actor);
	
	//removing the actor
	
	public int deleteActor(int id);
	
	
	//updating the actors

	public int updateFilm(Actor actor, int actorId);

	//getting actor by Id
	
	public Actor getActorByID(int id);
	

	
	
	

}
