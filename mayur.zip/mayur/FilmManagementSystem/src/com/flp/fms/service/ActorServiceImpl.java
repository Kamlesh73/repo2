package com.flp.fms.service;

import java.util.List;
import java.util.Set;

import com.flp.fms.dao.ActorDaoImplForList;
import com.flp.fms.dao.IActorDao;
import com.flp.fms.domain.Actor;

public class ActorServiceImpl implements IActorService {

	
	
 IActorDao actorDao=new ActorDaoImplForList();
	
	
	@Override
	public List<Actor> addActor() {
	
		return actorDao.getActorList(); // returning to the actor dao
	}

	@Override
	public List<Actor> getActorList() {
		// TODO Auto-generated method stub
		return actorDao.addActor();

}

	@Override
	
	//adding the actors returning to the dao 
	public int addActor(Actor actor) {
		return actorDao.addActor(actor);
	}

	@Override
	public int deleteActor(int id) {
		
		return actorDao.deleteActor(id);
		
		
	}

	@Override
	public int updateFilm(Actor actor, int actorId) {
		
		return actorDao.updateFilm(actor, actorId);
	}

	@Override
	public Actor getActorByID(int id) {
		
		return actorDao.getActorByID(id);

	}


	}

