package com.flp.fms.dao;
import java.sql.Connection;
import java.util.ArrayList;
import java.util.List;

import java.util.Map;

import com.flp.fms.domain.Actor;
import com.flp.fms.domain.Category;
import com.flp.fms.domain.Film;
import com.flp.fms.domain.Language;
import com.flp.fms.domain.UserLogin;

public interface IFilmDao {

	////Defining the Method
	public List<Language> getLanguages();
	public List<Category> getCategory();

	public Map<Integer, Film> RemoveFilm();

	public int addFilm1(Film film);
	
	public int removeFilm(int id);
	
	public Map<Integer, Film> SearchFilm();
	
	
	//public List<Film> searchAllFilm(Film film);

	List<Film> searchFilm(Film film);
	
	
	public int updateFilm(int id,Film film);
	
	boolean isValidUser(UserLogin login);

	
	

	




		
	}
	
	
	

	








