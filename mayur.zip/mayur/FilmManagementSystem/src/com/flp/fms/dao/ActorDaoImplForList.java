package com.flp.fms.dao;


import java.sql.Connection;

import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import com.flp.fms.domain.Actor;

public class ActorDaoImplForList implements IActorDao {

	/*@Override
	public Set<Actor> getActor() {
	Set<Actor> actors=new HashSet<>();
	
	actors.add(new Actor(101,"Tom","Jerry"));
	actors.add(new Actor(102,"Shahrukh","Khan"));
	actors.add(new Actor(103,"salman","Jerry"));
	actors.add(new Actor(104,"amir","Jerry"));
	actors.add(new Actor(105,"kamal","Jerry"));
	actors.add(new Actor(106,"hasan","Jerry"));
	
		return actors;*/
	
	
	

	@Override
	public List<Actor> addActor() {
		// TODO Auto-generated method stub
		return getActorList();
	}

		//creating a connection to an database	
	
	
public Connection getConnection(){
		Connection connection=null;
		try {
			Class.forName("com.mysql.jdbc.Driver");
			connection=DriverManager.getConnection("jdbc:mysql://localhost:3306/database123", "root", "Pass1234");
			
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	
		return connection;
	}

/// listing the actor implementation
	@Override
	public List<Actor> getActorList()
	{
		List<Actor> actor=new ArrayList<>();
		FilmDaoImplForList film=new FilmDaoImplForList();
		
		Connection con=film.getConnection();
		
		
		
		String sql="select * from ACTORR";
		try {
			PreparedStatement pst=con.prepareStatement(sql);
			ResultSet rs=pst.executeQuery();
			
		
			while(rs.next())
			{
				Actor act1=new Actor();
				act1.setActor_Id(rs.getInt(1));
				act1.setFirstName(rs.getString(2));
				act1.setLastNAME(rs.getString(3));
				actor.add(act1);	
			}	
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return actor;
	}



	/// adding the actor implementation
	@Override
	public int addActor(Actor actor) {
		
		
		Connection con=getConnection();
		String sql="insert into ACTORR(firstName,lastName)"
				+ "	 values(?,?)";
		
		int count=0;
		try {
			PreparedStatement pst=con.prepareStatement(sql);
			pst.setString(1, actor.getFirstName());
			pst.setString(2, actor.getLastNAME());
			
			count=pst.executeUpdate();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		try {
			con.close();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return count;	
		
	}


	/// deleting the actor implementation
	@Override
	public int deleteActor(int id) {
		
		int count=0;
		Connection con=getConnection();
		String sql="delete from ACTORR where actor_Id=?";
		
		/*System.out.println("deleted the actor");*/
		
		try {
			
			PreparedStatement pst=con.prepareStatement(sql);
			pst.setInt(1, id);
			
			count=pst.executeUpdate();
		
		} catch (Exception e) {
		
			e.printStackTrace();
		}
		
		try {
			con.close();
		} catch (SQLException e) {
			
			
			e.printStackTrace();
		}
		return count;
	}


	///updating  the actor implementation
	@Override
	public int updateFilm(Actor actor, int actorId) {
		
		int count=0;
		
	    Connection con=getConnection();
	    String sql="update ACTORR set firstName=?,lastName=? where actor_id=?";
	    
	    
	    try {
			PreparedStatement pst=con.prepareStatement(sql);
			pst.setString(1, actor.getFirstName());
			pst.setString(2, actor.getLastNAME());
			pst.setInt(3, actorId);
			
			
			count=pst.executeUpdate();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	
	        return count;
	}


//searching the actor implementation
	@Override
	public Actor getActorByID(int id) {
		
		
			
	        Actor actor=new Actor();
			Connection con=getConnection();
			String sql="select * from ACTORR where actor_id=?";
			
			try {
				PreparedStatement pst=con.prepareStatement(sql);
				pst.setInt(1, id);
				ResultSet rs=pst.executeQuery();
				
				
				while(rs.next())
				{
					actor.setFirstName(rs.getString(2));
					actor.setLastNAME(rs.getString(3));
				}
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
			return actor;
		
		
	}
	
		
	
	}

