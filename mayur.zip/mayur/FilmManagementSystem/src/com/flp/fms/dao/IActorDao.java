package com.flp.fms.dao;

import java.util.ArrayList;
import java.util.List;
import java.util.Set;

import com.flp.fms.domain.Actor;

public interface IActorDao {
	
	//this method is used to adding the actor
	public List<Actor>addActor();

	//This method is used to list the actor in the db
	List<Actor> getActorList();
	
	
	//this method is used add the actor in the list
	public int addActor(Actor actor);
	
	
	//this method is used delete the actor 
	public int deleteActor(int id);
	
	
	//this method is used to update the actorr
	
	public int updateFilm(Actor actor, int actorId);


	//getting actor by id
	
	public Actor getActorByID(int id);
	
}
