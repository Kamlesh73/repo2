package org.flp.fms.util;

import static org.junit.Assert.*;

import java.util.ArrayList;
import java.util.List;

import org.junit.Test;

import com.flp.fms.domain.Language;
import com.flp.fms.service.FilmServiceImpl;
import com.flp.fms.service.IFilmService;

public class TestingLanguage {


	

	  //TEST CASES FOR Language
			//1.Object is null
			//2.duplicate Language entry should not be allowed
			//3.Not Valid Language
	        //4.get all Languages
	IFilmService filmService=new FilmServiceImpl();

	@Test
	public void isLanguageObjectIsNull() {
		
		Language language=null;
		assertNotEquals(language, filmService.getLanguages());
		
	} 
	@Test
	public void noDuplicateLanguageEntry() {
		
		Language language=new Language(23,"marathi");
		assertNotEquals(language,filmService.getLanguages());
		
	}
	@Test
	public void isNotValidLanguage() {
		
		Language language=new Language(20,"ABC");
		assertNotEquals(language,filmService.getLanguages());
		
	}
	
	
	//TEST CASE FOR LIST OF LANGUAGES
		@Test
		public void GetAllLanguages(){
			

			List<Language>languages=new ArrayList<>();
			
			languages.add(new Language(21, "english"));
			languages.add(new Language(22, "hindi"));
			languages.add(new Language(23, "marathi"));
			languages.add(new Language(24, "Telugu"));
			languages.add(new Language(25, "tamil"));
			
			assertNotEquals(languages, filmService.getLanguages());
			
		}

}

