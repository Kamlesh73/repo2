package org.flp.fms.util;

import static org.junit.Assert.*;

import java.util.ArrayList;
import java.util.List;

import org.junit.Test;

import com.flp.fms.domain.Category;
import com.flp.fms.service.FilmServiceImpl;
import com.flp.fms.service.IFilmService;

public class TestingCategory {

	
	//TEST CASES FOR Category
		//1.Object is null
		//2.duplicate category entry should not be allowed
		//3.Not Valid category
		//4.Get all Category

	IFilmService filmService=new FilmServiceImpl();

	@Test
	public void isCategoryObjectIsNull() {
		
		Category category=null;
		assertNotEquals(category, filmService.getCategory());
		
	} 

	@Test
	public void noDuplicateActorEntry() {
		
		Category category=new Category(10,"HORROR");
		assertNotEquals(category,filmService.getCategory());
		
	}

	@Test
	public void isNotValidCategory() {
		
		Category category=new Category(20,"ABC");
		assertNotEquals(category,filmService.getCategory());
		
	}


	//TEST CASE FOR LIST FOR CATEGORY
		@Test
		public void testGetCategory(){
			
			List<Category> category=new ArrayList<>();
			
			category.add(new Category(10, "HORROR"));
			category.add(new Category(11, "ROMANCactoractor1FIR"));
			category.add(new Category(12, "THRILLER"));
			category.add(new Category(13, "TIMEPASS"));
			category.add(new Category(14, "BORING"));
			category.add(new Category(15, "romantic"));
			category.add(new Category(16, "family"));
			category.add(new Category(17, "action"));
		
			assertEquals(category, filmService.getCategory());
			
		}


	}

