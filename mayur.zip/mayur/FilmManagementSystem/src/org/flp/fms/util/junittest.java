package org.flp.fms.util;

import static org.junit.Assert.*;

import java.util.ArrayList;
import java.util.List;

import org.junit.Test;

import com.flp.fms.dao.ActorDaoImplForList;
import com.flp.fms.dao.IActorDao;
import com.flp.fms.domain.Actor;

public class junittest {

	IActorDao actorDao=new ActorDaoImplForList();
	
	
	@Test
	public void isActorObjectIsNull() {
		
		Actor actor=null;
		assertNotEquals(actor, actorDao.getActorByID(50));
		
	} 
	@Test
	public void noDuplicateActorEntry() {
	
		Actor actor=new Actor(1,"Sharukh","Khan");
		assertNotEquals(actor, actorDao.getActorByID(2));
		
	}
	@Test
	public void isNotValidActor() {
		
		Actor actor=new Actor(15,"ABC","XYZ");
		assertNotEquals(actor, actorDao.getActorByID(15));
		
	}
	
	
	@Test
	public void isNotValidActorEntry() {
		
		Actor actor=new Actor(15,"ABC","XYZ");
		assertEquals(1, actorDao.addActor(actor));
		
	}
	
	

	//TEST CASE FOR ACTOR LIST
	@Test
	public void testGetActor(){
		List<Actor> actor=new ArrayList<>();
		
		actor.add(new Actor(9, "shahrukh", "Khan"));
		actor.add(new Actor(10, "Salman", "Khan"));
		actor.add(new Actor(3, "Hritik", "Roshan"));
		actor.add(new Actor(4, "Aishwarya", "Rai"));
		actor.add(new Actor(5, "Kaitrina", "Kaif"));
		actor.add(new Actor(6, "Ranbir", "kapoor"));
		actor.add(new Actor(7, "Shraddha", "Kapoor"));
		actor.add(new Actor(8, "Nana", "Patekar"));
		actor.add(new Actor(9, "Akshay", "Kumar"));
	
		
		assertEquals(actor, actorDao.getActorList());

	}
	
}

	
	
	

