package com.flp.fms.service;

import java.util.List;
import java.util.Set;

import com.flp.fms.dao.ActorDaoImplForList;
import com.flp.fms.dao.IActorDao;
import com.flp.fms.domain.Actor;

public class ActorServiceImpl implements IActorService {

	
	
 IActorDao actorDao=new ActorDaoImplForList();
	
	
	@Override
	public List<Actor> addActor() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public List<Actor> getActorList() {
		// TODO Auto-generated method stub
		return null;
	}

	


	

}
