package com.flp.fms.service;

import java.util.List;
import java.util.Map;
import java.util.Set;

import com.flp.fms.dao.FilmDaoImplForList;
import com.flp.fms.domain.Category;
import com.flp.fms.domain.Film;
import com.flp.fms.domain.Language;

public class FilmServiceImpl implements IFilmService {
	
	FilmDaoImplForList filmDao=new FilmDaoImplForList();

	@Override
	public List<Language> getLanguages() {
		
		return filmDao.getLanguages();
	}

	@Override
	public List<Category> getCategory(){
		return filmDao.getCategory();
	}

	@Override
	public void addFilm(Film film) {
//		film.setFilm_Id(generate_Film_Id());
		film.setFilm_Id(generate_Film_Id());
		filmDao.addFilm(film);
		
	}
	
	
	public int generate_Film_Id(){
		
		int filmId=0;
		
		//Verify filmId has been Duplicated or not
		do{
			double fid=Math.random()*1000;
			filmId=(int)fid;
		}while(checkDuplicateFilmId(filmId));

		return filmId;
	}

	private boolean checkDuplicateFilmId(int filmId) {
		Set<Integer> keys= getAllFilms().keySet();
		boolean flag=false;
		if(keys.isEmpty() || keys==null){
			flag= false;
		}else{
			for(Integer key:keys){
				if(key==filmId){
					flag=true;
					break;
				}
			}
		}
		
		return flag;
		
	}
	

	@Override
	public Map<Integer, Film> getAllFilms() {
		
		return filmDao.getAllFilms();
	
	}

	//@Override
	/*public void searchFilm(Film film) {
		// TODO Auto-generated method stub
		
	}
*/
	@Override
	public Map<Integer, Film> searchFilms() {
		return filmDao.SearchFilm();
	
	

		
	}

	public Map<Integer, Film> removeFilm() {
		return filmDao.RemoveFilm();
		
	}



	}

	
	

