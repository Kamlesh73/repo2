package com.flp.fms.domain;

public class Category {

	
	private int category_id;
	
	private String category_Name;

	/**
	 * @param category_id
	 * @param category_Name
	 */
	
	///constructor using fields
	public Category(int category_id, String category_Name) {
		super();
		this.category_id = category_id;
		this.category_Name = category_Name;
	}

	public int getCategory_id() {
		return category_id;
	}

	public void setCategory_id(int category_id) {
		this.category_id = category_id;
	}

	public String getCategory_Name() {
		return category_Name;
	}

	public void setCategory_Name(String category_Name) {
		this.category_Name = category_Name;
	}

	
	////// hashcode method
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((category_Name == null) ? 0 : category_Name.hashCode());
		result = prime * result + category_id;
		return result;
	}

	
	/// equals method
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Category other = (Category) obj;
		if (category_Name == null) {
			if (other.category_Name != null)
				return false;
		} else if (!category_Name.equals(other.category_Name))
			return false;
		if (category_id != other.category_id)
			return false;
		return true;
	}

	
	/// to string 
	@Override
	public String toString() {
		return "Category [category_id=" + category_id + ", category_Name=" + category_Name + "]";
	}

	/**
	 * 
	 */
	
	// no argument constructor
	public Category() {
		super();
	}
	
}
