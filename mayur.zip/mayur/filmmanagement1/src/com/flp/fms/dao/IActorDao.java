package com.flp.fms.dao;

import java.util.ArrayList;
import java.util.List;
import java.util.Set;

import com.flp.fms.domain.Actor;

public interface IActorDao {
	
	
	public List<Actor>addActor();

	List<Actor> getActorList();
	
	
/*	
	public void saveActor(Actor actor1);
	
	public ArrayList<Actor> getAllActor();

	ArrayList<Actor> getAllActor1();
	*/

}
