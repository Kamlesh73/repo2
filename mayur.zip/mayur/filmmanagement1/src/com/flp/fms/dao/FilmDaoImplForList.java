package com.flp.fms.dao;

import java.sql.Connection;
import java.util.ArrayList;


import java.util.HashMap;

import java.util.List;

import java.util.Map;

import com.flp.fms.domain.Film;

import com.flp.fms.domain.Language;

import com.flp.fms.domain.Category;

public class FilmDaoImplForList implements IFilmDao{

	
	//private Map<Integer, Film>film_Repository1=new HashMap<>();
	private Map<Integer, Film> film_Repository=new HashMap<>();

	@Override
	public List<Language> getLanguages(){
		// TODO Auto-generated method stub
			List<Language> languages=new ArrayList<>();
			languages.add(new Language(1, "English"));
			languages.add(new Language(2, "Hindi"));
			languages.add(new Language(3, "Telegu"));
			languages.add(new Language(4, "Marati"));
			languages.add(new Language(5, "Kananta"));
			languages.add(new Language(6, "Tamil"));
			languages.add(new Language(7, "Malayalam"));
			return languages;
		}
	

	@Override
	public List<Category> getCategory() {
		List<Category> categorys=new ArrayList<>();
		 categorys.add(new Category(1, "horror"));
		 categorys.add(new Category(2, "romance"));
		 categorys.add(new Category(3, "action"));
		return categorys;
	 
	}
	
	//CURD Operation
			@Override
			public void addFilm(Film film){
			film_Repository.put(film.getFilm_Id(), film);
			}
			
			@Override
			public Map<Integer, Film> getAllFilms() {
			
			return film_Repository;
			}
			
			@Override
			public Map<Integer, Film> SearchFilm() {
			return  film_Repository;
			//Map<Integer, Film> search_Repository;
			//return search_Repository;
			}
			
			
			@Override
			public Map<Integer, Film> RemoveFilm() {
			return film_Repository;
		}


			public Connection getConnection() {
				// TODO Auto-generated method stub
				return null;
			}
	
	}
	