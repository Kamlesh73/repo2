package com.flp.fms.view;


import java.util.ArrayList;
import java.util.Collection;
import java.util.Date;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
//import java.sql.Date;
import java.util.Scanner;
import java.util.Set;

import com.flp.fms.domain.Actor;
import com.flp.fms.domain.Category;
import com.flp.fms.domain.Film;
import com.flp.fms.domain.Language;
import com.flp.fms.util.Validate;


public class UserInteraction {
	
	
	
Scanner sc=new Scanner(System.in);
	
	//FUNCTION TO PROMPT THE USER TO ENTER FILM ID
		public int readFilmId(){
			
			System.out.println("enter film id");
			return sc.nextInt();
		}
		
		//FUNCTION TO PROMPT THE USER TO ENTER FILM TITLE
		public String readTitle(){
				
			System.out.println("enter film title");
			String title = sc.nextLine();
			return title;
		}
		//FUNCTION TO PROMPT THE USER TO ENTER ACTOR FIRST NAME
		public String readFirstName(){
				
			System.out.println("enter first name of Actor");
			return sc.next();
		}
		
		
		//FUNCTION TO PROMPT THE USER TO ENTER ACTOR LAST NAME
		public String readLastName(){
					
			System.out.println("enter Last name of Actor");
			return sc.next();
		}
		
		//FUNCTION TO PROMPT THE USER TO ENTER FILM RATING
		public int readRating(){
					
			System.out.println("enter film rating");
			return sc.nextInt();
		}
		public Film addFilm(List<Language> languages,List<Category> categories,List<Actor> allActors){
			
			Film film = new Film();
			
			//Local variables
			String title;
			String releaseDate;
			Language originalLanguage;
			String rentalDuration;
			int length;
			int ratings;
			Set<Language> otherLanguages;
			Set<Actor> actors;
			Category category;
			
			boolean flag = false;
			
			
			//TO GET FILM TITLE AND TO VALIDATE IT
			do{
				
				System.out.println("enter film title");
				title = sc.nextLine();
				
				flag = Validate.isValidTitle(title);
				
				if(!flag)
					System.out.println("Inavlid title. Enter a valid title!");
				
			}while(!flag);
			
			film.setTitle(title);
			
			//TO GET FILM DESCRIPTION
			System.out.println("enter film description: ");
			film.setDescription(sc.nextLine());
			
			

			//TO GET RELEASE DATE AND TO VALIDATE IT
			do{
				
				System.out.println("enter released date [dd-mm-yyy]: ");
				releaseDate = sc.next();
				
				flag = Validate.isValidDate(releaseDate);
				
				if(flag){
					
					Date currentDate = new Date();
					Date releaseYear = new Date(releaseDate);
					
				
					//Checking whether release date is on or before current date
					if(releaseYear.before(currentDate)||releaseYear.equals(currentDate))
						//film.setRealeaseYear(realeaseYear);
					
						film.setRealeaseYear(realeaseYear);
					
					else{
						System.out.println("Invalid date. Release date should be on or before current date");
						flag = false;
					}
				}
				
				else
					System.out.println("Inavlid date format. Please enter correct format!");
				
			}while(!flag);
			
			
			//TO GET RENTAL DURATION AND TO VALIDATE IT
			do{
				
				System.out.println("enter rental duration [dd-mm-yyyy]: ");
				rentalDuration = sc.next();
				
				flag = Validate.isValidDate(rentalDuration);
				
				if(flag){
					
					Date rental_duration = new Date(rentalDuration);
					
					//checking whether rental duration is on or after release date
					if(film.getRealeaseYear().before(rental_duration)||film.getRealeaseYear().equals(rental_duration))
						film.setRentalDuration(rental_duration);
					
					else{
						System.out.println("Invalid date. Rental duration should be on or before release date");
						flag = false;
					}
				}
				
				else
					System.out.println("Inavlid date format. Please enter correct format!");
				
			}while(!flag);
			
			//TO GET FILM LENGTH AND TO VALIDATE IT
			do{
				
				System.out.println("enter length of the film minutes: ");
				length = sc.nextInt();
				
				flag = Validate.isValidlength(length);
				
				if(!flag)
					System.out.println("Invalid length. Length must be between 0 and 1000");
			}while(!flag);
			
			film.setLength(length);
		
			
			
			//TO GET REPLACEMENT COST
			System.out.println("enter replacement cost: ");
			film.setReplacementCost(sc.nextDouble());
			
			
			
			//TO GET CATEGORY
			category = selectCategory(categories);
			film.setCategory(category);
			
			
			
			//TO GET SPECIAL FEATURES
			System.out.println("enter special features: ");
			film.setSpecialFeatures(sc.next());
			
			
			
			//TO GET AND VALIDATE RATINGS
			do{
				
				System.out.println("enter rating for the film: ");
				ratings = sc.nextInt();
				
				
				 flag= Validate.isValidratings(ratings);
			
				
				if(!flag)
					System.out.println("enter valid rating!");
				
			}while(!flag);
			
			film.setRatings(ratings);	
			
			
			//TO GET ALL ACTORS
			actors = new HashSet<>();
			System.out.println("Add all actors");
			String choice;
			do{
				Actor actor = selectActor(allActors);
				actors.add(actor);
								
				System.out.println("do you want to enter another actor? [y/n]");
				choice = sc.next();
				
			}while(choice.charAt(0)=='y'||choice.charAt(0)=='Y');
							
			film.setActors(actors);
			
			
			
			return film;
		}
		
		
		
		//FUNCTION TO SELECT A LANGUAGE FROM THE LIST
		public Language selectLanguage(List<Language> languages){
			
			Language selectedLanguage=null;
			boolean flag = false;
			
			do{	
				
				//Print Language Details
				System.out.println("\tLANGUAGES");
				for(Language language:languages)
					System.out.println(language.getLanguage_Id() + "\t" + language.getLanguage_Name());
				
				System.out.println("Choose Language:");
				int option=sc.nextInt();
				
				//Checking whether a valid language id
				for(Language language: languages)
				{
					if(option==language.getLanguage_Id())
					{
						flag=true;
						selectedLanguage=language;					
						break;
					}
				}
				
				//Print Error Message for invalid language id
				if(!flag)
					System.out.println("Please select valid Language Id!");
				
			}while(!flag);	
			
			return selectedLanguage;
		}
		
		
		
		//FUNCTION TO SELECT A CATEGORY FROM THE LIST
		public Category selectCategory(List<Category> categories){
			
			Category selectedCategory=null;
			boolean flag = false;
			
			do{	
				
				//Print Category Details
				System.out.println("\tCATEGORIES");
				for(Category category:categories)
					System.out.println(category.getCategory_id() + "\t" + category.getCategory_Name());
				
				System.out.println("Choose the Category:");
				int option=sc.nextInt();
				
				//Checking whether a valid language id
				for(Category category:categories)
				{
					if(option==category.getCategory_id())
					{
						flag=true;
						selectedCategory=category;					
						break;
					}
				}
				
				//Print Error Message for invalid category id
				if(!flag)
					System.out.println("Please select valid category Id!");
				
			}while(!flag);	
			
			return selectedCategory;
		}
		
		
		
		//FUNCTION TO SELECT AN ACTOR FROM THE LIST
		public Actor selectActor(List<Actor> allActors){
			
			Actor selectedActor = null;
			boolean flag = false;
			
			do{	
				
				//Print Actor Details
				System.out.println("\tACTORS");
				for(Actor actor: allActors)
					System.out.println(actor.getActor_Id() + "\t" + actor.getFirstName() + " " + actor.getLastNAME());
				
				System.out.println("Choose the Actor:");
				int option=sc.nextInt();
				
				//Checking whether the entered Actor Id is valid
				for(Actor actor: allActors)
				{
					if(option==actor.getActor_Id())
					{
						flag=true;
						selectedActor=actor;					
						break;
					}
				}
				
				//Print Error Message for invalid Actor Id
				if(!flag)
					System.out.println("Please select valid Actor Id!");
				
			}while(!flag);	
			
			
			return selectedActor;
		}
		
		
		
		//TO LIST ALL THE FILMS IN A LIST
		public void getAllFilm(Collection<Film> films){
			
			//getting all the films in the Film repository
			//Collection<Film> films = allFilms.values();
			
			if(films.isEmpty())
				System.out.println("No Film Exists!");
			
			else{
				
				System.out.println("FILM ID"+ "\t" + " TITLE" + "\t" + "DESCRIPTION" +"\t"
					+ "RELEASE_YEAR" + "\t" + "ORIGINAL_LANGUAGE" + "\t" + "OTHER_LANGUAGES" + "\t"
					+ "RENTAL_DURATION"	+ "\t" + "LENGTH" + "\t" + "REPLACEMENT_COST" + "\t"
					+ "RATING" + "\t" + "SPECIAL_FEATURES" + "\t" + "ACTORS" + "\t" + "CATEGORY");
						
						
				for(Film film: films){
							
					printFilm(film);
				}
			}
		}
		
		

		//FUCTION TO PRINT A FILM
		public void printFilm(Film film){
			
			
			if (film!=null) {
				
				String otherLanguages = "";
				String allActors = "";
				//getting the name of all languages in which film is released
				for (Language language : film.getLanguages()) {

					otherLanguages = otherLanguages + language.getLanguage_Name() + ", ";
				}
				//getting the name of all the actors in the film
				for (Actor actor : film.getActors()) {

					allActors = allActors + actor.getFirstName() + " " + actor.getFirstName() + ", ";
				}
				System.out.println("\n" + film.getFilm_Id() + "\t" + film.getTitle() + "\t" + film.getDescription() + "\t"
						+ film.getRealeaseYear() + "\t" + film.getOriginalLanguage().getLanguage_Name() + "\t"
						+ otherLanguages + "\t" + film.getRentalDuration() + "\t" + film.getLength() + "\t"
						+ film.getReplacementCost() + "\t" + film.getRatings() + "\t" + film.getSpecialFeatures() + "\t"
						+ allActors + "\t" + film.getCategory().getCategory_Name());
			}
			
			else
				System.out.println("Film does not exist!");
		
		
		}
		
		
	}//end of the class
			
			/*//TO GET ORIGINAL LANGUAGE 
			System.out.println("enter orginal language");
			originalLanguage = addLanguage(languages);
			film.setOriginal_Lang(originalLanguage);
					
					
			
			//TO GET OTHER LANGUAGES  
			String choice;
			otherLanguages = new HashSet<>();
			System.out.println("Choose all the languages in which film is released");
			do{

				Language lang = addLanguage(languages);
				otherLanguages.add(lang);
						
				System.out.println("do you want to enter another language? [y/n]");
				choice = sc.next();
				
			}while(choice.charAt(0)=='y'||choice.charAt(0)=='Y');
					
			film.setLanguage(otherLanguages);
			
			
			//TO GET FILM LENGTH AND TO VALIDATE IT
			do{
				
				System.out.println("enter length of the film minutes: ");
				length = sc.nextInt();
				
				flag = Validate.isValidLength(length);
				
				if(!flag)
					System.out.println("Invalid length. Length must be between 0 and 1000");
			}while(!flag);
			
			film.setLenght(length);
			
		
		
		//Replacement cost Validation
		double cost=0.0;
		boolean cflag=false;
		do{
			System.out.println("Enter the Replacement Cost:");
			cost=sc.nextDouble();
			cflag=Validate.isValidCost(cost);
			if(cflag==true)
				film.setReplacement_Cost(cost);
			else
			System.out.println("Invalid Replacement cost.Please enter number greater then zero.");
			}while(!flag);
		
			//To get Special features
			String feature;
			System.out.println("Enter the Special feature:");
			feature=sc.next();
			film.setSpecial_features(feature); 
			
			
			//Choose original Language 
			System.out.println("Choose Original Language:");
			Language language= addLanguage(languages);
			film.setOriginal_Lang(language);
			
			
			//Add All Languages
			List<Language> languages2=new ArrayList<>();
			String choice;
			boolean flag_lang;
			do{
				System.out.println("Choose all languages for the film:");
				Language language1=addLanguage(languages);
				flag_lang=Validate.checkDuplicateLanguage(languages2,language1);
				if(!flag_lang)
					languages2.add(language1);
				else
					System.out.println("Language Already exists.Please try other.");
				System.out.println("Wish to add more Language?[y/n]");
				choice=sc.next();
			}while(choice.charAt(0)=='y'||choice.charAt(0)=='Y');
			film.setLanguage(languages2);
			
			
			
			
			//Add All actors
			Set<Actor> actors2=new HashSet<>();
			do{
				System.out.println("Choose All actors for the film:");
				Actor actor=addActor(actors);
				System.out.println("wishto add more actors?[Y/N]");
				choice=sc.next();
			}while(choice.charAt(0)=='y'||choice.charAt(0)=='Y');
			film.setActor(actors2);
			
			
			//Choose Film Category 
			System.out.println("Choose Category:");
			Category category1= selectCategory(categories);
			film.setCategory(category1);
			
			//Rating for movie
			int rate=0;
			do{
			System.out.println("Enter Film Rating");
			rate=sc.nextInt();
			flag=Validate.isValidRating(rate);
				if(!flag)
					System.out.println("Invalid Rating. Please Enter Valid Rating!");
			}while(!flag);
			film.setRating(rate);
			
		return film;
	}
//Choose valid language object from the list:

public Language addLanguage(List<Language>  languages){
	
	Language sel_language=null;
	boolean flag;
	do{	
		//Print Language Details
		for(Language language:languages)
			System.out.println(language.getLanguage_Id() + "\t" + language.getLanguage_Name());
		
		System.out.println("Choose the Language:");
		int option=sc.nextInt();
		
		flag=false;
		
		//Check the Language Object
		for(Language language: languages)
		{
			if(option==language.getLanguage_Id())
			{
				sel_language=language;
				flag=true;
				break;
			}
		}
		
		//Print Error Message
		if(!flag)
			System.out.println("Please select valid Language Id");
	}while(!flag);	
	
	return sel_language;

}
//Choose valid category
public Category selectCategory(List<Category>  categories){

Category sel_category=null;
boolean flag;
do{	
	//Print Category Details
	for(Category category:categories)
		System.out.println(category.getCategory_Id() + "\t" + category.getCategory_Name());
	
	System.out.println("Choose the category:");
	int option=sc.nextInt();
	
	flag=false;
	
	//Check the Category Object
	for(Category category:categories)
	{
		if(option==category.getCategory_Id())
		{
			sel_category= category;
			flag=true;
			break;
		}
	}
	
	//Print Error Message
	if(!flag)
		System.out.println("Please select valid category Id");
}while(!flag);	

return sel_category;
}
//Choose Valid Actor Object from the list of Actors
	public Actor addActor(Set<Actor> actors){
		
		Actor sel_actor=null;
		boolean flag=false;
		
		do{	
		for(Actor actor:actors)
			System.out.println(actor.getActor_id() + "\t" + actor.getFirstName() + "\t" + actor.getLastName());
		
		System.out.println("Choose the Actor:");
		int option=sc.nextInt();
		
		flag=false;
		
		//Check the Actor Object
		for(Actor actor: actors)
		{
			if(option==actor.getActor_id())
			{
				sel_actor=actor;
				flag=true;
				break;
			}
		}
			
		
		//Print Error Message
		if(!flag)
			System.out.println("Please select valid Actor Id");
		}while(!flag);	
		
		return sel_actor;
	}
public void getAllFilm(Collection<Film> lst) {
		
		
		
		for(Film film:lst){
			String languages="";
			for(Language language:film.getLanguage())
				languages=languages+language.getLanguage_Name()+",";
			
			System.out.println(film.getFilm_Id() + "\t" +
					film.getTitle() + "\t"+
					film.getRelease_Date() + "\t"+
					film.getRental_Duration()+"\t"+
					film.getReplacement_Cost()+"\t"+
					film.getRating()+"\t"+languages);
			}
		
	}
	
	


}*/



