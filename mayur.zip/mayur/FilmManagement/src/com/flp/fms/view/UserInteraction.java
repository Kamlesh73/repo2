package com.flp.fms.view;
import com.flp.fms.domain.Actor;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Date;
import java.util.HashSet;
import java.util.List;
import java.util.Scanner;
import java.util.Set;

import com.flp.fms.domain.Category;
import com.flp.fms.domain.Film;
import com.flp.fms.domain.Language;
import com.flp.fms.util.Validate;


public class UserInteraction{
	
	private static  boolean flag;
	Scanner sc=new Scanner(System.in);
	//private List<Language> languages;
	
	//Return fully qualified film object
	@SuppressWarnings("deprecation")
	public Film addFilm(List<Language> languages, List<Category> category, Set<Actor> actors){
		Film film=new Film();
		boolean flag=true;
		
		//Get Title and validate it
		String title=null;
		do{
		System.out.println("Enter Film Title");
		title=sc.nextLine();
		flag=Validate.isValidTitle(title);
			if(!flag)
				System.out.println("Invalid Title. Please Enter Valid Title!");
		}while(!flag);
		film.setTitle(title);
		//return film;

		//Enter the  description of the film
		System.out.println("Enter description of film");
		String desc=sc.next();
		film.setDescription(desc);
		
		//Enter the SpecialFeature of the film
		System.out.println("Enter Special Feature of film");
		String specialFea=sc.next();
		film.setSpecialFeatures(specialFea);
		
	//Get Description and Validate it
		String releaseDate;
		boolean date_flag=false;
		Date release_Date=null;///// date object
		do{
			
			do{
				System.out.println("Enter Release Date:");
				releaseDate=sc.next();
				flag=Validate.isValidDate(releaseDate);
				if(!flag)
					System.out.println("Please enter date in this Format(dd-MM-yyyy)!");
			}while(!flag);
			
			Date today=new Date();///// today is today date
			release_Date=new Date(releaseDate);///string store as date now
			if(release_Date.before(today)|| release_Date.equals(today))
				date_flag=true;
		
			if(!date_flag)
				System.out.println("Invalid Date! Date should be current date or Past Date!");
		}while(!date_flag);
		film.setRealeaseYear(release_Date);
		//return film;
		
		
		//Enter the Rental duration
		
		String rentalDuration;
		boolean rental_flag=false;
		Date rentDate=null;
		
		
		do{
		//to check correct date format
		do{
				System.out.println("Enter Rental Duration Date:");
				rentalDuration=sc.next();
				flag=Validate.isValidDate(rentalDuration);
				if(!flag)
					System.out.println("Please enter date in this Format(dd-MM-yyyy)!");
		}while(!flag);
		
		
		 rentDate=new Date(rentalDuration);
		Date releaaseDate=film.getRealeaseYear();
				
				if(rentDate.after(releaaseDate))
					rental_flag=true;
				
				if(!rental_flag)
					System.out.println("Date should be current date or future date");
		}while(!rental_flag);
		film.setRentalDuration(rentDate);;
		
       // Enter the length
		
		int length;
		do{
		System.out.println("Enter Film length");
		length=sc.nextInt();
		//flag=Validate.isValidTitle(length);
			if(length>1000)
				System.out.println("Invalid length. Please Enter Valid length!");
		}while(!flag);
		film.setLength(length);
		
		//Enter the Replacement Cost
				Double d;
				System.out.println("Enter Replacement Cost");
				d=sc.nextDouble();
				film.setReplacementCost(d);
				
				
	
		//Enter the  rating
		int ratings;
		
		do{
			
		
			System.out.println("Enter the rating of the film");
			ratings=sc.nextInt();
			if(ratings>=5)
				System.out.println("Invalid rating .Please Enter Valid Rating!");
		}while(!flag);
		film.setRatings(ratings);
		
			//Choose Valid Language Object from the list of Languages

			//Choose Language
				System.out.println("Choose Original Language");
				Language language= addLanguage(languages);
				film.setOriginalLanguage(language);
				
				
				//Add all languages
				List<Language> languages2=new ArrayList<>();
				String choice;
				boolean flag_langs;
				do{
					System.out.println("Choose All Languages for the Film:");
					Language language1= addLanguage(languages);
					
					
					flag_langs=Validate.checkDuplicateLanguage(languages2, language1);
					if(!flag_langs)
						languages2.add(language1);
					else
						System.out.println("Language already Exists. Please try other languages!");
					
					
					System.out.println("Wish to add More Languages?[y|n]");
					choice=sc.next();
				}while(choice.charAt(0)=='y'||choice.charAt(0)=='Y');
				film.setLanguages(languages2);
				
				
				
				
				
				///ADD Category OF THE FILM
				System.out.println("Choose Category:");
				Category sel_category= addCategory(category);
				film.setCategory(sel_category);
				
				//Add all Actors
				
				//Set<Actor> actors2=new HashSet<>();
				Set<Actor> actors2=new HashSet<>();
				do{
					System.out.println("Choose All Actors for the Film:");
					Actor actor=addActor(actors);
					actors2.add(actor);
					
					System.out.println("Wish to add More Actors?[y|n]");
					choice=sc.next();
				}while(choice.charAt(0)=='y'||choice.charAt(0)=='Y');
		       
				film.setActors(actors2);
				
				
		
				return film;
			}
				private Actor addActor(Set<Actor> actors) {
				Actor sel_actor=null;
				boolean flag=false;
				
				do{	
				for(Actor actor:actors)
					System.out.println(actor.getActor_Id()+ "\t" + actor.getFirstName() + "\t" + actor.getLastNAME());
				
				System.out.println("Choose the Actor:");
				int option=sc.nextInt();
				
				flag=false;
				
				//Check the Actor Object
				for(Actor actor: actors)
				{
					if(option==actor.getActor_Id())
					{
						sel_actor=actor;
						flag=true;
						break;
					}
				}
					
				
				//Print Error Message
				if(!flag)
					System.out.println("Please select valid Actor Id");
				}while(!flag);	
				
				return sel_actor;
	}



			//Choose Valid Language Object from the list of Languages
			public Language addLanguage(List<Language>  languages){
				
				Language sel_language=null;
				boolean flag;
				do{	
					//Print Langauge Details
					for(Language language:languages)
						System.out.println(language.getLanguage_Id() + "\t" + language.getLanguage_Name());
					
					System.out.println("Choose the Language:");
					int option=sc.nextInt();
					
					flag=false;
					
					//Check the Language Object
					for(Language language: languages)
					{
						if(option==language.getLanguage_Id())
						{
							sel_language=language;
							flag=true;
							break;
						}
					}
					
					//Print Error Message
					if(!flag)
						System.out.println("Please select valid Language Id");
				}while(!flag);	
				
				return sel_language;
				
			
}
             ///listing the category////
		public Category addCategory(List<Category> categories) {
						// TODO Auto-generated method stub
						Category sel_Category=null;
							boolean flag;
							do{	
								//Print Langauge Details
								for(Category category:categories)
									System.out.println(category.getCategory_id() + "\t" +  category.getCategory_Name());
								
								System.out.println("Choose the Category:");
								int option=sc.nextInt();
								
								flag=false;
								
								
								//Check the category Object
								for( Category category1: categories)
								{
									if(option==category1.getCategory_id())
									{
										sel_Category=category1;
										flag=true;
										break;
									}
								}
								
								//Print Error Message
								if(!flag)
									System.out.println("Please select valid category");
							}while(!flag);	
							
							
							
							return sel_Category;
		}



		public void getAllFilms(Collection<Film> lst) {
			
			for(Film film:lst)
			{
				
				String lang="";
				String actorName="";
			
			
				for(Language langs:film.getLanguages())
					lang=lang+langs.getLanguage_Name()+",";
				System.out.println(lang);
				for(Actor actor:film.getActors())
				{
//					actorName=actor.getActor_Fname()+" "+actor.getActor_Lname()+",";
					actorName=actor.getFirstName()+" "+actor.getLastNAME();
				}
				System.out.println(film.getFilm_Id());
				System.out.println(film.getFilm_Id()+"\t"+film.getTitle()+"\t"+film.getDescription()+"\t"+film.getRealeaseYear()+"\t"+film.getRentalDuration()+"\t"+film.getLength()+"\t"+film.getRatings()+"\t"+film.getReplacementCost()+"\t"+film.getSpecialFeatures()+"\t"+film.getOriginalLanguage().getLanguage_Name()+"\t"+film.getCategory().getCategory_Name()+"\t"+lang+"\t"+actorName);
			}
			
		}
		
public void searchFilm(Collection<Film> film_list1)
{
	
	boolean flag=false;
	String choice;
	int option;
	do{
		System.out.println("1.Search by ID");
		System.out.println("2.Search by rating");
		System.out.println("3.Search by Title");
		System.out.println("Choose your option:");
		option=sc.nextInt();
		
		if(option==1)
		{

			System.out.println("Enter film id to search:");
			int id=sc.nextInt();
			for(Film film:film_list1)
			{
				if(id==film.getFilm_Id())
				{
					System.out.println("Film is exists");
					System.out.println(film);
					flag=true;
					break;
				}
			}
			if(flag==false)
				System.out.println("film not exists");
		}
		
		 if(option==2)
		{
			System.out.println("Enter of what rating films are need to be search:");
			int rating=sc.nextInt();
	
			for(Film film:film_list1)
			{
				if(rating==film.getRatings())
				{
					//System.out.println("Film is exists");
					System.out.println(film);
					flag=true;
					break;
				}
			}
			if(flag==false)
				System.out.println("film not exists");
		}
		
	
		
		
		if(option==3)
		{
			for(Film film:film_list1)
			{
				System.err.println("Enter title for the film to search:");
				String title=sc.next();
				if(title.equals(film.getTitle()))
				{
					System.out.println("Film is exists");
					System.out.println(film);
//					flag=true;
//					break;
				}
			}
			if(flag==false)
				System.out.println("film not exists");
		}
	
	System.out.println("Wish to continue(y/Y)");
	choice=sc.next();
	
}while(choice.charAt(0)=='y'||choice.charAt(0)=='Y');
	
}




public void removeFilm(Collection<Film> film_list2) {
	boolean flag=false;
	String choice;
	int option;
	do{
		System.out.println("1.Remove by ID");
		System.out.println("2.Remove by rating");
		System.out.println("3.Remove by Title");
		System.out.println("Choose your option:");
		option=sc.nextInt();
		
		if(option==1)
		{

			System.out.println("Enter film id to remove the film:");
			int id=sc.nextInt();
			for(Film film:film_list2)
			{
				if(id==film.getFilm_Id())
				{
//					System.out.println(film);
					film_list2.remove(film);
					System.out.println("Film is removed");
					flag=true;
					break;
				}
			}
			if(flag==false)
				System.out.println("film not exists");
		}
		
		else if(option==2)
		{
			System.out.println("Enter of what rating films are need to be remove:");
			int rating=sc.nextInt();
	
			for(Film film:film_list2)
			{
				if(rating==film.getRatings())
				{
					//System.out.println("Film is exists");
//					System.out.println(film);
					film_list2.remove(film);
					flag=true;
					break;
				}
			}
			if(flag==false)
				System.out.println("film not exists");
		}
		
	
		
		
		else if(option==3)
		{
			for(Film film:film_list2)
			{
				System.err.println("Enter title for the film to remove:");
				String title=sc.next();
				if(title.equals(film.getTitle()))
				{
//					System.out.println("Film is exists");
//					System.out.println(film);
					film_list2.remove(film);
//					flag=true;
//					break;
				}
			}
			if(flag==false)
				System.out.println("film not exists");
		}
	
	System.out.println("Wish to continue(y/Y)");
	choice=sc.next();
	
}while(choice.charAt(0)=='y'||choice.charAt(0)=='Y');
	
}
}




