package com.flp.fms.view;

import java.awt.Choice;

import java.util.Collection;
import java.util.Map;
import java.util.Scanner;

import com.flp.fms.dao.FilmDaoImplForList;
import com.flp.fms.domain.Film;
import com.flp.fms.service.ActorServiceImpl;
import com.flp.fms.service.FilmServiceImpl;

public class BootClass {

	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		int option;
		UserInteraction userInteraction=new UserInteraction();
		FilmServiceImpl filmserve=new FilmServiceImpl();
		ActorServiceImpl actimp=new ActorServiceImpl();
		String choice;
		do{
		menuSelection();
		System.out.println("Enter your option:[1-6]");
		option=sc.nextInt();
		switch(option){
			case 1:
				Film film=userInteraction.addFilm(filmserve.getLanguages(),filmserve.getCategory(), actimp.getActor());
				//System.out.println(film);
				
				filmserve.addFilm(film);
				break;
			case 2:
				break;
			case 3:

			   Map<Integer, Film>filmList2=filmserve.removeFilm();
			    Collection<Film>film_list2=filmList2.values();
			    userInteraction.removeFilm(film_list2);
			    break;
			case 4:
				Map<Integer, Film>  film_lst1= filmserve.searchFilms();
				Collection<Film> lst1=film_lst1.values();
	//			userInteraction.searchFilm(lst1);
				break;
				
			case 5:
				
				Map<Integer, Film>  film_lst= filmserve.getAllFilms();
			
				System.out.println(film_lst);
				Collection<Film> lst=film_lst.values();
				userInteraction.getAllFilms(lst);
				break;

			case 6:
				System.exit(0);
				break;
				
		}
				/*System.out.println("Wish to contonue(y/Y):");
				 choice=sc.next();
				*/
		
		}while(option<=6);
		

	}

	public static void menuSelection(){
		System.out.println("1.Add Film");
		System.out.println("2.Modify Film");
		System.out.println("3.Remove Film");
		System.out.println("4.Search Film");
		System.out.println("5.GetAll Film");
		System.out.println("6.Exit");
		
	}
	
	
}
