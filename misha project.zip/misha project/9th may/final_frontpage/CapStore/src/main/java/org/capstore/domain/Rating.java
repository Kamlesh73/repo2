package org.capstore.domain;

public class Rating {

}
