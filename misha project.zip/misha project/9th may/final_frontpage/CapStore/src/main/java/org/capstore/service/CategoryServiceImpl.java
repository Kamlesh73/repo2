package org.capstore.service;
import java.util.List;
import org.capstore.dao.CategoryDao;
import org.capstore.domain.Category;
import org.capstore.domain.Discount;
import org.capstore.domain.Images_Electronics;
import org.capstore.domain.chat;
import org.capstore.domain.coupon;
import org.capstore.domain.product;
import org.capstore.domain.sub_category;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

// This Class contains the Service Methods implementd 

@Service
public class CategoryServiceImpl implements CategoryService
{
	
	@Autowired
	private CategoryDao categoryDao;

    //***************************************************************************************
	@Transactional
	public List<sub_category> getsubcategory1()
	{
		return categoryDao.getsubcategory1();
	}
	//***************************************************************************************
	@Transactional
	public List<Category> getAllCategories() {

		return categoryDao.getAllCategories();
	}
	//***************************************************************************************
	@Transactional
	public void saveCategory(Category category) {
		categoryDao.saveCategory(category);

	}

	@Transactional
	public List<sub_category> getAllSubCategories(Integer category_id) {
		// TODO Auto-generated method stub
		return categoryDao.getAllSubCategories(category_id);
	}


	//***************************************************************************************
	@Transactional
	public List<product> getAllFurniture()

	{


		return categoryDao.getAllFurniture();
	}
	//***************************************************************************************
	@Transactional
	public List<product> getAllKitchen()
	{
		return categoryDao.getAllKitchen();
	}
	//***************************************************************************************
	@Transactional
	public List<product> getAllHome()	
	{

		return categoryDao.getAllHome();

	}
	//***************************************************************************************
	// MostViewed Methods
	@Transactional
	public List<product> getmostVisitedFurniture()


	{
		return categoryDao.getmostVisitedFurniture();

	}
	//***************************************************************************************

	@Transactional
	public List<product> getDescendingPrice()
	{

		return categoryDao.getDescendingPrice();
	}
	//***************************************************************************************

	@Transactional
	public List<product> getAscendingPrice()
	{

		return categoryDao.getAscendingPrice();
	}
	//***************************************************************************************
	@Transactional
	public List<product> getRating()
	{

		return categoryDao.getRating();
	}
	//***************************************************************************************

	@Transactional
	public List<product> getCoupon()
	{
		return categoryDao.getCoupon();
	}

	//***************************************************************************************
	public void saveCoupon(coupon coupon) 
	{
		categoryDao.saveCoupon(coupon);	

	}

	//***************************************************************************************
	public void saveImage(Images_Electronics Images_Electronics )
	{
		categoryDao.saveImage(Images_Electronics);
	}

	//***************************************************************************************
	public void saveDiscount(Discount discount) {
		categoryDao.saveDiscount(discount);

	}
	//***************************************************************************************
	public List<chat> getChat()
	{
		return categoryDao.getChat();
	}
	//***************************************************************************************
	public void  saveChat(chat chat)
	{
		categoryDao.saveChat(chat);	
	}
	//***************************************************************************************

}
