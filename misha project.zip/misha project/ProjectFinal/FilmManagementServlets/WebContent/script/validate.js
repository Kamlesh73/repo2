/* JavaScript for Validating the fields*/


// These methods contains validation for various fields when adding the Film Data 

function validateField()
{
	var flag=true;
	var description = Film.description.value;
	var title = Film.title.value;
	var length = Film.length.value;
	var rental = Film.rentalDate.value;
	var rcost = Film.replaceCost.value;
	var rental = Film.rentalDate.value;
	var releaseDate=Film.releaseDate.value;
	var language=Film.originalLanguage.value;
	var languagelist=Film.multiLanguage.value;
	var actor=Film.actorName.value;
	var category=Film.category.value;

	if(!Film.description.value.match(/^[A-Za-z0-9_ ]*$/) && Film.description.value !="")
	{

		document.getElementById("unameErr1").innerHTML="*Please enter the correct description";
		flag=false;
	}
	// Title should accept only Alphabets or $
	else if(!Film.title.value.match(/^[A-Za-z0-9_ ]*$/) && Film.title.value !="")	  
	{

		document.getElementById("unameErr2").innerHTML="*Please enter correct Title";
		flag=false;
	}
	// these field should not be null
	else if(description==""||title==""||length==""||rental==""||rcost=="")

	{
		document.getElementById("allerr").innerHTML="*Please enter all mandatory fields";
		flag=false;

	}
	// Length should be > 120
	else if(length<120)
	{
		document.getElementById("allerr").innerHTML="*Please enter valid length greater than 120 minutes";
		flag=false;
	}	
	// Rental Date should be after release Date
	else if(rental<releaseDate)
		{
		
		document.getElementById("allerr").innerHTML="*Please rental Date should be after release Date";
		flag=false;
		}
	//The drop down box should not be null
	else if(language==""||languagelist==""||actor==""||category=="")
		{
		
		 document.getElementById("allerr").innerHTML="*Please select language category and actors";
		 flag=false;
		}
	
	return flag;
}

// Method that allows only entry on numbers on the Key Press event
//********************************************************************************************************

function isNumber(evt) {
	var iKeyCode = (evt.which) ? evt.which : evt.keyCode
			if (iKeyCode != 46 && iKeyCode > 31 && (iKeyCode < 48 || iKeyCode > 57))
				return false;

	return true;
}   
//*******************************************************************************************************

//Ajax Code for the Search based on various fields
//****************************************************************************************************

function displayFilm(){

	var title=f1.filmTitle.value;
	var rating=f1.rating.value;
	var category=f1.category.value;
	var Language=f1.Language.value;
	var Actor=f1.Actor.value;
	var filmId=f1.filmId.value;
	var releaseDate=f1.releaseDate.value;
	alert(releaseDate);
	
	//Ajax Code 
	var xhr = new XMLHttpRequest();
	xhr.onreadystatechange = function() {
		if (xhr.readyState == 4) {
			var data = xhr.responseText;
			document.getElementById('displayFilm').innerHTML=data;
		}
	}
	// Sending the data into the next servlet
	
	xhr.open('GET', 'SearchData?title='+title +'&rating='+rating+'&category='+category+'&Language='+Language+'&Actor='+Actor+'&filmId='+filmId+'&releaseDate='+releaseDate  , true);

	xhr.send(null);
}


//*****************************************************************************************************

