	/* Login Page to Check Verify the username and password*/


	package com.flp.fms.controller;	
	import java.io.IOException;
	import java.io.PrintWriter;
	import com.flp.fms.domain.*;
	import javax.servlet.ServletException;
	import javax.servlet.http.HttpServlet;
	import javax.servlet.http.HttpServletRequest;
	import javax.servlet.http.HttpServletResponse;
	import com.flp.fms.service.*;
	
	
	public class Login extends HttpServlet
	{
		private static final long serialVersionUID = 1L;		
		
		
		protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
			
			// Read Data from the Login form that user enters
	
			PrintWriter out = response.getWriter();	
			String username = request.getParameter("uname");
			String password = request.getParameter("upwd");
			
	       // Bind the data user enters into the Pojo class
			
			LoginUser loginuser = new LoginUser();
			loginuser.setUserName(username);
			loginuser.setPassword(password);
			
	        // call the method to verify
			
			LoginServiceImplementation service = new LoginServiceImplementation();
	
			if(service.isValidLogin(loginuser))
				//response.sendRedirect("pages/success.html");
				request.getRequestDispatcher("Pages/Login.html").forward(request, response);
			else
				response.sendRedirect("Pages/Links.html");	
	
		}
	
	
	
	}
	
	
