
/* This Servlet List the Film objects from the table Delete hyperlink*/

package com.flp.fms.controller;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import com.flp.fms.domain.Actor;
import com.flp.fms.domain.Film;
import com.flp.fms.domain.Language;
import com.flp.fms.service.ActorServiceImpl;
import com.flp.fms.service.FilmServiceImpl;


public class DeleteList extends HttpServlet 
{
	private static final long serialVersionUID = 1L;

	
	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException 
	{
		// Lists to store the reterived database
		
		FilmServiceImpl filmservice = new FilmServiceImpl();
		ArrayList<Film> filmdetails=filmservice.getAllFilms();
		ActorServiceImpl actorservice = new ActorServiceImpl();

		PrintWriter out=response.getWriter();
		
		// Html tags to structure the content
		
		out.println("<html>");
		out.println("<head>ListAll Film Details"
				+ "<link rel='stylesheet' type='text/css' href='Css/myStyle.css'></head>"
				+ "<body>"
				+ "<table border='2' align='center'>"
				+ "<tr>"
				+ "<th>Film Id</th>"
				+ "<th>Title</th>"
				+ "<th>Description</th>"
				+ "<th>ReleaseYear</th>"
				+ "<th>Original Language</th>"
				+ "<th>Rental Duration</th>"
				+ "<th>Length</th>"
				+ "<th>replacement Cost</th>"
				+ "<th>Ratings</th>"
				+ "<th>SpecialFeatures</th>"
				+ "<th>Category</th>"
				+ "<th>Language List</th>"
				+ "<th>Actor List</th>"
				+ "</tr>");

		// Reteriving the data from the film objects and display in the table format.
		
		for(Film film:filmdetails)
		{
			out.println("<tr>");
			out.println("<td>"+film.getFilm_Id()+"</td>");
			out.println("<td>"+film.getTitle()+"</td>");
			out.println("<td>"+film.getDescription()+"</td>");
			out.println("<td>"+film.getRelease_Date()+"</td>");
			out.println("<td>"+film.getOriginalLanguage().getLanguage_Name()+"</td>");
			out.println("<td>"+film.getRental_Duration()+"</td>");
			out.println("<td>"+film.getLength()+"</td>");
			out.println("<td>"+film.getReplacement_Cost()+"</td>");
			out.println("<td>"+film.getRatings()+"</td>");
			out.println("<td>"+film.getSpecial_Features()+"</td>");
			out.println("<td>"+film.getCategory().getCategory_Name()+"</td>");
			
			// Get the List of Other Languages for film from the third party table
	//************************************************************************************************
			ArrayList<Language> filmdlanguage=filmservice.getLanguageList(film.getFilm_Id());
			out.println("<td>");
			for(Language lang:filmdlanguage)
			{

				out.println(lang.getLanguage_Name());
			}
			out.println("</td>");

			// Get the List of Other Actors for film from the third party table
	//************************************************************************************************
			ArrayList<Actor> filmactor=actorservice.getActorList(film.getFilm_Id());
			out.println("<td>");
			for(Actor act:filmactor)
			{

				out.println(act.getFirst_Name()+" "+act.getLast_Name());
			}
			out.println("</td>");
			out.println("<td><a href='DeleteRecord?film_Id="+film.getFilm_Id()+"'>Delete</a></td>");



			out.println("</tr>");
		}
		out.println("</table></body>");

		out.println("</html>");


	}
}


