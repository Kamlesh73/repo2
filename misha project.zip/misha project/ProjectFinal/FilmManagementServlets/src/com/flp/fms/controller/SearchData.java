/* Servlet to get the Parameters on which search has to be performed*/

package com.flp.fms.controller;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.Date;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import com.flp.fms.domain.Actor;
import com.flp.fms.domain.Film;
import com.flp.fms.domain.Language;
import com.flp.fms.service.ActorServiceImpl;
import com.flp.fms.service.FilmServiceImpl;



public class SearchData extends HttpServlet 
{
	private static final long serialVersionUID = 1L;

	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		FilmServiceImpl filmservice = new  FilmServiceImpl();
		ActorServiceImpl actorservice = new ActorServiceImpl();

		String filmId=request.getParameter("filmId");
		String title=request.getParameter("title");
		String rating=request.getParameter("rating");
		String category=request.getParameter("category");
		String Language=request.getParameter("Language");
		String Actor=request.getParameter("Actor");
		
		// Variable Declaration
		
		int rate, fid;
		String categoryValue = null,language=null,actor=null;

		// Set the data in the film object

		Film film = new Film();
		
		
	//*******Title Field*****************************************************************************************

		film.setTitle(title);

		if(!filmId.equals("Select FilmId"))
		{
			fid= Integer.parseInt(filmId);
			film.setFilm_Id(fid);

		}
		else
			film.setRatings(0);

	//*******Rating Field*****************************************************************************************

		if(!rating.equals("Select Rating"))
		{
			rate = Integer.parseInt(rating);
			film.setRatings(rate);

		}
		else
			film.setRatings(0);
		
 //*******Category Field*****************************************************************************************

		if(!category.equals("Select Category"))
		{

			categoryValue = category;
		}
		else 
			categoryValue=null;
		
//*******Language  Field*****************************************************************************************


		if(!Language.equals("Select Language"))
		{

			language = Language;
		}
		else 
			language = null;
		
//*******Actor Field*****************************************************************************************

		if(!Actor.equals("Select Actor"))
		{

			actor = Actor;
		}
		else
			actor = null;
		
		//*******Date Field*****************************************************************************************
		
		

		// Convert the date from String to Util date
			String date = request.getParameter("releaseDate");
			if(date!="")
			{
			Date reldat = new Date(date);
			film.setRelease_Date(reldat);
			}
			else
				film.setRelease_Date(null);
			
	//*******Incoke the search Method *****************************************************************************************
	
		ArrayList<Film> filmlist = filmservice.searchAllFilm(film, categoryValue, language, actor);
		PrintWriter out=response.getWriter();

		


		out.println("<table border='2' align='center'>"
				+ "<tr>"
				+ "<th>Film Id</th>"
				+ "<th>Title</th>"
				+ "<th>Description</th>"
				+ "<th>ReleaseYear</th>"
				+ "<th>Original Language</th>"
				+ "<th>Rental Duration</th>"
				+ "<th>Length</th>"
				+ "<th>replacement Cost</th>"
				+ "<th>Ratings</th>"
				+ "<th>SpecialFeatures</th>"
				+ "<th>Category</th>"
				+ "<th>Language List</th>"
				+ "<th>Actor List</th>"
				+ "</tr>");

		for(Film film1:filmlist)
		{
			out.println("<tr>");
			out.println("<td>"+film1.getFilm_Id()+"</td>");
			out.println("<td>"+film1.getTitle()+"</td>");
			out.println("<td>"+film1.getDescription()+"</td>");
			out.println("<td>"+film1.getRelease_Date()+"</td>");
			out.println("<td>"+film1.getOriginalLanguage().getLanguage_Name()+"</td>");
			out.println("<td>"+film1.getRental_Duration()+"</td>");
			out.println("<td>"+film1.getLength()+"</td>");
			out.println("<td>"+film1.getReplacement_Cost()+"</td>");
			out.println("<td>"+film1.getRatings()+"</td>");
			out.println("<td>"+film1.getSpecial_Features()+"</td>");
			out.println("<td>"+film1.getCategory().getCategory_Name()+"</td>");
			
		// Film Other Language List	
	//************************************************************************************************
			ArrayList<Language> filmdlanguage=filmservice.getLanguageList(film.getFilm_Id());
			out.println("<td>");
			for(Language lang:filmdlanguage)
			{

				out.println(lang.getLanguage_Name());
			}
			out.println("</td>");
			
	// Actor Other Actor List	
	//************************************************************************************************

			ArrayList<Actor> filmactor=actorservice.getActorList(film.getFilm_Id());
			out.println("<td>");
			for(Actor actorlist:filmactor)
			{

				out.println(actorlist.getFirst_Name()+" "+actorlist.getLast_Name());
			}
			out.println("</td>");

			out.println("</tr>");
		}
		out.println("</table>");
	}
	
}
