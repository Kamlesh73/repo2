package com.flp.fms.service;
import com.flp.fms.controller.Login;
import com.flp.fms.domain.LoginUser;

//This class contains the Login user verification methods.

public interface ILoginService 
{
	public boolean isValidLogin(LoginUser loginuser);
	
}
