
/* Servlet to add the film data into the database*/


// Packages

package com.flp.fms.controller;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import com.flp.fms.domain.Actor;
import com.flp.fms.domain.Category;
import com.flp.fms.domain.Language;
import com.flp.fms.service.ActorServiceImpl;
import com.flp.fms.service.FilmServiceImpl;


public class AddFilm extends HttpServlet
{

	private static final long serialVersionUID = 1L;
	
	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

		// Declarations of List to store retrieved data from database

		FilmServiceImpl filmservice=new FilmServiceImpl();
		ActorServiceImpl actorservice=new ActorServiceImpl();
		ArrayList<Actor> actor=actorservice.getAllActor();
		ArrayList<Language>lang=filmservice.getAllLanguage();
		ArrayList<Category>category=filmservice.getAllCategory();
		

		// Printwriter object to display the response on webpage

		PrintWriter out=response.getWriter();
		
		// Html tags to structure the Add Film Page
		
	//************************************************************************************************	
		out.println("<html>");
		out.println("<head><center><h1>Add Film Details</h1><hr></center>"
				+ "<link rel='stylesheet' type='text/css' href='Css/myStyle.css'>"
				+ "</head>"
				
				// Validation script included

				+"<script type='text/javascript' src='script/validate.js'></script>");	


		out.println(					

				"<link href='http://code.jquery.com/ui/1.10.4/themes/ui-lightness/jquery-ui.css' rel='stylesheet'>"
						+"<script src='http://code.jquery.com/jquery-1.10.2.js'></script>"
						+"<script src='http://code.jquery.com/ui/1.10.4/jquery-ui.js'></script>"
						
						// Script for Date Picker format as per accepted by sql
						
						+"<!-- Javascript -->"
						+" <script>"
						+" $(function() {"
						+" $( '#datepicker1' ).datepicker({"
						+"dateFormat:'dd-M-yy'"
						+"});"
						+" $( '#datepicker1' ).datepicker('show');"
						+"$( '#datepicker1' ).datepicker('setDate',new Date());"
						+"});"
						+" $(function() {"
						+"$( '#datepicker2' ).datepicker({"
						+" dateFormat:'dd-M-yy'"
						+"});"
						+" $( '#datepicker2' ).datepicker('show');"
						+"$( '#datepicker2' ).datepicker('setDate',new Date());"
						+" });"
						+"</script>"


						+ "<body><center>"
						
						// Post Method is used as large secured data is passed
						
						+"<form name='Film' method='post' action='SaveFilmData' onsubmit='return validateField()''>"
		
			 			+"<div>"	
			 			+ "<table cellspacing='10'>"
			 			+"<tr>"
	//************************************************************************************************
			 			+" <td>Title</td>"
			 			+"<td><input type='text' name='title' >"
			 			+"<div id='unameErr2' class='errMsg'></div>"
			 			+"</td>" 
			 			+"</tr>"
		
	//************************************************************************************************	
						+ "<tr>"				
						+ "<td>Description</td>"
						+ "<td><input type='text' name='description'>"
						+"<div id='unameErr1' class='errMsg'></div>"
						+"</td>" 
						+"</tr>"
		
	//************************************************************************************************					+"<tr>"
						+"<td>Release Date</td>"
						+"<td><input type='text' name='releaseDate' id='datepicker1'></td>" 
						+"</tr>"
						+"<tr>"
						
	//************************************************************************************************
						+"<td>Rental_Duration:</td>"
						+"<td><input type='text' name='rentalDate' id='datepicker2'> </td>" 
						+"</tr>"
	//************************************************************************************************
						+"<tr>"  
						+"<td>Length:</td>"
						+"<td><input type='text' name='length' onkeypress='javascript:return isNumber(event)''> </td>" 
						+"<tr>" 
						+"<tr>"  
		
	//************************************************************************************************	
					     +"<td>Replacement_Cost:</td>"
					     +" <td> <input type='text' name='replaceCost' onkeypress='javascript:return isNumber(event)'> </td>" 
					     +"</tr>"  
   //************************************************************************************************
			 			 +"<tr>" 
			 			 +"<td> Ratings:</td>"
			 			 +"<td><select name='rating'>"
			 			 +"<option value='1'>1</option>"
			 			 +"<option value='2'>2</option>"
			 			 +"<option value='3'>3</option>"
			 			 +"<option value='4'>4</option>"
			 			 +"<option value='5'>5</option>"
			 			 +"</select> </td>" 
			 			 +"</tr>" 
//************************************************************************************************
						 +"<tr>"
						 +"<td> Special Features:</td>"
						 +"<td><textarea name='special'> </textarea></td>"
						 +"</tr>"); 
//************************************************************************************************
		

		out.println("<tr>");				
		out.println("<td>Actor</td>");
		out.println("<td>");

		out.println("<select multiple name='actorName'>");

		for(Actor act:actor)
		{
			out.println( " <option value= " + act.getActor_Id() + ">"+act.getFirst_Name()+"</option>");
		}
		out.println("</select>");
		out.println("</td>");
		out.println("</tr>");							

//************************************************************************************************
		out.println("<tr>");
		out.println("<td>Original Language</td>");
		out.println("<td>");

		out.println("<select name='originalLanguage'>");
		for(Language lang1:lang)
		{
			out.println( " <option value= " + lang1.getLanguage_Id() + ">"+lang1.getLanguage_Name()+"</option>");
		}
		out.println("</select>");
		out.println("</td>");
		out.println("</tr>");									
//************************************************************************************************

		out.println("<tr>");									
		out.println("<td>Language</td>");
		out.println("<td>");											
		out.println("<select multiple name='multiLanguage'>");
		for(Language lang1:lang)
		{
			out.println( " <option value= " + lang1.getLanguage_Id() + ">"+lang1.getLanguage_Name()+"</option>");
		}
		out.println("</select>");
		out.println("</td>");
		out.println("</tr>");

//************************************************************************************************

		out.println("<tr>");

		out.println("<td>Category</td>");
		out.println("<td>");

		out.println("<select name='category'>");

		for(Category catg:category)
		{
			out.println( " <option value= " + catg.getCategory_Id() + ">"+catg.getCategory_Name()+"</option>");
		}
		out.println("</select>");
		out.println("</td>");
		out.println("</tr>");
//************************************************************************************************
		out.println("<tr>"+
				"<td><input class='myButton' type='submit' value='Save' ></td>"+
				"<td><input class='myButton' type='reset' value='Clear'></td>"+	
				"</td>"+
				"</tr>"+
				
				"</table>"+
				"<div id='allerr' class='errMsg'></div>");			

		out.println("</table></div></form></center></body>");

		out.println("</html>");


	}
}
