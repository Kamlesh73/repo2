package com.flp.fms.service;

import com.flp.fms.domain.*;

public class LoginServiceImplementation implements ILoginService
{
	public boolean isValidLogin(LoginUser loginuser)
	{
		if(loginuser.getUserName().equals("Misha")&&loginuser.getPassword().equals("abc"))
		
		return true;
		else
		return false;
		
		
		
	}
}
