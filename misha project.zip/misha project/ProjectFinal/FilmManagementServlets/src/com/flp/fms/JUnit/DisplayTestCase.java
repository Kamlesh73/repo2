/*Test Cases for GetAll List */ 

package com.flp.fms.JUnit;
import static org.junit.Assert.*;

import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import org.junit.Test;

import com.flp.fms.domain.Actor;
import com.flp.fms.domain.Category;
import com.flp.fms.domain.Film;
import com.flp.fms.domain.Language;
import com.flp.fms.service.ActorServiceImpl;
import com.flp.fms.service.FilmServiceImpl;
/*1. Test Case for testToPass for getAll() 
 *2. Test Case for getLanguage when 0 is input 
 *3. TestCase for getLanguage when filmId is notNull
 *4. TestCase for getCategory method*/

public class DisplayTestCase 
{
	FilmServiceImpl filmservice=new FilmServiceImpl();
	ActorServiceImpl actorservice = new ActorServiceImpl();
	//**********************************************************************
	
	@Test
	public void whenFilmIdNotNull() 
	{
		ArrayList<Film> filmlist=filmservice.getAllFilms();	
		
		assertEquals(filmservice.getAllFilms(),filmlist);
	}
	
	// Get Film by Language Id Method Test
	//**********************************************************************
	
	@Test
	public void whenFilmIdNull() 
	{
		ArrayList<Film> filmlist=filmservice.getAllFilms();	
		
		assertEquals(filmservice.getLanguage(0),null);
	}
	//**********************************************************************
	@Test
	public void whenLanguageIdNotNull() 
	{
		Language language = new Language();
		ArrayList<Language> filmlist = filmservice.getAllLanguage();		
		assertNotEquals(filmservice.getLanguage(3),null);
	}
	
	//**********************************************************************
		@Test
		public void whenNotNull() 
		{
			Category category = new Category();
			ArrayList<Category> filmlist = filmservice.getAllCategory();		
			assertEquals(filmservice.getAllCategory(),filmlist);
		}
	
		//Test Case Method to get Actor List
	//***********************************************************************
		
		@Test
		public void whenActorNotNull() 
		{
			Actor actor = new Actor();			
			
			assertNotEquals(actorservice.getActor(3),null);
		}
		//Test Case Method to get Actor List
		//***********************************************************************
			
			@Test
			public void whenActorNull() 
			{
				Actor actor = new Actor();			
				
				assertEquals(actorservice.getActor(0),null);
			}
		
		
	
}
