
/* Servlet to Display the Various Parametrs on which Search the  to update list*/
package com.flp.fms.controller;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import com.flp.fms.domain.Film;
import com.flp.fms.service.FilmServiceImpl;


public class SelectUpdateList extends HttpServlet
{
	private static final long serialVersionUID = 1L;

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException 
	{
		PrintWriter out=response.getWriter();
		FilmServiceImpl filmservice = new FilmServiceImpl();
		
		// Bind the database film data into the list
		
		ArrayList<Film> filmlist=filmservice.getAllFilmId();
		
		// Structure the elements in html 
//*****************************************************************************************************
		out.println("<html>"
				+"<head><center><h1>Update Film Details</h1><hr></center>"
				+ "<link rel='stylesheet' type='text/css' href='Css/myStyle.css'>"
				+ "</head>"			
				+ "<body>");	
		out.println("<form name='FilmUpdate'  action='UpdateFilmData' onsubmit='return validateField()''>");
		out.println("<table border='2' align='center' cellspacing='20'>"
				+ "<tr>"
				+ "<th>Select Options</th>"
				+ "<th>Click</th>"
				+ "</tr>"
				+ "<tr>"
// FilmId
//*****************************************************************************************************
				+ "<td><select name='filmId'>"
				+ "<option selected='true'>Select FilmId</option>");

				for(Film film:filmlist)
				  {
					 out.println("<option value='"+ film.getFilm_Id()+"'>" + film.getFilm_Id() +"</option>");
				  }

		out.println("</select>");
	 
//*****************************************************************************************************


		out.println("<td><input class='myButton' type='submit' value='Update' >");
		out.println("</tr>");
		out.println("<tr>"
				+ "<td><input type='text' name='filmTitle' size='20'></td>"
				+ "<td><input class='myButton' type='submit' value='Update'></td>"
				+ "</tr>");
		out.println("</table>");
		out.println("</form></body></html>");
	}

}

