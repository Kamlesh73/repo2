	
	/* Servlet to invoke the Delete method and redirect to next page*/
	
	
	package com.flp.fms.controller;
	import java.io.IOException;
	import java.io.PrintWriter;
	import javax.servlet.ServletException;
	import javax.servlet.http.HttpServlet;
	import javax.servlet.http.HttpServletRequest;
	import javax.servlet.http.HttpServletResponse;
	import com.flp.fms.service.FilmServiceImpl;
	
	
	public class DeleteRecord extends HttpServlet
	{
		private static final long serialVersionUID = 1L;	
	
		protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
			String filmid=request.getParameter("film_Id");
			FilmServiceImpl filmservice = new FilmServiceImpl();
			
			// Invoke the Delete Method based on FilmId
			
			boolean flag=filmservice.deleteFilm(Integer.parseInt(filmid));	

			// If the delete is successful redirect to the next servlet.
	//************************************************************************************************
			if(flag)
			{
				request.getRequestDispatcher("GetFilmDetails").forward(request, response);	
				PrintWriter out=response.getWriter();	
				out.println("<html><body>");
				out.println("<h1>Film Record Deleted  Successfully</h1>");
				out.println("</body></html>");
	
			}
		}
	
	}