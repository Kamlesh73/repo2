package com.flp.fms.service;

import java.util.ArrayList;
import com.flp.fms.domain.Actor;
import com.flp.fms.domain.Category;
import com.flp.fms.domain.Film;
import com.flp.fms.domain.Language;

//These methods are implemented in the FilmService Implementation class
public interface IFilmService 
{
	
	public int saveEmployee(Film film);	
	public ArrayList<Actor> getAllActor();
	public ArrayList<Language> getAllLanguage();
	public ArrayList<Category> getAllCategory();
	public ArrayList<Film> getAllFilms();
	public ArrayList<Language> getLanguageList(int fid);
	public ArrayList<Film> searchAllFilm(Film film,String categoryValue,String language,String Actor);
	public boolean deleteFilm(int filmId);
	public void updateFilm(Film film, Language language_Selected, Category catgeory_Selected);
	public ArrayList<Film> searchFilm(Film film);
	
}
