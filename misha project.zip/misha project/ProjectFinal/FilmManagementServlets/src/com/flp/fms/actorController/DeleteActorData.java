package com.flp.fms.actorController;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.flp.fms.service.ActorServiceImpl;
import com.flp.fms.service.FilmServiceImpl;

/**
 * Servlet implementation class DeleteActorData
 */
public class DeleteActorData extends HttpServlet {
	
	ActorServiceImpl actorservice = new ActorServiceImpl();
	private static final long serialVersionUID = 1L;       
   
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String actorid=request.getParameter("actor_Id");
		FilmServiceImpl filmservice = new FilmServiceImpl();
		
		// Invoke the Delete Method based on FilmId
		
		boolean flag=actorservice.deleteActor(Integer.parseInt(actorid));	

		// If the delete is successful redirect to the next servlet.
//************************************************************************************************
		if(flag)
		{
			//request.getRequestDispatcher("GetActorList").forward(request, response);	
			PrintWriter out=response.getWriter();	
			out.println("<html><body>");
			out.println("<h1>Actor Record Deleted  Successfully</h1>");
			out.println("</body></html>");

		}
	}

}