	
/* Display The Add Form of the searched Film*/

    package com.flp.fms.controller;	
	import java.io.IOException;
	import java.io.PrintWriter;
	import java.util.ArrayList;
	import java.util.List;	
	import javax.servlet.ServletException;
	import javax.servlet.http.HttpServlet;
	import javax.servlet.http.HttpServletRequest;
	import javax.servlet.http.HttpServletResponse;	
	import com.flp.fms.domain.Actor;
	import com.flp.fms.domain.Film;
	import com.flp.fms.domain.*;
	import com.flp.fms.domain.Language;
	import com.flp.fms.service.ActorServiceImpl;
	import com.flp.fms.service.FilmServiceImpl;
	
	
	public class UpdateFilmData extends HttpServlet 
	{
		private static final long serialVersionUID = 1L;	
		
		protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
	
			// Variable Declaration
			
			int filmId;	
			String getfilmId;
			
			// Store the database data in the List
			
			FilmServiceImpl filmservice = new FilmServiceImpl();
			ActorServiceImpl actorservice = new ActorServiceImpl();	
			ArrayList<Category>categoryList=filmservice.getAllCategory();	
			ArrayList<Actor> actor=actorservice.getAllActor();
			ArrayList<Language>language=filmservice.getAllLanguage();	
			Film film = new Film();
			
	// Search by filmId
			
	//*****************************************************************************************************
			getfilmId=request.getParameter("filmId");	
			if(!getfilmId.equals("Select FilmId"))
			{
				filmId= Integer.parseInt(getfilmId);
				film.setFilm_Id(filmId);
	
			}
			else
				film.setFilm_Id(0);	
			
	//Search By FilmTitle 
	//*****************************************************************************************************
		
			String filmTitle=(request.getParameter("filmTitle"));
			if(filmTitle==null)
				film.setTitle(null);
			else
				film.setTitle(filmTitle);
	//****************************************************************************************************	
			ArrayList<Film> filmlist = filmservice.searchFilm(film);	
			PrintWriter out=response.getWriter();
			
			// Search the film and display in the To Update list with various fields
	//****************************************************************************************************
			out.println("<html>");
			out.println("<head>"
					+ "<link rel='stylesheet' type='text/css' href='Css/myStyle.css'>"				
					+ "</head>"	
					+"<script type='text/javascript' src='script/validate.js'></script>");
			
			//Date Picker Script
	
			out.println("<link rel='stylesheet' type='text/css' href='css/MyStyle.css'>"							
					+"<link rel='stylesheet' type='text/css' href='../CSS_Style/subStyle.css'>"
					+"<link href='http://code.jquery.com/ui/1.10.4/themes/ui-lightness/jquery-ui.css' rel='stylesheet'>"
					+"<script src='http://code.jquery.com/jquery-1.10.2.js'></script>"
					+"<script src='http://code.jquery.com/ui/1.10.4/jquery-ui.js'></script>"
					+"<!-- Javascript -->"
					+" <script>"
					+" $(function() {"
					+" $( '#datepicker1' ).datepicker({"
					+"dateFormat:'dd-M-yy'"
					+"});"
					+" $( '#datepicker1' ).datepicker('show');"
					+"$( '#datepicker1' ).datepicker('setDate',new Date());"
					+"});"
					+" $(function() {"
					+"$( '#datepicker2' ).datepicker({"
					+" dateFormat:'dd-M-yy'"
					+"});"
					+" $( '#datepicker2' ).datepicker('show');"
					+"$( '#datepicker2' ).datepicker('setDate',new Date());"
					+" });"
					+"</script>"	
					+ "<body>"
					+"<center>"
					+"<form name='Film' method='post' action='SaveUpdatedData' onsubmit='return validateField()''>"
					+ "<h3>Update Film Details</h3>");
			
			for(Film film1:filmlist)
			{
				out.println( "<table>"
						+"<tr>"
						//**********************************************************************************************
						+" <td>Title</td>"
						+"<td><input type='text' name='title' value = "+film1.getTitle()+" >"
						+"<div id='unameErr2' class='errMsg'></div>"
						+"</td>" 
						+"</tr>"
						+ "<tr>"
						//**********************************************************************************************
						+ "<td>Description</td>"
						+ "<td><input type='text' name='description' value = "+film1.getDescription()+ ">"
						//**********************************************************************************************
						+ "<td><input type='hidden' name='htid' value = "+film.getFilm_Id()+ ">"
						+"<div id='unameErr1' class='errMsg'></div>"
						+"</td>" 
						+"</tr>"
						+"<tr>"
						//**********************************************************************************************
						+"<td>Release Date</td>"
						+"<td><input type='text' name='releaseDate' id='datepicker1' value = "+film1.getRelease_Date()+"></td>" 
						+"</tr>"
						+"<tr>"
						//**********************************************************************************************
						+"<td>Rental_Duration:</td>"
						+"<td><input type='text' name='rentalDate' id='datepicker2' value = "+film1.getRental_Duration()+"> </td>" 
						+"</tr>"
						+"<tr>"  
						//**********************************************************************************************
						+"<td>Length:</td>"
						+"<td><input type='text' name='length' value = "+film1.getLength()+" onkeypress='javascript:return isNumber(event)''> </td>" 
						+"<tr>" 
						+"<tr>" 	
						//**********************************************************************************************
						+"<td>Replacement_Cost:</td>"
						+" <td> <input value="+film1.getReplacement_Cost()+ " type='text' name='replacecost'  onkeypress='javascript:return isNumber(event)' > </td>" 
						+"</tr>"); 
				//**********************************************************************************************
				out.println("<tr><td>Ratings:</td>");
				out.println("<td><select name='rating'>");
				
				for(int i=1;i<=5;i++)
				{	
					if(i==film1.getRatings())
					{
						out.println("<option selected value="+film1.getRatings()+">"+film1.getRatings()+"</option>");
					}
					else
					{
						out.println("<option value="+i+">"+i+"</option>");	
					}				}	  
				out.println("</td></tr>");
				//**********************************************************************************************
				//Special Features	
				out.println("<tr>"
						+"<td> Special_Features:</td>"
						+"<td><Input type='text' name='special' size=3 value="+film1.getSpecial_Features()+"></td>"
						+"</tr>"); 	
				out.println("<tr>");
				//**********************************************************************************************
				out.println("<td>Actor</td>");	
	            // Compare the Actor List and Film Choosen actor list and highligt the content from database
				
				ArrayList<Actor> filmactor=actorservice.getActorList(film1.getFilm_Id());
	
				out.println("<td>");	
				out.println("<select multiple name='actorName'>");	
				for(Actor act:actor)
				{
					int flag=0;
					for(Actor actorList :filmactor)
					{
						if(act.getFirst_Name().equals(actorList.getFirst_Name()))
						{
							out.println( " <option selected value= " + act.getActor_Id() + ">"+act.getFirst_Name()+"</option>");
							flag=1;
							break;
						}	
	
					}
					if(flag!=1)
						out.println( " <option  value= " + act.getActor_Id() + ">"+act.getFirst_Name()+"</option>");	
				}
				//**********************************************************************************************
				out.println("</select>");	
				out.println("</td>");	
				out.println("</tr>");	
				out.println("<tr>");
				//**********************************************************************************************
	
				out.println("<td>Original Language</td>");
				out.println("<td>");	
				out.println("<select name='originalLanguage'>");
				for(Language lang1:language)
				{
					out.println( " <option value= " + lang1.getLanguage_Id() + ">"+lang1.getLanguage_Name()+"</option>");
				}
				out.println("</select>");
				out.println("</td>");
				out.println("</tr>");
				// Compare the Language List and Film Choosen Language list and highligt the content from database
				//**********************************************************************************************	
				out.println("<tr>");	
				out.println("<td>Other Languages:</td>");
				out.println("<td>");
				ArrayList<Language> filmdlanguage=filmservice.getLanguageList(film1.getFilm_Id());
				out.println("<select multiple name='multiLanguage'>");	
				for(Language languageList:language)
				{
					int flag1=0;
	
					for(Language selectedLang:filmdlanguage)					{
	
						if(languageList.getLanguage_Name().equals(selectedLang.getLanguage_Name()))
						{	
							out.println( " <option selected value= " + languageList.getLanguage_Id() + ">"+languageList.getLanguage_Name()+"</option>");
							flag1=1;
							break;
						}
					}	
					out.println( " <option  value= " + languageList.getLanguage_Id() + ">"+languageList.getLanguage_Name()+"</option>");	
				}
				out.println("</select>");
				out.println("</td>");
				out.println("</tr>");
				//**********************************************************************************************
	
				out.println("</select>");
				out.println("</td>");
				out.println("</tr>");
				// ***********************************************************************************************
				out.println("<tr>");	
				out.println("<td>Category</td>");
				out.println("<td>");	
				out.println("<select name='category'>");
				for(Category catg:categoryList)
				{
					if(film1.getCategory().getCategory_Id()==catg.getCategory_Id())
					{	
						out.println("<option selected value="+catg.getCategory_Id()+">"+catg.getCategory_Name()+"</option>");	
					}
					else
						out.println( "<option value= " + catg.getCategory_Id() + ">"+catg.getCategory_Name()+"</option>");
	
				}
	
				out.println("</select>");
				out.println("</td>");
				out.println("</tr>");
				// ***********************************************************************************************
				out.println("<tr>"+
						"<td><input class='myButton' type='submit' value='Save' ></td>"+
						"<td><input class='myButton' type='reset' value='Clear'>"+	
						"</td>"+
						"</tr>"+
						"</table>"+	
						"<div id='allerr' class='errMsg'></div>");		
				out.println("</table></form></center></body>");	
				out.println("</html>");
			}
		}
	}
	
