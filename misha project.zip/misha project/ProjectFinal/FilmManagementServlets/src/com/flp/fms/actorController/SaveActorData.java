// Servlet to save the actor data into the database*/
package com.flp.fms.actorController;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.Date;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import com.flp.fms.domain.Actor;
import com.flp.fms.domain.Category;
import com.flp.fms.domain.Film;
import com.flp.fms.domain.Language;
import com.flp.fms.service.ActorServiceImpl;
import com.flp.fms.service.FilmServiceImpl;

/**
 * This Servlet will take the parameters that user hase passed and save to the database
 */
public class SaveActorData extends HttpServlet 
{
	private static final long serialVersionUID = 1L;
       
    
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

	
		// Create Instance of service and domain for get and set data	
		Actor actor = new Actor();
		ActorServiceImpl actorservice = new ActorServiceImpl();
	
		//Retervie  the data from various fields in the AddFilm Servlet
		
//************************************************************************************************

		actor.setFirst_Name(request.getParameter("firstName"));			
		actor.setLast_Name(request.getParameter("lastName"));
		
		
		
//************************************************************************************************

		
		// Invoke the saveFilm Method in the FilmImplementation table
		actorservice.saveActor(actor);
		PrintWriter out=response.getWriter();		
		out.println("<html><body>");
		out.println("<h1>Actor Details Added Successfully</h1>");
		out.println("</body></html>");

	}

	}


