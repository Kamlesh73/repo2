/* This interface contains methods that manipulate the actor table*/

package com.flp.fms.service;
import java.util.ArrayList;
import com.flp.fms.domain.Actor;

// These methods are implemented in the ActorService Implementation class

public interface IActorService
{
	public ArrayList<Actor> getActor(int fid);
	public ArrayList<Actor> getAllActor();
	public ArrayList<Actor> getActorList(int fid);
	public int saveActor(Actor actor);
	public ArrayList<Actor> getAllActors(); 
	public boolean deleteActor(int actorId);
}
