

/* Reterive the parametrs from varios fields in AddFilm Table using getParameters*/

package com.flp.fms.controller;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.Date;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import com.flp.fms.domain.Actor;
import com.flp.fms.domain.Category;
import com.flp.fms.domain.Film;
import com.flp.fms.domain.Language;
import com.flp.fms.service.FilmServiceImpl;


public class SaveFilmData extends HttpServlet
{
	private static final long serialVersionUID = 1L;

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		
		ArrayList<Language> languageList=new ArrayList<>();
		ArrayList<Actor> actorList=new ArrayList<>();

		// Create Instance of service and domain for get and set data

		FilmServiceImpl filmservice =  new FilmServiceImpl();
		Film film = new Film();
		Language language = new Language();
		Actor actor = new Actor();
		Category catgeory = new Category();

		//Retervie  the data from various fields in the AddFilm Servlet
		
//************************************************************************************************

		film.setTitle(request.getParameter("title"));	
		
		film.setDescription(request.getParameter("description"));
		
		// Convert the date from String to Util date
		
		String rd = request.getParameter("releaseDate");
		Date reldat = new Date(rd);
		film.setRelease_Date(reldat);

		// Convert the date from String to Util date
		
		String rendat = request.getParameter("rentalDate");
		Date rendate = new Date(rendat);
		film.setRental_Duration(rendate);
		
//************************************************************************************************

		film.setLength(Integer.parseInt(request.getParameter("length")));		
		film.setReplacement_Cost(Double.parseDouble(request.getParameter("replaceCost")));		
		film.setRatings(Integer.parseInt(request.getParameter("rating")));		
		film.setSpecial_Features(request.getParameter("special"));	
//************************************************************************************************

		// Set the selected original language and Category into the film 		

		language.setLanguage_Id(Integer.parseInt(request.getParameter("originalLanguage")));
		film.setOriginalLanguage(language);		

		catgeory.setCategory_Id(Integer.parseInt(request.getParameter("category")));
		film.setCategory(catgeory);	
		
//************************************************************************************************

		// Multiple  language data

		String[] selang=request.getParameterValues("multiLanguage") ;		

		String mylang = "";

		for(String str: selang)
		{

			Language lang = new Language();
			mylang=mylang+str+",";
			lang.setLanguage_Id(Integer.parseInt(str));		  
			languageList.add(lang);	  

		}
		String langu = mylang.substring(0,mylang.length()-1);
		film.setLanguages(languageList);
		
//************************************************************************************************
		//Multiple actor data


		String[] selact=request.getParameterValues("actorName") ;
		String myactor1 = "";

		for(String str: selact)
		{
			Actor actor1 = new Actor();
			myactor1=myactor1+str+",";
			actor1.setActor_Id(Integer.parseInt(str));		  
			actorList.add(actor1);

		}
		String actu = myactor1.substring(0,myactor1.length()-1);
		film.setActors(actorList);
		
		
		// Invoke the saveFilm Method in the FilmImplementation table
		
		int s = filmservice.saveFilm(film);		
		if(s!=0)
		{

		PrintWriter out=response.getWriter();
		
		out.println("<html><body>");
		out.println("<h1>Film Details Added Successfully</h1>");
		out.println("</body></html>");
		}
		else
		{
			request.getRequestDispatcher("AddFilm").forward(request, response);
		}

	}

}
