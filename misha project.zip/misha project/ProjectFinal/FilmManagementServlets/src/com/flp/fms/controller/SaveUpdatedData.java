/* Bind the data Entered by the user from the various html fields */

package com.flp.fms.controller;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.Date;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import com.flp.fms.domain.Actor;
import com.flp.fms.domain.Category;
import com.flp.fms.domain.Film;
import com.flp.fms.domain.Language;
import com.flp.fms.service.FilmServiceImpl;


public class SaveUpdatedData extends HttpServlet 
{
	private static final long serialVersionUID = 1L;

	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException 
	{
		
		ArrayList<Language> language=new ArrayList<>();
		ArrayList<Actor> actor=new ArrayList<>();
		FilmServiceImpl filmser = new  FilmServiceImpl();
		FilmServiceImpl filmservice =  new FilmServiceImpl();
		
		Film film = new Film();
		Language lang1 = new Language();
		Actor act1 = new Actor();
		Category catg = new Category();	
		
//************************************************************************************************
		film.setFilm_Id(Integer.parseInt(request.getParameter("htid")));

		film.setTitle(request.getParameter("title"));
		System.out.println(film.getTitle());
		film.setDescription(request.getParameter("description"));
		
		// Acccess Date and convert into util Date
//************************************************************************************************
		String rd = request.getParameter("releaseDate");		
		Date reldat = new Date(rd);
		film.setRelease_Date(reldat);
		
		String rendat = request.getParameter("rentalDate");	
		Date rendate = new Date(rendat);
		film.setRental_Duration(rendate);

//************************************************************************************************
		film.setLength(Integer.parseInt(request.getParameter("length")));
		
		film.setReplacement_Cost(Double.parseDouble(request.getParameter("replacecost")));
		
		film.setRatings(Integer.parseInt(request.getParameter("rating")));

		film.setSpecial_Features(request.getParameter("special"));
		
		// Access the  Languages and Category from the drop down list
//************************************************************************************************

		
		lang1.setLanguage_Name(request.getParameter("originalLanguage"));	
		System.out.println(lang1);
		film.setOriginalLanguage(lang1);

		
		catg.setCategory_Id(Integer.parseInt(request.getParameter("category")));
		film.setCategory(catg);			


// Access the Multiple Languages and Actors from the drop down list
//************************************************************************************************



		String[] selang=request.getParameterValues("multiLanguage") ;	
		String mylang = "";
		for(String str: selang)
		{

			Language lang = new Language();
			mylang=mylang+str+",";
			lang.setLanguage_Id(Integer.parseInt(str));		  
			language.add(lang);	  

		}
		String langu = mylang.substring(0,mylang.length()-1);
		film.setLanguages(language);

// Access the Multiple  and Actors from the drop down list
//************************************************************************************************


		String[] selact=request.getParameterValues("actorName") ;
		String myactor1 = "";

		for(String str: selact)
		{
			Actor actor1 = new Actor();
			myactor1=myactor1+str+",";
			actor1.setActor_Id(Integer.parseInt(str));		  
			actor.add(actor1);

		}
		
		String actu = myactor1.substring(0,myactor1.length()-1);
		film.setActors(actor);
		
	// Call the update film Method and pass the parameters
	//************************************************************************************************

		filmser.updateFilm(film, lang1, catg);
		PrintWriter out=response.getWriter();
		
		out.println("<html><body>");
		out.println("<h1>Film Details Updated Successfully</h1>");
		out.println("</body></html>");
		

	}



}


