package com.flp.fms.actorController;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.flp.fms.domain.Actor;
import com.flp.fms.service.ActorServiceImpl;

/**
 * Servlet implementation class ActorDeleteList
 */
public class ActorDeleteList extends HttpServlet 
{
	private static final long serialVersionUID = 1L;
       
    
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException 
	{
		
		ActorServiceImpl actorservice = new ActorServiceImpl();
		ArrayList<Actor> actorList = actorservice.getAllActors();
		
		
		PrintWriter out=response.getWriter();
		
		//Structure for the html page.
	//************************************************************************************************
		out.println("<html>");
		out.println("<head><h1> Actor Details </h1>"
				+ "<link rel='stylesheet' type='text/css' href='Css/myStyle.css'></head>"
				+ "<body><center>"
				+ "<table border='2' align='center'>"
				+ "<tr>"				
				+ "<th>Actor Id</th>"
				+ "<th>Actor First Name</th>"
				+ "<th>Actor Last Name</th>"
				+ "<th>Delete Link</th>"
				+ "</tr>");
		
        // Retrive the data from list into the html page
		
		for(Actor actor:actorList)
		{
			out.println("<tr>");
			out.println("<td>"+actor.getActor_Id()+"</td>");
			out.println("<td>"+actor.getFirst_Name()+"</td>");
			out.println("<td>"+actor.getLast_Name()+"</td>");
			out.println("<td><a href='DeleteActorData?actor_Id="+actor.getActor_Id()+"'>Delete</a></td>");

			
			out.println("</td>");
			out.println("</tr>");
		}

		out.println("</table></center></body>");		
		out.println("</html>");	

	}
	}

	

