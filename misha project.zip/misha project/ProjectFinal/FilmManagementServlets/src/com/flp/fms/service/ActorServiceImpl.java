/* This class implements the methods in the IActorService Interface*/

package com.flp.fms.service;
import java.util.ArrayList;
import com.flp.fms.dao.FilmDaoImplForDB;
import com.flp.fms.domain.Actor;

public class ActorServiceImpl implements IActorService
{

FilmDaoImplForDB filmdao = new FilmDaoImplForDB();
	
	//Service to getAll Actor from the database with specific film id
	//****************************************************************************
	public ArrayList<Actor> getActor(int fid)
	{
		
		return filmdao.getActor(fid);
	}
	
	//Service to getAll Actor from the database 
	//****************************************************************************
	public ArrayList<Actor> getAllActor()
	{
		
		return filmdao.getAllActor();
	}
	// Service to get Actor List based on filmId
	//****************************************************************************
	
	public ArrayList<Actor> getActorList(int fid)
	{
		
		return filmdao.getActorList(fid);
	}
	// Service to Add Actor Details
	//***************************************************************************
	public int saveActor(Actor actor)
	{
		return filmdao.saveActor(actor);
	}
	//***************************************************************************
	public ArrayList<Actor> getAllActors() 
	{
		
		return filmdao.getAllActors();
	}
	//**************************************************************************
	public boolean deleteActor(int actorId)
	{
		
		return filmdao.deleteActor(actorId);
	}
	
}
