/* Servlet To add All Actors*/

package com.flp.fms.actorController;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import com.flp.fms.domain.Actor;
import com.flp.fms.domain.Category;
import com.flp.fms.domain.Language;
import com.flp.fms.service.ActorServiceImpl;
import com.flp.fms.service.FilmServiceImpl;

/**
 * Servlet implementation class AddActor
 */
public class AddActor extends HttpServlet 
{
	private static final long serialVersionUID = 1L;       
  
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// Declarations of List to store retrieved data from database
			
				ActorServiceImpl actorservice=new ActorServiceImpl();			
				

				// Printwriter object to display the response on webpage

				PrintWriter out=response.getWriter();
				
				// Html tags to structure the Add Actor Page
				
			//************************************************************************************************	
				out.println("<html>");
				out.println("<head><center><h1>Add Film Details</h1><hr></center>"
						+ "<link rel='stylesheet' type='text/css' href='Css/myStyle.css'>"
						+ "</head>"
						
						// Validation script included

						+"<script type='text/javascript' src='script/validate.js'></script>");	


				out.println(	"<body><center>"
								
								// Post Method is used as large secured data is passed
								
								+"<form name='Film' method='post' action='SaveActorData' onsubmit='return validateField()''>"
				
					 			+"<div>"	
					 			+ "<table cellspacing='10'>"
					 			+"<tr>"
			//************************************************************************************************
					 			+" <td>Actor First Name</td>"
					 			+"<td><input type='text' name='firstName' >"
					 			+"<div id='unameErr2' class='errMsg'></div>"
					 			+"</td>" 
					 			+"</tr>"
				
			//************************************************************************************************	
								+ "<tr>"				
								+ "<td>Actor Last Name</td>"
								+ "<td><input type='text' name='lastName'>"
								+"<div id='unameErr1' class='errMsg'></div>"
								+"</td>" 
								+"</tr>");
				
							out.println("<tr>"+
						"<td><input class='myButton' type='submit' value='Save' ></td>"+
						"<td><input class='myButton' type='reset' value='Clear'></td>"+	
						"</td>"+
						"</tr>"+
						
						"</table>"+
						"<div id='allerr' class='errMsg'></div>");			

				out.println("</table></div></form></center></body>");

				out.println("</html>");


			}
	}

		

	
