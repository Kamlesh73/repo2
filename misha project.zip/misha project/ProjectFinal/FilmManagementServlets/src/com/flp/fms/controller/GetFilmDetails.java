	package com.flp.fms.controller;
	
	/* Servlet to get all the Film Records from the Film Database*/
	
	import java.io.IOException;
	import java.io.PrintWriter;
	import java.util.ArrayList;	
	import javax.servlet.ServletException;
	import javax.servlet.http.HttpServlet;
	import javax.servlet.http.HttpServletRequest;
	import javax.servlet.http.HttpServletResponse;	
	import com.flp.fms.domain.Actor;
	import com.flp.fms.domain.Film;
	import com.flp.fms.domain.Language;
	import com.flp.fms.service.ActorServiceImpl;
	import com.flp.fms.service.FilmServiceImpl;
	
	public class GetFilmDetails extends HttpServlet 
	{
		private static final long serialVersionUID = 1L;
	
		protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
	
			FilmServiceImpl filmservice=new FilmServiceImpl ();	
			ActorServiceImpl actorservice = new ActorServiceImpl();
	
			// Bind the film details in the database into the array list
			
			ArrayList<Film> filmdetails=filmservice.getAllFilms();
	
			PrintWriter out=response.getWriter();
			
			//Structure for the html page.
		//************************************************************************************************
			out.println("<html>");
			out.println("<head><h1> Film Details </h1>"
					+ "<link rel='stylesheet' type='text/css' href='Css/myStyle.css'>"
					+ "<body><center>"
					+ "<table border='2' align='center'>"
					+ "<tr>"
					+ "<th>Film Id</th>"
					+ "<th>Title</th>"
					+ "<th>Description</th>"
					+ "<th>ReleaseYear</th>"
					+ "<th>Original Language</th>"
					+ "<th>Rental Duration</th>"
					+ "<th>Length</th>"
					+ "<th>replacement Cost</th>"
					+ "<th>Ratings</th>"
					+ "<th>SpecialFeatures</th>"
					+ "<th>Category</th>"
					+ "<th>Language List</th>"
					+ "<th>Actor List</th>"
					+ "</tr>");
			
	        // Retrive the data from list into the html page
			
			for(Film film:filmdetails)
			{
				out.println("<tr bgcolor='#F5F5F5'>");
				out.println("<td>"+film.getFilm_Id()+"</td>");
				out.println("<td>"+film.getTitle()+"</td>");
				out.println("<td>"+film.getDescription()+"</td>");
				out.println("<td>"+film.getRelease_Date()+"</td>");
				out.println("<td>"+film.getOriginalLanguage().getLanguage_Name()+"</td>");
				out.println("<td>"+film.getRental_Duration()+"</td>");
				out.println("<td>"+film.getLength()+"</td>");
				out.println("<td>"+film.getReplacement_Cost()+"</td>");
				out.println("<td>"+film.getRatings()+"</td>");
				out.println("<td>"+film.getSpecial_Features()+"</td>");
				out.println("<td>"+film.getCategory().getCategory_Name()+"</td>");
				
				//Retervie and Display the data of Other Languages from the thirdparty database table
				
	//************************************************************************************************
				ArrayList<Language> filmdlanguage=filmservice.getLanguageList(film.getFilm_Id());
				out.println("<td>");
	
				for(Language lang:filmdlanguage)
				{
	
					out.println(lang.getLanguage_Name());
				}
				out.println("</td>");

				//Retervie and Display the data of Other Actors from the thirdparty database table
				
	//************************************************************************************************
	
				ArrayList<Actor> filmactor=actorservice.getActorList(film.getFilm_Id());
				out.println("<td>");
				for(Actor actorList:filmactor)
				{
	
					out.println(actorList.getFirst_Name()+" "+actorList.getLast_Name());
				}
				out.println("</td>");				
	
				out.println("</tr>");
			}
	
			out.println("</table></center></body>");		
			out.println("</html>");	
	
		}
	
	
	}		
	
	
	
	
	
