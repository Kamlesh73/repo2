/*This class implements the methods in the IFilmService Interface*/

package com.flp.fms.service;
import java.util.ArrayList;
import com.flp.fms.dao.FilmDaoImplForDB;
import com.flp.fms.domain.Actor;
import com.flp.fms.domain.Category;
import com.flp.fms.domain.Film;
import com.flp.fms.domain.Language;

public class FilmServiceImpl

{
    // Create object of filmdao 
	//****************************************************************************
	
	FilmDaoImplForDB filmdao = new FilmDaoImplForDB();
	
	// Save film to insert data into the database
	//****************************************************************************
	
	public int saveFilm(Film film)
	{
		
		return filmdao.saveFilm(film);
		
	}
	
	//Service to getAll languages from the database
	//****************************************************************************
	
	public ArrayList<Language> getAllLanguage()
	{
		
		return filmdao.getAllLanguage();
	}
	//Service to getAll Category from the database
	//****************************************************************************
	public ArrayList<Category> getAllCategory()
	{
		
		return filmdao.getAllCategory();
	}
	
	//Service to getAll Languages from the database with specific film id
	//****************************************************************************
	public ArrayList<Language> getLanguage(int fid)
	{
		
		return filmdao.getLanguage(fid);
		 
	}
	// Service to get all FilmId
	//****************************************************************************
	
	public ArrayList<Film> getAllFilmId()
	{
		
		return filmdao.getAllFilmId();
	}
	// Service to get all Films
	//****************************************************************************
	
	public ArrayList<Film> getAllFilms() 
	{
		
		return filmdao.getAllFilms();
	}
	// Service to get all Language
	//****************************************************************************
	public ArrayList<Language> getLanguageList(int fid)
	{
		
		return filmdao.getLanguageList(fid);
	}
	// Service to searchAll Film
	//****************************************************************************
	public ArrayList<Film> searchAllFilm(Film film,String categoryValue,String language,String Actor)
	{		
		
		return filmdao.searchAllFilm(film, categoryValue, language, Actor);
	}
	// Service to delete filmbased on  FilmId search
	//****************************************************************************
	
	public boolean deleteFilm(int filmId)
	{
		
		return filmdao.deleteFilm(filmId);
	}
	// Service to update film details
	//****************************************************************************
	public void updateFilm(Film film, Language language_Selected, Category catgeory_Selected)
	{
		
		 filmdao.updateFilm(film, language_Selected, catgeory_Selected);
	}
	// Service to search all film details
	//****************************************************************************
	public ArrayList<Film> searchFilm(Film film)
	{
		return filmdao.searchFilm(film);
		
	}
	
}
