/* This interface contains the methods that is implemented in FilmDaoImplForDB.java*/
package com.flp.fms.dao;
import java.util.ArrayList;
import com.flp.fms.domain.Actor;
import com.flp.fms.domain.Category;
import com.flp.fms.domain.Film;
import com.flp.fms.domain.Language;

// This Interface has varios method implemented in the FilmDaoImplForDB class

public interface IFilmDao 

{
	public int saveFilm(Film film);	
	public ArrayList<Language> getAllLanguage();
	public ArrayList<Category> getAllCategory();
	public ArrayList<Language> getLanguage(int fid);
	public ArrayList<Actor> getActor(int fid);
	public ArrayList<Actor> getAllActor();
	public ArrayList<Film> getAllFilmId();
	public ArrayList<Language> getLanguageList(int fid);
	public ArrayList<Actor> getActorList(int fid); 
	public ArrayList<Film> searchAllFilm(Film film,String categoryValue,String language,String Actor);
	public boolean deleteFilm(int filmId);
	public void updateFilm(Film film, Language language_Selected, Category catgeory_Selected);
	public ArrayList<Film> searchFilm(Film film);
	// Methods for Actor Implementation
	public int saveActor(Actor actor);
	public ArrayList<Actor> getAllActors(); 
	public boolean deleteActor(int actorId);
	
}
