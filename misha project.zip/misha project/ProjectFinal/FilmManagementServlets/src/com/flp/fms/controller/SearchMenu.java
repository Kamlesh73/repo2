	/**
	 Servlet implementation class SearchMenu 
	 This servlet displays the various search options
	 The search is initiated from this Servlet
	 */

    package com.flp.fms.controller;	
	import java.io.IOException;
	import java.io.PrintWriter;
	import java.util.ArrayList;	
	import javax.servlet.ServletException;
	import javax.servlet.http.HttpServlet;
	import javax.servlet.http.HttpServletRequest;
	import javax.servlet.http.HttpServletResponse;	
	import com.flp.fms.domain.Actor;
	import com.flp.fms.domain.Category;
	import com.flp.fms.domain.Film;
	import com.flp.fms.domain.Language;
	import com.flp.fms.service.ActorServiceImpl;
	import com.flp.fms.service.FilmServiceImpl;
	
	
	public class SearchMenu extends HttpServlet 
	{
		private static final long serialVersionUID = 1L;
	
		FilmServiceImpl filmservice = new FilmServiceImpl();
		ActorServiceImpl actorservice = new ActorServiceImpl();
	
	
		protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
			
			// Bind the reterived data from database into the List
			
			ArrayList<Film> filmList=filmservice.getAllFilmId();
			ArrayList<Actor> actorList=actorservice.getAllActor();
			ArrayList<Language>languageList=filmservice.getAllLanguage();
			ArrayList<Category>categoryList=filmservice.getAllCategory();
	
			PrintWriter out=response.getWriter();
			
			//Structure The Search Menu in html
	
//*****************************************************************************************************
			out.println("<html>");
			out.println("<head><title>Search Film Details</title>"
					+ "<script type='text/javascript' src='script/validate.js'></script>"
					+ "<link rel='stylesheet' type='text/css' href='Css/myStyle.css'>"
	
	
					+"<link href='http://code.jquery.com/ui/1.10.4/themes/ui-lightness/jquery-ui.css' rel='stylesheet'>"
					+"<script src='http://code.jquery.com/jquery-1.10.2.js'></script>"
					+"<script src='http://code.jquery.com/ui/1.10.4/jquery-ui.js'></script>"
					
					// Date Picker script
					
					+"<!-- Javascript -->"
					+" <script>"
					+" $(function() {"
					+" $( '#datepicker1' ).datepicker({"
					+"dateFormat:'dd-M-yy'"
					+"});"
					+" $( '#datepicker1' ).datepicker('show');"
					+"$( '#datepicker1' ).datepicker('setDate',new Date());"
					+"});"
	
					+"</script>"	
					+ "</head>"
					+ "<body><form name='f1'>"
					+ "<div>"
					+"<table cellspacing='20'>"
					+"<tr>"
					
					// Film Id
			//*****************************************************************************************************
					+ "<td><label>Choose Film  Id</label></td>"
					+ "<td><select name='filmId'>"
					+ "<option selected='true'>Select FilmId</option>");
	
			for(Film film:filmList)
			{
				out.println("<option value='"+ film.getFilm_Id()+"'>" + film.getFilm_Id() +"</option>");
			}
			out.println("</select></td>"
					
			// Title
			//*****************************************************************************************************
					
	
					+ "<td><label>Title:</label></td>"
					+ "<td><input type='text' name='filmTitle' size='20'></td>"
					
			// Rating
			//*****************************************************************************************************
	
					+ "<td><label>Rating:</label></td>"
	
					+"<td><select name='rating'>"
					+ "<option selected='true'>Select Rating</option>"
					+"<option value='1'>1</option>"
					+"<option value='2'>2</option>"
					+"<option value='3'>3</option>"
					+"<option value='4'>4</option>"
					+"<option value='5'>5</option>"
					+"</select></td>"
					
			// Category
			//*****************************************************************************************************
	
					+ "<tr><td><label>Category:</label></td>"
					+"<td><select name='category'>"
					+ "<option selected='true'>Select Category</option>");
	
	
	
					for(Category catgeory:categoryList)
					{
	
						out.println("<option  value="+catgeory.getCategory_Name()+">"+catgeory.getCategory_Name()+"</option>");
	
	
					}
					
			// Language
			//*****************************************************************************************************
	
			out.println("</select></td>");
	
			// Language
			out.println( "<td><label>Language:</label></td>"	
							+"<td><select name='Language'>"
							+ "<option selected='true'>Select Language</option>");	
			for(Language language:languageList)
			{	
				out.println("<option  value="+language.getLanguage_Name()+">"+language.getLanguage_Name()+"</option>");	
	
			}
			out.println("</select></td>");
			
			// Actor List
		//*****************************************************************************************************
	
			
			out.println( "<td><label>Actor:</label></td>"	
								+"<td><select name='Actor'>"
								+ "<option selected='true'>Select Actor</option>");
			for(Actor actorlist:actorList)
			{
	
				out.println("<option  value="+actorlist.getFirst_Name()+actorlist.getLast_Name()+">"+actorlist.getFirst_Name()+actorlist.getLast_Name()+"</option>");	
	
			}
			// Release Date
	//*****************************************************************************************************
			out.println("</select></td></tr>"
					+ "<tr><td><label>Release Date:</label><td>"
					+ "<td><input type='text' name='releaseDate' size='20' id='datepicker1'></td>"
					+ "</tr></table><hr>");
			// Search Button
  //*****************************************************************************************************
	
	
			out.println("<center><input type='button' class='myButton' name='Search' value='Search' onClick='displayFilm()'></center>"
					+ "</div>"
					+ "<div id='displayFilm'> "		
					+ "</div>"
					+ "</form></body>");		
			out.println("</html>");	
		}
	}
	
	
