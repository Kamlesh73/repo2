package com.flp.fms.JUnit;
import static org.junit.Assert.*;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import org.junit.Test;
import com.flp.fms.domain.Film;
import com.flp.fms.service.*;

 

/* 1. Test to check if the parameters are NULL
 * 2. Test when only film object passed and other parameters Null
 * 3. Test when all fields except Id is given
 * */

public class SearchTest 
{
	FilmServiceImpl filmservice=new FilmServiceImpl();
	
	@Test
	public void whenAllfieldsNull() 
	{
		assertNotEquals(filmservice.searchAllFilm(null, null, null, null),null);
	}
	
	//************************************************************************************
	
	@Test
	public void whenFilmObjectNotNull() 
	{
		ArrayList<Film> filmlist=filmservice.getAllFilms();
		
		Film film = new Film();
		film.setTitle("Titanic");
		film.setFilm_Id(52);
		film.setRatings(1);

		String strDate = "1950-01-01";
		DateFormat formatter = new SimpleDateFormat("yyyy-mm-dd");
		java.util.Date date = null;
		try {
			date = formatter.parse(strDate);
		    } catch (ParseException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		java.sql.Date sqlDate = new java.sql.Date(date.getTime());
		film.setRelease_Date(sqlDate);
		
		assertNotEquals(filmservice.searchAllFilm(film, null, null, null),filmlist);
	}
	
	//************************************************************************************
	
	
	@Test
	public void whenFilmObjectField() 
	{
		ArrayList<Film> filmlist=filmservice.getAllFilms();
		
		Film film = new Film();		
		film.setFilm_Id(52);		
		
		assertNotEquals(filmservice.searchAllFilm(film, null, null, null),filmlist);
	}
	
	//************************************************************************************
	

}
