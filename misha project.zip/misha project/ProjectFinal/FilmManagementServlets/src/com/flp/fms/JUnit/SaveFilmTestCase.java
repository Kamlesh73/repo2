package com.flp.fms.JUnit;
import static org.junit.Assert.*;

import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import org.junit.Test;
import com.flp.fms.domain.*;
import com.flp.fms.service.FilmServiceImpl;

/*1. Test Case when all fields are NotNull
 * 2. Test Case if one field is not Null
 * 3. All Fields Null*/

public class SaveFilmTestCase {
	
	FilmServiceImpl filmservice=new FilmServiceImpl();

	@Test
	public void allFieldsNotNull() 
	{
		Film film = new Film();
		Category category = new Category();
		Language language = new Language();
		Actor actor = new Actor();
		
		
		film.setTitle("FairyTales");
		film.setDescription("GoodMovie");		
		film.setLength(50);
		film.setRatings(5);	
		
		String strDate = "1950-01-01";
		DateFormat formatter = new SimpleDateFormat("yyyy-mm-dd");
		java.util.Date date = null;
		try {
			date = formatter.parse(strDate);
		    } catch (ParseException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		java.sql.Date sqlDate = new java.sql.Date(date.getTime());
		
		film.setRelease_Date(sqlDate);
		
		String strDate1 = "1950-02-02";
		DateFormat formatter1 = new SimpleDateFormat("yyyy-mm-dd");
		java.util.Date date1 = null;
		try {
			date = formatter.parse(strDate);
		    } catch (ParseException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		java.sql.Date sqlDate1= new java.sql.Date(date.getTime());
		
	
		film.setRental_Duration(sqlDate1);		
		category.setCategory_Id(1);
		film.setCategory(category);		
		language.setLanguage_Id(2);
		film.setOriginalLanguage(language);
		
		ArrayList<Language> langList = new ArrayList();
		language.setLanguage_Id(4);	
		langList.add(language);
		film.setLanguages(langList);
		
		
		ArrayList<Actor> actorList = new ArrayList();
		actor.setActor_Id(2);
		actorList.add(actor);
		film.setActors(actorList);		
		assertEquals(filmservice.saveFilm(film),1);
		//assertNotEquals(filmservice.saveFilm(film),filmlist);
		
		
	}
	
	
	//*****************************************************************************************
	@Test
	public void ontFieldsNull() 
	{
		Film film = new Film();
		Category category = new Category();
		Language language = new Language();
		Actor actor = new Actor();
		
		film.setTitle(null);
		film.setDescription("GoodMovie");		
		film.setLength(50);
		film.setRatings(5);	
		
		String strDate = "1950-01-01";
		DateFormat formatter = new SimpleDateFormat("yyyy-mm-dd");
		java.util.Date date = null;
		try {
			date = formatter.parse(strDate);
		    } catch (ParseException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		java.sql.Date sqlDate = new java.sql.Date(date.getTime());
		
		film.setRelease_Date(sqlDate);
		
		String strDate1 = "1950-02-02";
		DateFormat formatter1 = new SimpleDateFormat("yyyy-mm-dd");
		java.util.Date date1 = null;
		try {
			date = formatter.parse(strDate);
		    } catch (ParseException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		java.sql.Date sqlDate1= new java.sql.Date(date.getTime());
		
	
		film.setRental_Duration(sqlDate1);		
		category.setCategory_Id(1);
		film.setCategory(category);		
		language.setLanguage_Id(2);
		film.setOriginalLanguage(language);
		
		ArrayList<Language> langList = new ArrayList();
		language.setLanguage_Id(4);	
		langList.add(language);
		film.setLanguages(langList);
		
		
		ArrayList<Actor> actorList = new ArrayList();
		actor.setActor_Id(2);
		actorList.add(actor);
		film.setActors(actorList);
		
		assertEquals(filmservice.saveFilm(film),0);
		
	}
//**********************************************************************************************
	@Test
	public void WhenFilmObjectIsNull()
	{

		assertNotEquals(filmservice.saveFilm(null),0);
	}
	

}
