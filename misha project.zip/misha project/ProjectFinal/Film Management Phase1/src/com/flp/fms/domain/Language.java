/* Pojo Class for the Language Object*/


package com.flp.fms.domain;

   public class Language
   	{
	
	   //private fields
	
		int language_Id;
		String language_Name;
			
		// Default Constructor
			
		public Language()
		{}
			
		// Parametrized Constructor
			
		public Language(int language_Id, String language_Name )
		{				
			this.language_Id=language_Id;
			this.language_Name=language_Name;
				
		}
			
		// Getters and Setters

		public int getLanguage_Id() 
		 {
			return language_Id;
		 }

		public void setLanguage_Id(int language_Id) 
		{
			this.language_Id = language_Id;
		}

		public String getLanguage_Name() 
		{
			return language_Name;
		}

		public void setLanguage_Name(String language_Name) 
		{
			this.language_Name = language_Name;
		}
			
		// To String 
			

		@Override
		public String toString() 
		 {
			  return "Language [language_Id=" + language_Id + ", language_Name=" + language_Name + "]";
		 }
			
			
			
		
   }
