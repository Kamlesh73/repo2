package com.flp.fms.service;
import java.util.*;
import com.flp.fms.domain.*;

/* The film Service Interface contains the Methods which are implemented in DAO */

public interface IFilmService 
{
	public List<Language> getLanguages();
	public List<Category> getCategory();
	public void addFilm(Film film);
	public Map<Integer, Film> getAllFilms();
	public void searchby_Id(Collection<Film> lst1);
	public void searchby_Name(Collection<Film> lst);
	public void searchby_Rating(Collection<Film> lst);	
	public void removeby_Name(String filmName);
	public void update(Film film,int filmId);
	public void removeby_Id(int filmId);
	public void removeby_Rating(int rating);
}