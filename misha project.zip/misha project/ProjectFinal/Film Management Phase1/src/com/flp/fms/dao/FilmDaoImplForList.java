
/* This Class Interacts with the repository to perform various CRUD Operations */

package com.flp.fms.dao;
import java.util.*;
import com.flp.fms.domain.*;

public class FilmDaoImplForList implements IFilmDao {
	
	Film film = new Film();
	Film film1 = new Film();
	
	// Film Repository that stores the Film Objects
	
	private Map<Integer, Film> film_Repository=new HashMap<>();
	
//******************************************************************************************	
	// Add Languages into the Language
	
	public List<Language> getLanguages() 
	{
		List<Language> languages=new ArrayList<>();
		languages.add(new Language(1, "English"));
		languages.add(new Language(2, "Hindi"));
		languages.add(new Language(3, "Telegu"));
		languages.add(new Language(4, "Marati"));
		languages.add(new Language(5, "Kananta"));
		languages.add(new Language(6, "Tamil"));
		languages.add(new Language(7, "Malayalam"));		
		return languages;
	}
	
	//CURD Operation
	
//******************************************************************************************	
	// Method to add film object into the Repository	
	
		public void addFilm(Film film) 
		{
			film_Repository.put(film.getFilm_Id(), film);
			
		}

//******************************************************************************************
		// Method to getAll  film object into the Repository
		
		public Map<Integer, Film> getAllFilms()
		{
			
			return film_Repository;
		}
//******************************************************************************************
		// Method to Search the Film by Id
		
		public void searchby_Id(Collection<Film> lst)
		{
				int flag = 0;
				
				System.out.println("Please Enter Film Id you want to Search");
				Scanner sc = new Scanner(System.in);
				int f_id=sc.nextInt();
				
				
			for(Film film:lst)
			{				
				
				if(f_id==film.getFilm_Id())
				{
					System.out.println("Element  Found");
					System.out.println(film);
					
				}				
				

			}
			
	}
//******************************************************************************************					
		// Method to search the film By Name 
		
		public void searchby_Name(Collection<Film> lst)
		{
				int flag = 0;
				
				System.out.println("Please Enter Film Name you want to Search");
				Scanner sc = new Scanner(System.in);
				String fname=sc.next();
				
				
			for(Film film:lst)
			{
				
				
				if(fname.equals(film.getTitle()))
				{
					System.out.println("Element  Found");
					System.out.println(film);
					
				}				
				

			}
		}
//******************************************************************************************
		// Method to search the film by Rating parameter
		
		public void searchby_Rating(Collection<Film> filmList)
		{
				int flag = 0;
				
				System.out.println("Please Enter Film Rating that you want to Search");
				Scanner sc = new Scanner(System.in);
				int rate=sc.nextInt();
				
				
			for(Film film: filmList)
			{
				
				
				if(rate==film.getRatings())
				{
					System.out.println("Element  Found");
					System.out.println(film);
					
				}
					
				

			}
		}
			
	//******************************************************************************************
		// Method to delete the film searching by FilmId parameter
			
			public void removeby_Id(int filmId)
			{
					
				film_Repository.remove(filmId);
				System.out.println("Film Deleted Successfully");
				
				  
			}
	//******************************************************************************************		
			
		// Method to Delete Film searching by Rating Parameter
			
			public void removeby_Rating(int rating)
			{
				Collection<Film> allFilms = film_Repository.values();
				Iterator<Film> itr = allFilms.iterator();
				
				int filmId=0;
				
				while(itr.hasNext())
				{
					
					Film film = itr.next();
					
					if(film.getRatings()==rating)
					{
						
						filmId = film.getFilm_Id();
						break;
					}
				}	
				film_Repository.remove(filmId);
				System.out.println("Film Deleted Successfully!");
				
			}
		//*************************************************************************************	
			
			// Remove the data from the list search on Name parameter
			
				public void removeby_Name(String filmName)
				{					
						
						
					Collection<Film> allFilms = film_Repository.values();
					Iterator<Film> itr = allFilms.iterator();
					
					int filmId=0;
					
					while(itr.hasNext())
					{
						
						Film film = itr.next();
						
						if(film.getTitle().equals(filmName))
						{
							
							filmId = film.getFilm_Id();
							break;
						}
					}	
					film_Repository.remove(filmId);
					System.out.println("Film Deleted Successfully!");
					
					  
				}
				
	//******************************************************************************************
		// Method to Update the Film Object in the Repository.       
    
         public void updateFilm(Film film)
         {
        	 film_Repository.put(film.getFilm_Id(), film);
         }


		
}
