
package com.flp.fms.dao;
import java.util.ArrayList;
import java.util.List;

import com.flp.fms.domain.Category;

public class CategoryDaoImplForList {
	
	//Method to Add the Category items into the List
	
	public List<Category> getCategory() 
	{
		List<Category> category=new ArrayList<>();
		category.add(new Category(1,"Comedy"));
		category.add(new Category(2,"Romantic"));
		category.add(new Category(3,"Horror"));
		category.add(new Category(4,"Animation"));
		category.add(new Category(5,"Thriller"));
		category.add(new Category(6,"Adventure"));
		category.add(new Category(7,"History"));
		return category;
	}

}
