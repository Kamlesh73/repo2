package com.flp.fms.dao;

import java.util.List;
import com.flp.fms.domain.Category;

//Include the getCategory Method which will get Category List from List

public interface ICategoryDao 
{
	
	public List<Category> getCategory();

}
