
/* Film Service class Implements all the methods in FilmService Interface*/

package com.flp.fms.service;			
import java.util.Collection;
import java.util.List;
import java.util.Map;
import java.util.Scanner;
import java.util.Set;			
import com.flp.fms.domain.Category;
import com.flp.fms.domain.Language;
import com.flp.fms.domain.Film;
import com.flp.fms.dao.FilmDaoImplForList;
import com.flp.fms.dao.ICategoryDao;
import com.flp.fms.dao.CategoryDaoImplForList;
import com.flp.fms.dao.IFilmDao;

public class FilmServiceImpl implements IFilmService
{

	// Instance created

	private IFilmDao filmDao=new FilmDaoImplForList();
	private CategoryDaoImplForList IcatDao=new CategoryDaoImplForList();
	
	//***************************************************************************************************************
	// Get All the Language list

	public List<Language> getLanguages() 
	{

		return filmDao.getLanguages();			
	}
	//***************************************************************************************************************				

	// Get All the Category list


	public List<Category> getCategory()

	{		

		return IcatDao.getCategory();			
	}
	//***************************************************************************************************************			

	// Generate the filmId and add the film details into the  DAO layer repository.

	public void addFilm(Film film) 
	{

		film.setFilm_Id(generate_Film_Id());
		filmDao.addFilm(film);		
	}
	//***************************************************************************************************************			

	// Method to Generate the Random Film_Id

	public int generate_Film_Id(){

		int filmId=0;

		//Verify filmId has been Duplicated or not
		do{
			double fid=Math.random()*1000;
			filmId=(int)fid;
		}while(checkDuplicateFilmId(filmId));


		return filmId;
	}
	//***************************************************************************************************************

	// Method to call DAO layer getAllFilms 

	public Map<Integer, Film> getAllFilms() 
	{

		return filmDao.getAllFilms();
	}

	//***************************************************************************************************************
	//Method to check if the generated Id is a Duplicate FilmId

	public boolean checkDuplicateFilmId(int filmId){

		Set<Integer> keys= getAllFilms().keySet();
		boolean flag=false;
		if(keys.isEmpty() || keys==null){
			flag= false;
		}else{
			for(Integer key:keys){
				if(key==filmId){
					flag=true;
					break;
				}
			}
		}

		return flag;

	}


	//***************************************************************************************************************		
	// Method to search film by FilmId

	public void searchby_Id(Collection<Film> lst)
	{

		filmDao.searchby_Id(lst);

	}


	//***************************************************************************************************************		
	// Method to Search By Name

	public void searchby_Name(Collection<Film> lst)
	{
		filmDao.searchby_Name(lst);
	}


	//***************************************************************************************************************
	// Method to search By Rating

	public void searchby_Rating(Collection<Film> lst)
	{
		filmDao.searchby_Rating(lst);
	}
	//***************************************************************************************************************
	// Remove the data from the list

	public void removeby_Id(int filmId)
	{

		filmDao.removeby_Id(filmId);
	}

	//***************************************************************************************************************
	// Remove the data from the list by Rating

	public void removeby_Rating(int rating)
	{
		filmDao.removeby_Rating(rating);
	}
	//***************************************************************************************************************	

	// Remove the data from the list

	public void removeby_Name(String filmName)
	{

		filmDao.removeby_Name(filmName);

	}

	//***************************************************************************************************************
	// Update the film data from the list

	public void update(Film film,int filmId)
	{

		film.setFilm_Id(filmId);
		filmDao.addFilm(film);
	}

	



}

