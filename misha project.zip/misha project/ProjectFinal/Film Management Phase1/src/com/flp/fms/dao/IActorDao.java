package com.flp.fms.dao;
import java.util.Set;
import com.flp.fms.domain.Actor;

// Include the getActor Method which will get Actor List from List

public interface IActorDao 
{
	
	public Set<Actor> getActor();

}
