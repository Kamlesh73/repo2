package com.flp.fms.dao;
import java.util.*;
import com.flp.fms.domain.*;


// This interface contains Method definations that is implemented in the FilmDao Class

public interface IFilmDao 
{


	public List<Language> getLanguages();
	public void addFilm(Film film); // Add Film 
	public Map<Integer, Film> getAllFilms();// Display Film
	public void searchby_Id(Collection<Film> lst);
	public void searchby_Name(Collection<Film> lst);
	public void searchby_Rating(Collection<Film> lst);	
	public void removeby_Rating(int rating);
	public void removeby_Name(String filmName);
	public void updateFilm(Film film);
	public void removeby_Id(int filmId);


}
