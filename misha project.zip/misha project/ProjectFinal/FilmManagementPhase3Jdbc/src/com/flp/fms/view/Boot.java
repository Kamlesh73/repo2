/* Boot Class starts the execution of the Project and interacts with the DAO Layer*/

package com.flp.fms.view;
import java.util.ArrayList;
import java.util.Scanner;
import com.flp.fms.domain.Film;
import com.flp.fms.domain.*;
import com.flp.fms.domain.Language;
import com.flp.fms.service.ActorServiceImpl;
import com.flp.fms.service.FilmServiceImpl;
import com.flp.fms.service.IFilmService;



public class Boot {
	
	//FilmServiceImpl filmService=new FilmServiceImpl();
	
	public static void main(String[] args) 
	{
		   FilmServiceImpl filmService=new FilmServiceImpl();
			int choice;
			int choiceSearch,choiceDelete;
			UserInteraction U = new UserInteraction();			
			ActorServiceImpl actorServices=new ActorServiceImpl();
			
			
			do{
				selection();
				System.out.println("Enter your choice:");
				Scanner sc = new Scanner(System.in);
				choice = sc.nextInt();

			switch(choice)
			 {
			   // Case 1 is to Add the new film data into the database.
				case 1:
					
					Film film = U.addFilm(filmService.getAllLanguage(),filmService.getAllCategory(),actorServices.getAllActor());  
				    
				    System.out.println(film);
				    filmService.saveFilm(film);
				    System.out.println("Creation Successful!!");
					break;
					
					// Case 2 will update the updated data in the database after validation
					
				case 2:	
					System.out.println("Enter the Film ID of the film to be updates:");
					int filmId = sc.nextInt();
					Film updateFilm = U.addFilm(filmService.getAllLanguage(),filmService.getAllCategory(),actorServices.getAllActor());
					updateFilm.setFilm_Id(filmId);
					filmService.updateFilm(updateFilm);
					System.out.println("Updation Successful!!");
					break;
					
					// Case 3 will delete the mentioned film data from the database 
				case 3:
					do{
						remove_Selection();
						 System.out.println("Enter your choice for Deletion:");						
						 choiceDelete = sc.nextInt();
						 Film filmSearch = new Film();
						 switch(choiceDelete)
						 {
						  // Delete by Film_Id.
						  case 1:
							    System.out.println("Enter the Film ID of the film to be deleted:");
								int dfilmId = sc.nextInt();
								Film deleteFilm = new Film();
								deleteFilm.setFilm_Id(dfilmId);
								boolean flag = filmService.deleteFilm(deleteFilm.getFilm_Id());
								if(flag==true)
									System.out.println("Deletion Successful!!");					
								break;
							// Delete by Title 
						  case 2:
							    System.out.println("Enter the Title of the film to be deleted:");
								String dfilmTitle = sc.next();							
								boolean flag1 = filmService.deleteFilm(dfilmTitle);
								if(flag1==true)
									System.out.println("Deletion based on Title  Successful!!");					
								break;
						  case 3:
							  	System.out.println("Enter the Rating of the film to be deleted:");
								Film filmrate = new Film();
								filmrate.setRatings(sc.nextInt());
								boolean flag2 = filmService.deleteFilm(filmrate);
								if(flag2==true)
									System.out.println("Deletion based on Rate  Successful!!");					
								break; 
						  case 4:
							    break;					 
						 
						 }
						
						
					  }while(choiceDelete!=4);
					 break;
					
					// Case 4 is to perform search on various parameters
				case 4:
					do{
						search_Selection();
						 System.out.println("Enter your search choice:");						
						 choiceSearch = sc.nextInt();
						 Film filmSearch = new Film();
						 String categoryValue, language;
						 int Actor;
						 switch(choiceSearch)
						 {
						 // Search Film_id	
						 case 1:
						 		 System.out.println("Enter the FilmId to be searched:");
						 		 int searchfilmId = sc.nextInt();
						 		 filmSearch.setFilm_Id(searchfilmId);						 		 
						 		 filmSearch.setTitle(null);
						 		 filmSearch.setRatings(0);
						 		 filmSearch.setOriginalLanguage(null);
						 		 categoryValue=null;
						 		 language=null;
						 		 Actor=0;
						 		 ArrayList<Film> filmlist=filmService.searchAllFilm(filmSearch, categoryValue, language, Actor);
						 		 if(filmlist.isEmpty())
						 			 System.out.println("Sorry No Record Found in the Database ");
						 		 else
						 		// Display the details of all the Films in the database.
						 		 display(filmlist);	
							break;
							
							// Search Film by Film Title	
						 	case 2:
						 		 System.out.println("Enter the Film Title to be searched:");
						 		 String searchTitle = sc.next();
						 		 filmSearch.setFilm_Id(0);						 		 
						 		 filmSearch.setTitle(searchTitle);
						 		 filmSearch.setRatings(0);
						 		 filmSearch.setOriginalLanguage(null);
						 		 categoryValue=null;
						 		 language=null;
						 		 Actor=0;
						 		 ArrayList<Film> filmTitle=filmService.searchAllFilm(filmSearch, categoryValue, language, Actor);
						 		if(filmTitle.isEmpty())
						 			 System.out.println("Sorry No Record Found in the Database ");
						 		 else
						 		// Display the details of all the Films in the database.
						 		 display(filmTitle);					 		
						 		break;
						 		
						 		// Search Film by Ratings
						 	case 3:
						 		 System.out.println("Enter the Film Ratings(1-5) to be searched:");
						 		 int searchRate = sc.nextInt();
						 		 filmSearch.setFilm_Id(0);						 		 
						 		 filmSearch.setTitle(null);
						 		 filmSearch.setRatings(searchRate);
						 		 filmSearch.setOriginalLanguage(null);
						 		 categoryValue=null;
						 		 language=null;
						 		 Actor=0;
						 		 ArrayList<Film> filmRate=filmService.searchAllFilm(filmSearch, categoryValue, language, Actor);
						 		if(filmRate.isEmpty())
						 			 System.out.println("Sorry No Record Found in the Database ");
						 		 else
						 		// Display the details of all the Films in the database.
						 		 display(filmRate);				 		
						 		
						 		break;
						 		// Search the film by Language
						 	case 4:	
						 		 ArrayList<Language> languageList = filmService.getAllLanguage();
						 		 System.out.println("---------------------------");
						 		 System.out.println("|        Language          |");
						 		 System.out.println("---------------------------");
						 		 for(Language languagelist:languageList)
						 		 {
						 			 
						 			 System.out.println(languagelist.getLanguage_Name());
						 			 
						 		 }
						 		 System.out.println("---------------------------");
						 		 //displayList(languageList);
						 		 System.out.println("Enter the Film  to be searched based on Language:");
						 		 String searchLanguage = sc.next();
						 		 filmSearch.setFilm_Id(0);						 		 
						 		 filmSearch.setTitle(null);
						 		 filmSearch.setRatings(0);
						 		 filmSearch.setOriginalLanguage(null);
						 		 categoryValue=null;
						 		 language=searchLanguage;
						 		 Actor=0;
						 		 ArrayList<Film> filmLanguage=filmService.searchAllFilm(filmSearch, categoryValue, language, Actor);
						 		if(filmLanguage.isEmpty())
						 			 System.out.println("Sorry No Record Found in the Database ");
						 		 else
						 		// Display the details of all the Films in the database.
						 		 display(filmLanguage);				 		
						 		
						 		break;
						 		// Search film by Actor Names 
						 	case 5:
						 		 ArrayList<Actor> actorList = actorServices.getAllActor();
						 		 System.out.println("---------------------------");
						 		 System.out.println("|        Actors           |");
						 		 System.out.println("---------------------------");
						 		 for(Actor actorlist:actorList)
						 		 {
						 			 
						 			 System.out.println(actorlist.getActor_Id()+" "+actorlist.getFirst_Name()+" "+actorlist.getLast_Name());
						 			 
						 		 }
						 		 System.out.println("---------------------------");
						 		 System.out.println("Enter the Film  to be searched based on Actor:");
						 		 int searchActor = sc.nextInt();
						 		 filmSearch.setFilm_Id(0);						 		 
						 		 filmSearch.setTitle(null);
						 		 filmSearch.setRatings(0);
						 		 filmSearch.setOriginalLanguage(null);
						 		 categoryValue=null;
						 		 language=null;
						 		 Actor=searchActor;
						 		 ArrayList<Film> filmActor=filmService.searchAllFilm(filmSearch, categoryValue, language, Actor);
						 		if(filmActor.isEmpty())
						 			 System.out.println("Sorry No Record Found in the Database ");
						 		 else
						 		// Display the details of all the Films in the database.
						 		 display(filmActor);		
						 		break;
						 	 case 6:
						 		    break;
						 			
						 }
					  }while(choiceSearch!=6);

					
					

					break;
				case 5:
					// Display the details of all the Films in the database.
					ArrayList<Film> filmDetails = filmService.getAllFilms();
					System.out.println("-----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------");
					System.out.println("|Film ID\t|Title\t\t\t|Length\t|Rental Duration\t|Rate\t|Category\t\t|Original Language\t\t|Release Date\t\t|Languages\t\t|Actors List\t\t\t|");
					System.out.println("-----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------");
					
					for(Film filmList:filmDetails)
					{
						
						System.out.print(  "|"+ filmList.getFilm_Id()  +"\t\t|"+filmList.getTitle()+"\t\t\t|"+filmList.getLength()+"\t|"+filmList.getRental_Duration()+"\t\t|"+filmList.getRatings()+"\t|"+filmList.getCategory().getCategory_Name()+"\t\t\t|"+filmList.getOriginalLanguage().getLanguage_Name()+"\t\t\t|"+filmList.getRelease_Date()+"\t\t|");
						ArrayList<Language> filmdlanguage=filmService.getLanguageList(filmList.getFilm_Id());
						
						
						for(Language lang:filmdlanguage)
						{
						
							System.out.println(lang.getLanguage_Name()+"\t\t|");
						}
						System.out.println("------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------");

						
					}	
					
					break;
					
				case 6:
					System.exit(0);


				}
			}while(choice!=6);
		}
	//*****************************************************************************************************
		// Static Method to display the Film Menu

		public static void selection()
		{
			
			System.out.println("------------------------------------------------------");
			System.out.println("| \t                |MENU|    \t             |");
			System.out.println("------------------------------------------------------");
			
			System.out.println("| 	   \t 1. AddFilm 	  		     |");
			System.out.println("|	   \t 2. UpdateFilm   		     |");
			System.out.println("|	   \t 3. RemoveFilm   		     |");
			System.out.println("|	   \t 4. SearchFilm   		     |");
			System.out.println("|	   \t 5. GetAllFilm   		     |");
			System.out.println("|	   \t 6. Exit   		     	 |");
			System.out.println("-----------------------------------------------------");		


		}

		//Static Method to display the SubSelection for the search option 

		//*****************************************************************************************************

		public static void search_Selection()
		{

			System.out.println("------------------------------------------------------");
			System.out.println("| \t            |SEARCH SUB MENU|    \t             |");
			System.out.println("------------------------------------------------------");
			
			System.out.println("| 	   \t 1. Search By FilmId 	  		       |");
			System.out.println("|	   \t 2. Search By Film Title   		   |");
			System.out.println("|	   \t 3. Search By Rating   		       |");
			//System.out.println("|	   \t 4. SearchF By Title   		       |");
			System.out.println("|	   \t 4. Search By Language   		       |");
			System.out.println("|	   \t 5. Search By Actor   		           |");
			System.out.println("|	   \t 6. Exit Search Menu    		       |");
			System.out.println("-----------------------------------------------------");		


		}
		//*****************************************************************************************************
		//Static Method to display the SubSelection for the remove option



		public static void remove_Selection()
		{

			System.out.println("------------------------------------------------------");
			System.out.println("| \t             |DELETE SUB MENU|    \t             |");
			System.out.println("------------------------------------------------------");
			
			System.out.println("| 	   \t 1. Delete By FilmId 	  		       |");
			System.out.println("|	   \t 2. Delete By Film Title   		   |");
			System.out.println("|	   \t 3. Delete By Rating   		       |");			
			System.out.println("|	   \t 4. Exit Remove Menu    		       |");
			System.out.println("-----------------------------------------------------");		


		}
		//*****************************************************************************************************
		//Static Method to display the list of films
		
		public static void display(ArrayList<Film> filmlist)
		{
			FilmServiceImpl filmService=new FilmServiceImpl();
			System.out.println("-----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------");
			System.out.println("|Film ID\t|Title\t\t\t|Length\t|Rental Duration\t|Rate\t|Category\t\t|Original Language\t\t|Release Date\t\t|Languages\t\t|Actors List\t\t\t|");
			System.out.println("-----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------");
			
			for(Film filmList:filmlist)
			{
				
				System.out.print(  "|"+ filmList.getFilm_Id()  +"\t\t|"+filmList.getTitle()+"\t\t\t|"+filmList.getLength()+"\t|"+filmList.getRental_Duration()+"\t\t|"+filmList.getRatings()+"\t|"+filmList.getCategory().getCategory_Name()+"\t\t\t|"+filmList.getOriginalLanguage().getLanguage_Name()+"\t\t\t|"+filmList.getRelease_Date()+"\t\t|");
				ArrayList<Language> filmdlanguage=filmService.getLanguageList(filmList.getFilm_Id());
				
				
				for(Language lang:filmdlanguage)
				{
				
					System.out.println(lang.getLanguage_Name()+"\t\t|");
				}
				System.out.println("------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------");

				
			}	
			
			//*****************************************************************************************************
			
		}




























	}
