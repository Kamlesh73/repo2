package com.flp.fms.service;

import java.util.ArrayList;
import com.flp.fms.domain.Actor;



public interface IActorService
{
	public ArrayList<Actor> getActor(int fid);
	public ArrayList<Actor> getAllActor();
	public ArrayList<Actor> getActorList(int fid); 
}
